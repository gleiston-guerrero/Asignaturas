public class Primo {
    static boolean esPrimo(int n) {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
    public static void main(String[] args) {
        System.out.println(esPrimo(7));   // true
        System.out.println(esPrimo(8));   // false
    }
}
