public class EnumDemo {
    enum Estado { ACTIVO, INACTIVO, SUSPENDIDO }

    public static void main(String[] args) {
        Estado e = Estado.ACTIVO;
        String mensaje = switch (e) {
            case ACTIVO     -> "La cuenta esta activa";
            case INACTIVO   -> "La cuenta esta inactiva";
            case SUSPENDIDO -> "La cuenta esta suspendida";
        };
        System.out.println(mensaje);
    }
}
