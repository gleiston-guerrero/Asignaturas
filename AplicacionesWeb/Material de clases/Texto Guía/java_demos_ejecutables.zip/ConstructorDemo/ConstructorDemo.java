public class ConstructorDemo {
    public static void main(String[] args) {
        Estudiante e = new Estudiante("Ana", "ana@uteq.edu.ec");
        System.out.println(e.getNombre());
    }
}

class Estudiante {
    private String nombre;
    private String correo;
    public Estudiante(String nombre, String correo) {
        this.nombre = nombre;
        this.correo = correo;
    }
    public String getNombre() { return nombre; }
}
