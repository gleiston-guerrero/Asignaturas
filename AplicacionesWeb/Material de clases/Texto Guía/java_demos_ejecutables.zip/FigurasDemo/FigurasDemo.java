public class FigurasDemo {
    public static void main(String[] args) {
        Figura[] figuras = { new Circulo(2), new Cuadrado(3) };
        for (Figura f : figuras) {
            System.out.println(f.area());     // polimorfismo
        }
    }
}

interface Figura { double area(); }

class Circulo implements Figura {
    private double radio;
    public Circulo(double radio) { this.radio = radio; }
    @Override public double area() { return Math.PI * radio * radio; }
}

class Cuadrado implements Figura {
    private double lado;
    public Cuadrado(double lado) { this.lado = lado; }
    @Override public double area() { return lado * lado; }
}
