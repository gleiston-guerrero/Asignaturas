import java.util.*;

public class ContarPalabras {
    public static void main(String[] args) {
        String texto = "ana luis ana eva luis ana";
        Map<String, Integer> conteo = new HashMap<>();
        for (String palabra : texto.split(" ")) {
            conteo.put(palabra, conteo.getOrDefault(palabra, 0) + 1);
        }
        System.out.println(conteo);   // {ana=3, luis=2, eva=1}
    }
}
