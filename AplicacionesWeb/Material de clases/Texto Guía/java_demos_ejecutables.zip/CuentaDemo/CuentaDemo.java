public class CuentaDemo {
    public static void main(String[] args) {
        Cuenta c = new Cuenta();
        c.depositar(100);
        System.out.println(c.saldo);   // 100.0
    }
}

class Cuenta {
    double saldo;                      // atributo
    void depositar(double monto) {     // metodo
        this.saldo += monto;
    }
}
