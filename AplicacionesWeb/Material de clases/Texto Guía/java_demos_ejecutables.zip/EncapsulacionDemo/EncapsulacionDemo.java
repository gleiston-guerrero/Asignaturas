public class EncapsulacionDemo {
    public static void main(String[] args) {
        Cuenta c = new Cuenta();
        c.depositar(100);
        c.depositar(-50);              // ignorado por la validacion
        System.out.println(c.getSaldo());  // 100.0
    }
}

class Cuenta {
    private double saldo;              // oculto al exterior
    public void depositar(double monto) {
        if (monto > 0) this.saldo += monto;   // validacion
    }
    public double getSaldo() { return this.saldo; }
}
