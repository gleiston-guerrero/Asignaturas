public class Bucles {
    public static void main(String[] args) {
        for (int i = 1; i <= 3; i++) {
            System.out.print(i);          // 123
        }
        System.out.println();
        String[] colores = {"rojo", "verde", "azul"};
        for (String c : colores) {        // for-each
            System.out.print(c + " ");
        }
        System.out.println();
    }
}
