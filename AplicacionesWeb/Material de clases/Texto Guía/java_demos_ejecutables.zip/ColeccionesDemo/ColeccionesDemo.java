import java.util.*;

public class ColeccionesDemo {
    public static void main(String[] args) {
        List<String> lista = new ArrayList<>(List.of("a", "b", "a"));
        System.out.println(lista.size());     // 3 (admite duplicados)

        Set<String> conjunto = new HashSet<>(lista);
        System.out.println(conjunto.size());  // 2 (sin duplicados)

        Map<String, Integer> edades = new HashMap<>();
        edades.put("Ana", 21);
        edades.put("Luis", 23);
        System.out.println(edades.get("Ana")); // 21
    }
}
