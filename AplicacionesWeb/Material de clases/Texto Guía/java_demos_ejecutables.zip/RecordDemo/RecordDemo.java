public class RecordDemo {
    // Un record equivale a una clase con constructor, getters, equals y toString:
    record Estudiante(int id, String nombre, String correo) {}

    public static void main(String[] args) {
        var e = new Estudiante(1, "Ana", "ana@uteq.edu.ec");
        System.out.println(e.nombre());     // metodo de acceso: Ana
        System.out.println(e);              // toString automatico
    }
}
