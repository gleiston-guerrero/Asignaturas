public class Hola {
    public static void main(String[] args) {
        // System.out.println imprime y salta de linea
        System.out.println("Hola, mundo");
    }
}
