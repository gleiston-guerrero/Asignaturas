public class HerenciaDemo {
    public static void main(String[] args) {
        Perro p = new Perro("Fido");
        System.out.println(p.nombre + ": " + p.sonido());
    }
}

class Animal {
    protected String nombre;
    public Animal(String nombre) { this.nombre = nombre; }
    public String sonido() { return "..."; }
}

class Perro extends Animal {
    public Perro(String nombre) { super(nombre); }
    @Override public String sonido() { return "Guau"; }
}
