import java.util.*;
import java.util.stream.*;

public class AgruparPorCarrera {
    record Estudiante(int id, String nombre, String carrera) {}

    public static void main(String[] args) {
        List<Estudiante> estudiantes = List.of(
            new Estudiante(1, "Ana", "Software"),
            new Estudiante(2, "Luis", "Telematica"),
            new Estudiante(3, "Sara", "Software"));
        Map<String, Long> porCarrera = estudiantes.stream()
            .collect(Collectors.groupingBy(
                Estudiante::carrera, Collectors.counting()));
        System.out.println(porCarrera);
    }
}
