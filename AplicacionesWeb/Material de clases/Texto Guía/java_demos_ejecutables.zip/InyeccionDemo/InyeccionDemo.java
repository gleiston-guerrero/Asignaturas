import java.util.*;

public class InyeccionDemo {
    public static void main(String[] args) {
        var repo = new EstudianteRepositorio();
        var servicio = new EstudianteServicio(repo);   // se inyecta el repo
        servicio.listar().forEach(System.out::println);
    }
}

record Estudiante(int id, String nombre) {}

class EstudianteRepositorio {
    public List<Estudiante> listarTodos() {
        return List.of(new Estudiante(1, "Ana"), new Estudiante(2, "Luis"));
    }
}

class EstudianteServicio {
    private final EstudianteRepositorio repositorio;
    public EstudianteServicio(EstudianteRepositorio repositorio) {
        this.repositorio = repositorio;             // recibido, no creado
    }
    public List<Estudiante> listar() { return repositorio.listarTodos(); }
}
