public class Variables {
    public static void main(String[] args) {
        int edad = 21;             // entero
        double nota = 8.5;         // decimal
        char inicial = 'A';        // un caracter
        boolean activo = true;     // verdadero o falso
        long grande = 9000000000L;
        String nombre = "Ana";   // tipo de referencia
        final double IVA = 0.15;   // 'final' = constante

        System.out.println(nombre + " tiene " + edad);
        System.out.println("Nota: " + nota + " IVA: " + IVA);
        System.out.println(inicial + " " + activo + " " + grande);
    }
}
