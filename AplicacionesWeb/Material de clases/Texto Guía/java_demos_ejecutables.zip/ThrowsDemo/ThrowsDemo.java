public class ThrowsDemo {
    static int dividir(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("No se divide por cero");
        }
        return a / b;
    }
    public static void main(String[] args) {
        System.out.println(dividir(10, 2));     // 5
        try {
            dividir(10, 0);
        } catch (IllegalArgumentException e) {
            System.out.println("Capturado: " + e.getMessage());
        }
    }
}
