import java.util.function.*;

public class LambdasDemo {
    public static void main(String[] args) {
        Function<Integer, Integer> doble = x -> x * 2;
        System.out.println(doble.apply(5));        // 10
        Predicate<Integer> esPar = n -> n % 2 == 0;
        System.out.println(esPar.test(4));         // true
    }
}
