import java.util.*;
import java.util.stream.*;

public class StreamsDemo {
    public static void main(String[] args) {
        List<Integer> numeros = List.of(1, 2, 3, 4, 5, 6);
        List<Integer> paresAlCuadrado = numeros.stream()
            .filter(n -> n % 2 == 0)      // quedarse con los pares
            .map(n -> n * n)              // elevar al cuadrado
            .collect(Collectors.toList());
        System.out.println(paresAlCuadrado);   // [4, 16, 36]

        int suma = numeros.stream().mapToInt(Integer::intValue).sum();
        System.out.println(suma);              // 21
    }
}
