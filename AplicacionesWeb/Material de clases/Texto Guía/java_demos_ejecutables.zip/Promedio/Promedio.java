public class Promedio {
    public static void main(String[] args) {
        double[] notas = {7, 8.5, 6, 9, 10};
        double suma = 0;
        for (double n : notas) suma += n;
        System.out.println("Promedio: " + (suma / notas.length));
    }
}
