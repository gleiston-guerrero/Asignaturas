import java.util.*;

public class OptionalDemo {
    public static void main(String[] args) {
        Optional<String> resultado = Optional.of("Ana");
        System.out.println(resultado.orElse("desconocido"));   // Ana
        Optional<String> vacio = Optional.empty();
        System.out.println(vacio.orElse("desconocido"));       // desconocido
    }
}
