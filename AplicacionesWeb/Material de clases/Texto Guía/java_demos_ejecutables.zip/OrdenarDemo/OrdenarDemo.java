import java.util.*;

public class OrdenarDemo {
    public static void main(String[] args) {
        List<String> nombres = new ArrayList<>(List.of("Luis", "Ana", "Eva"));
        Collections.sort(nombres);                       // alfabetico
        System.out.println(nombres);
        nombres.sort(Comparator.reverseOrder());         // inverso
        System.out.println(nombres);
        nombres.sort(Comparator.comparingInt(String::length)); // por longitud
        System.out.println(nombres);
    }
}
