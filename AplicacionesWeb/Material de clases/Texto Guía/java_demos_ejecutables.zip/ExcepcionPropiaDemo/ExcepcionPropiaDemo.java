public class ExcepcionPropiaDemo {
    public static void main(String[] args) {
        double saldo = 100, monto = 150;
        try {
            if (monto > saldo) {
                throw new SaldoInsuficienteException("Fondos insuficientes");
            }
        } catch (SaldoInsuficienteException e) {
            System.out.println(e.getMessage());
        }
    }
}

class SaldoInsuficienteException extends RuntimeException {
    public SaldoInsuficienteException(String mensaje) { super(mensaje); }
}
