public class ExcepcionesDemo {
    public static void main(String[] args) {
        try {
            int resultado = 10 / 0;          // lanza ArithmeticException
            System.out.println(resultado);
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Esto se ejecuta siempre");
        }
    }
}
