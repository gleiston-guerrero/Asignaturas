public class VarDemo {
    public static void main(String[] args) {
        var nombre = "Ana";        // el compilador deduce: String
        var edad   = 21;            // deduce: int
        var notas  = new int[]{7, 8, 9};
        System.out.println(nombre + " " + edad + " " + notas.length);
    }
}
