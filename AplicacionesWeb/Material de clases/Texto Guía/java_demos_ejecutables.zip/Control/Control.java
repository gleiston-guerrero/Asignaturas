public class Control {
    public static void main(String[] args) {
        int nota = 8;
        if (nota >= 7) {
            System.out.println("Aprobado");
        } else {
            System.out.println("Reprobado");
        }
        String letra = switch (nota) {   // expresion switch (Java 14+)
            case 9, 10 -> "A";
            case 7, 8  -> "B";
            default    -> "C";
        };
        System.out.println(letra);
    }
}
