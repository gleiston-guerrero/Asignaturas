import java.util.*;

public class GenericosDemo {
    public static void main(String[] args) {
        List<String> nombres = new ArrayList<>();   // solo String
        nombres.add("Ana");
        // nombres.add(42);   // ERROR en compilacion: no es String
        String primero = nombres.get(0);            // sin conversiones
        System.out.println(primero);
    }
}
