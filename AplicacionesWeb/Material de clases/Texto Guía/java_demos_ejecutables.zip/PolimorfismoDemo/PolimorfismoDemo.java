public class PolimorfismoDemo {
    public static void main(String[] args) {
        Animal[] animales = { new Perro("Fido"), new Animal("X") };
        for (Animal a : animales) {
            System.out.println(a.sonido());   // cada uno responde distinto
        }
    }
}

class Animal {
    protected String nombre;
    public Animal(String nombre) { this.nombre = nombre; }
    public String sonido() { return "..."; }
}

class Perro extends Animal {
    public Perro(String nombre) { super(nombre); }
    @Override public String sonido() { return "Guau"; }
}
