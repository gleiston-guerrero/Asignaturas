public class Metodos {
    static int sumar(int a, int b) { return a + b; }
    static double sumar(double a, double b) { return a + b; }   // sobrecarga
    static int sumarTodos(int... valores) {                     // varargs
        int total = 0;
        for (int v : valores) total += v;
        return total;
    }
    public static void main(String[] args) {
        System.out.println(sumar(2, 3));            // 5
        System.out.println(sumar(2.5, 3.5));        // 6.0
        System.out.println(sumarTodos(1, 2, 3, 4)); // 10
    }
}
