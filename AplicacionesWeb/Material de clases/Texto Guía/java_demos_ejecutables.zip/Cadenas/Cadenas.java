public class Cadenas {
    public static void main(String[] args) {
        String nombre = "Ana";
        String saludo = "Hola, " + nombre;   // concatenacion con +
        System.out.println(saludo);
        System.out.println(saludo.length());   // longitud
        System.out.println(saludo.toUpperCase());

        // En Java las cadenas NO interpolan variables:
        String clave = "P@$7Gr3$QL";          // literal, sin precaucion
        System.out.println(clave);

        String bloque = """
                Primera linea
                Segunda linea""";              // bloque de texto (Java 15+)
        System.out.println(bloque);
    }
}
