public class Arreglos {
    public static void main(String[] args) {
        int[] numeros = {10, 20, 30};
        System.out.println(numeros[0]);     // 10
        System.out.println(numeros.length); // 3
        numeros[1] = 99;                    // modificar
        int suma = 0;
        for (int n : numeros) suma += n;
        System.out.println("Suma: " + suma);
    }
}
