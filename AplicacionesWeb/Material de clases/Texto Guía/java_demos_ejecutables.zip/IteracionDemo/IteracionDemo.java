import java.util.*;

public class IteracionDemo {
    public static void main(String[] args) {
        List<String> lista = List.of("a", "b", "c");
        for (String s : lista) {
            System.out.println(s);
        }
        Map<String, Integer> edades = Map.of("Ana", 21, "Luis", 23);
        for (Map.Entry<String, Integer> e : edades.entrySet()) {
            System.out.println(e.getKey() + " -> " + e.getValue());
        }
    }
}
