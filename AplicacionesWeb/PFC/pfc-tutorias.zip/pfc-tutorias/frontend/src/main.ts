import { bootstrapApplication } from '@angular/platform-browser';
import { Component } from '@angular/core';

/**
 * Componente raíz del Sistema de Gestión de Tutorías Académicas de la UTEQ.
 * Versión 0.3.0: sólo renderiza el contenido estático del index.html mediante
 * el selector <app-root>. Los módulos funcionales se agregarán a partir de la
 * Entrega 2 (v0.7.0, semana 12) con enrutamiento, servicios HTTP con
 * interceptor JWT y componentes de negocio.
 */
@Component({
  selector: 'app-root',
  standalone: true,
  template: `<ng-content></ng-content>`
})
export class AppComponent {}

bootstrapApplication(AppComponent).catch((err: unknown) => console.error(err));
