/**
 * Diagrama C4 Nivel 2 - Container Diagram
 * Sistema de Gestion de Tutorias Academicas de la UTEQ
 *
 * Referencia autoritativa:
 *   Brown, S. (2023). The C4 Model for Visualising Software Architecture.
 *   https://c4model.com
 */

workspace "PFC Tutorias UTEQ" "Sistema de Gestion de Tutorias Academicas - Nivel 2" {

    model {

        estudiante   = person "Estudiante"
        docente      = person "Docente"
        coordinacion = person "Coordinacion Academica"

        sga      = softwareSystem "SGA UTEQ"            "Sistema academico institucional." "sistema-externo"
        smtp     = softwareSystem "Servidor SMTP UTEQ"  "Correo institucional."             "sistema-externo"
        whatsapp = softwareSystem "WhatsApp Business"   "Canal opcional."                    "sistema-externo"

        sistema = softwareSystem "Sistema de Gestion de Tutorias" {

            web = container "Frontend Angular" {
                description "Single Page Application (SPA) que consume la API REST. Interfaz para los tres tipos de usuarios."
                technology "Angular 17 (standalone) + TypeScript 5.4 servida por Nginx 1.27"
                tags "spa"
            }

            api = container "API REST" {
                description "Monolito modular que expone la logica de negocio a traves de una API HTTP REST conforme a RFC 9110. Autenticacion JWT stateless. En v0.3.0 solo expone /actuator/health."
                technology "Spring Boot 3.4 sobre Java 21 LTS (Eclipse Temurin)"
                tags "api"
            }

            db = container "Base de Datos Relacional" {
                description "Persistencia transaccional con integridad referencial. Almacena usuarios, asignaturas, franjas, solicitudes y sesiones. Politica hibrida de acceso: CRUD via JPA + procedimientos almacenados para operaciones complejas (ADR-004)."
                technology "PostgreSQL 16 (alpine)"
                tags "database"
            }

            cache = container "Cache en memoria" {
                description "Cache in-memory de sesiones y blacklist de JTI (JWT ID) revocados. En v0.3.0 arranca sin datos; se utiliza a partir de v0.7.0."
                technology "Redis 7 (alpine)"
                tags "cache"
            }
        }

        estudiante   -> web  "Usa"    "HTTPS"
        docente      -> web  "Usa"    "HTTPS"
        coordinacion -> web  "Usa"    "HTTPS"

        web -> api "Consume la API REST" "HTTPS + JSON"

        api -> db    "Lee y escribe datos"                          "JDBC (JPA + SPs)"
        api -> cache "Cache de sesiones y blacklist JTI"            "Redis Protocol"
        api -> sga   "Valida asignaturas y aulas (Entrega 2+)"      "HTTPS/REST"
        api -> smtp  "Envia notificaciones por correo (Entrega 2+)" "SMTP+TLS"
        api -> whatsapp "Envia notificaciones opcionales (Entrega 3+)" "HTTPS/REST"
    }

    views {

        container sistema "Containers" {
            include *
            autolayout lr
            description "Nivel 2 - Container Diagram. Muestra los cuatro contenedores desplegables (SPA, API, BD, Cache) y sus interacciones con actores y sistemas externos."
        }

        styles {
            element "Person" {
                shape person
                background "#006633"
                color "#ffffff"
                fontSize 20
            }
            element "spa" {
                background "#cc9900"
                color "#ffffff"
                fontSize 18
            }
            element "api" {
                background "#006633"
                color "#ffffff"
                fontSize 18
            }
            element "database" {
                shape cylinder
                background "#003399"
                color "#ffffff"
                fontSize 18
            }
            element "cache" {
                shape cylinder
                background "#cc0000"
                color "#ffffff"
                fontSize 18
            }
            element "sistema-externo" {
                background "#999999"
                color "#ffffff"
                fontSize 16
            }
        }
    }
}
