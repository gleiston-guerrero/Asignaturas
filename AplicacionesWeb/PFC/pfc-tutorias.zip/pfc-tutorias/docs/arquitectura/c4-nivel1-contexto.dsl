/**
 * Diagrama C4 Nivel 1 - System Context Diagram
 * Sistema de Gestion de Tutorias Academicas de la UTEQ
 *
 * Referencia autoritativa:
 *   Brown, S. (2023). The C4 Model for Visualising Software Architecture.
 *   https://c4model.com
 *
 * Renderizado a PNG con Structurizr DSL:
 *   docker run -it --rm -v $(pwd):/usr/local/structurizr structurizr/cli \
 *       export -workspace c4-nivel1-contexto.dsl -format plantuml
 *   plantuml -tpng c4-nivel1-contexto.puml
 *
 * Alternativa: importar en https://structurizr.com/dsl
 */

workspace "PFC Tutorias UTEQ" "Sistema de Gestion de Tutorias Academicas - Nivel 1" {

    model {

        // ------------------- Actores humanos -------------------
        estudiante  = person "Estudiante" {
            description "Estudiante matriculado en una carrera de la UTEQ que solicita tutorias."
        }

        docente = person "Docente" {
            description "Docente titular o de contrato que configura su disponibilidad, gestiona solicitudes y registra tutorias realizadas."
        }

        coordinacion = person "Coordinacion Academica" {
            description "Coordinador(a) de carrera que monitorea la actividad tutorial y consulta reportes agregados."
        }

        // ------------------- Sistema objeto -------------------
        sistema = softwareSystem "Sistema de Gestion de Tutorias" {
            description "Plataforma web institucional para solicitud, aceptacion, seguimiento y evaluacion de tutorias academicas."
            tags "sistema-objeto"
        }

        // ------------------- Sistemas externos -------------------
        sga = softwareSystem "SGA UTEQ" {
            description "Sistema de Gestion Academica institucional. Fuente de la verdad para matriculas, asignaturas activas y disponibilidad de aulas."
            tags "sistema-externo"
        }

        smtp = softwareSystem "Servidor SMTP institucional" {
            description "Servidor de correo institucional (Google Workspace UTEQ) usado para el envio de notificaciones por defecto."
            tags "sistema-externo"
        }

        whatsapp = softwareSystem "WhatsApp Business API" {
            description "Canal opcional de notificaciones. Su uso esta condicionado por la disponibilidad de la API oficial de Meta."
            tags "sistema-externo"
        }

        // ------------------- Relaciones -------------------
        estudiante   -> sistema  "Registra solicitudes, consulta estado, revisa historial"
        docente      -> sistema  "Configura disponibilidad, gestiona solicitudes, registra sesiones"
        coordinacion -> sistema  "Consulta reportes agregados y estadisticas"

        sistema -> sga       "Valida asignaturas activas y disponibilidad de aulas (RF-10)"  "HTTPS/REST"
        sistema -> smtp      "Envia notificaciones por correo (canal por defecto)"           "SMTP+TLS"
        sistema -> whatsapp  "Envia notificaciones opcionales cuando el usuario lo elige"     "HTTPS/REST"
    }

    views {

        systemContext sistema "SystemContext" {
            include *
            autolayout lr
            description "Nivel 1 - System Context Diagram. Muestra el sistema como una caja unica en su entorno de actores humanos y sistemas externos."
        }

        styles {
            element "Person" {
                shape person
                background "#006633"
                color "#ffffff"
                fontSize 22
            }
            element "sistema-objeto" {
                background "#006633"
                color "#ffffff"
                fontSize 22
            }
            element "sistema-externo" {
                background "#999999"
                color "#ffffff"
                fontSize 18
            }
        }
    }
}
