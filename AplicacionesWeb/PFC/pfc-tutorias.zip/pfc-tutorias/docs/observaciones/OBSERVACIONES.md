# Bitácora de observaciones — PFC de Tutorías (AppWeb 2026-2027)

Esta bitácora es acumulativa a lo largo de las cuatro entregas del PFC. Cada observación registrada por el Product Owner institucional o por los pares evaluadores durante las defensas orales queda archivada con su código único, texto íntegro sin edición, decisión tomada por el equipo, hash del commit de resolución y estado actual.

**Formato de cada entrada**:

- **Código**: `OBS-NN` (correlativo desde 01).
- **Fecha**: fecha ISO 8601 (`YYYY-MM-DD`) en que se registró la observación.
- **Origen**: quién la formuló (docente responsable, par evaluador, integrante del equipo).
- **Texto íntegro**: la observación exactamente como fue expresada, sin reformular ni suavizar.
- **Categoría**: `requisitos`, `arquitectura`, `código`, `documentación`, `proceso`, `seguridad`, `pruebas`, `reproducibilidad`.
- **Decisión del equipo**: qué se decidió hacer y por qué.
- **Commit**: hash corto del commit que la resuelve (`N/A` si aún está abierta).
- **Estado**: `ABIERTA`, `EN CURSO`, `RESUELTA`, `DIFERIDA con ADR-NNN`.

---

## Estado actual

**Entrega 1 (v0.3.0)**: bitácora inicializada. Todas las observaciones que reciba el equipo durante la defensa oral parcial (semana 6) se registrarán aquí durante las 48 horas posteriores.

**Observaciones registradas hasta la fecha**: 0

---

## Observaciones

<!--
Ejemplo de entrada (borrar cuando llegue la primera observación real):

### OBS-01 — 2026-06-05 — docente responsable — categoría: requisitos

**Texto íntegro**: "El RNF-05 sobre disponibilidad establece 99.5% pero no declara la ventana temporal (por mes calendario, por semestre, sobre horario académico) ni el instrumento de medición. Un RNF sin instrumento no es verificable."

**Decisión del equipo**: refinar RNF-05 declarando ventana temporal "por semestre académico durante horario 06:00-22:00 hora Ecuador" e instrumento "Prometheus + Grafana con alerta por indisponibilidad > 3 min consecutivos".

**Commit**: `a3f2c1e`

**Estado**: RESUELTA

---
-->

*(Sin observaciones todavía. Se poblará con la retroalimentación de la defensa oral parcial de la semana 6.)*

---

## Reglas operativas

1. Ninguna observación se cierra sin `commit` que la resuelva o sin un ADR que documente su diferimiento justificado.
2. Las observaciones abiertas por más de dos semanas escalan a discusión en la siguiente sesión sprint retrospective del equipo.
3. Las observaciones DIFERIDAS con ADR se revisan al inicio de cada Entrega para confirmar si siguen siendo aplazables.
4. Esta bitácora se audita en la Entrega Final como evidencia de trazabilidad de la retroalimentación docente y del rigor del proceso de mejora continua.
