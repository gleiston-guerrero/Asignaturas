# CHANGELOG del corpus de requisitos

Este archivo documenta todos los cambios que el equipo del PFC de Aplicaciones Web ha realizado respecto al corpus de requisitos base producido en la asignatura de Ingeniería de Requisitos del cuarto nivel (PPA 2025-2026). Sigue el formato [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/).

---

## Corpus base

**Documento**: *Análisis de Requisitos para el Sistema de Gestión de Tutorías Académicas de la UTEQ*

**Autores del corpus base**: Toaquiza B., Lombeida B., Muñoz M., Zambrano M. (estudiantes de 4.º semestre B, Carrera de Ingeniería de Software, PPA 2025-2026)

**Supervisión académica**: Dr. Gleiston Guerrero Ulloa, Ph.D.

**Contenido original que se adopta sin cambios**:

- 26 requisitos funcionales (RF-01 a RF-26)
- 3 requisitos no funcionales originales (que se refinan y expanden en `RNF.md`)
- 11 requisitos de interfaz (RI-01 a RI-11)
- 5 requisitos de usabilidad (RU-01 a RU-05)
- 8 requisitos de proceso (RP-01 a RP-08)
- Priorización Kano (14 imprescindibles, 4 satisfactorios, 1 delighter)
- Matriz de trazabilidad por categoría
- 11 historias de usuario base
- Diagramas UML de casos de uso, clases (análisis) y actividad

---

## [0.3.0] — 2026-06-05 — Entrega 1 del PFC de Aplicaciones Web

### Added

- Refinamiento de los 3 RNF originales a un catálogo de 8 RNF, cada uno con métrica cuantitativa ISO/IEC 25010:2011, instrumento de medición y umbral de aceptación (véase `RNF.md`).
- Redacción de 5 casos de uso siguiendo la plantilla Cockburn *fully-dressed* (véase `casos-uso/CU-01` a `CU-05`), a partir de los flujos identificados en el corpus base:
  - CU-01: Registrar solicitud de tutoría
  - CU-02: Aceptar o rechazar solicitud
  - CU-03: Registrar tutoría realizada
  - CU-04: Consultar estado de solicitudes
  - CU-05: Generar reporte institucional
- Adaptación de las 11 historias de usuario originales al formato Connextra + Gherkin, con criterios de aceptación operacionales verificables (véase `historias-usuario/BACKLOG.md`).
- Especificación de Requisitos del Software (SRS) formalizada conforme a la cláusula 9 de ISO/IEC/IEEE 29148:2018 con secciones explícitas de *Introduction*, *Overall Description*, *Specific Requirements* y *Verification* (véase `SRS-v0.3.0.tex` y su PDF).

### Changed

- **RF-05 (Confirmación de asistencia)**: se explicita que la confirmación puede ser realizada tanto por el estudiante (vía la SPA) como por el docente (al registrar la tutoría realizada), no exclusivamente por el docente como se implicaba en el corpus base.
- **RNF-01 (Alta disponibilidad)**: se declara la ventana temporal específica *"lunes-viernes 06:00-22:00 hora Ecuador durante un semestre académico completo"* que en el corpus base no estaba fijada. Se especifica el instrumento (Prometheus + Grafana).
- **RNF-02 (Auditoría)**: se lista explícitamente las 15 acciones críticas que deben quedar auditadas, con especificación del esquema de la tabla `auditoria_evento`.
- **RNF-03 (Seguridad)**: se refina con especificación de OWASP Top 10:2021 (controles A01, A02, A03, A05, A07) y del instrumento OWASP ZAP 2.14.

### Deprecated

- Ninguno.

### Removed

- Ninguno. Se conservan íntegramente los 26 RF, 11 RI, 5 RU y 8 RP del corpus base.

### Fixed

- **Ambiguïdad en RF-08 (Agrupación de sesiones)**: el corpus base dejaba abierto si la agrupación era manual por el docente o automática por criterio del sistema. Se decide en la SRS que es **manual con sugerencia automática por similaridad de tema y coincidencia horaria**. Documentado como decisión menor en el SRS.

### Security

- Incorporación explícita del control OWASP A03 (Injection) al RNF-03, con la prohibición absoluta de concatenación dinámica de SQL declarada como restricción arquitectónica en el ADR-004.

---

## Reglas operativas para futuros cambios

1. Todo cambio a un requisito ya publicado en una versión etiquetada debe registrarse aquí antes del siguiente tag.
2. Los cambios que alteren el comportamiento observable de un requisito ya implementado incrementan el MINOR de la versión del PFC.
3. Los cambios que rompan compatibilidad con la implementación existente incrementan el MAJOR de la versión.
4. Ningún requisito puede eliminarse silenciosamente. Toda eliminación requiere entrada en la sección `Removed` de esta bitácora con la justificación.
5. Los cambios que introduzcan un ADR o modifiquen uno existente citan el ADR correspondiente en la línea del cambio.
