# Backlog de Historias de Usuario — Sistema de Tutorías UTEQ

**Versión**: `v0.3.0` (Entrega 1)
**Formato**: Connextra + criterios de aceptación en Gherkin
**Referencias autoritativas**:
- Cohn, M. (2004). *User Stories Applied: For Agile Software Development*. Addison-Wesley Professional.
- ISO/IEC/IEEE 29148:2018, cláusula 9.5.5 (User Stories como técnica de captura).

Las 11 historias derivan del corpus base de Ingeniería de Requisitos (PPA 2025-2026) y están trazadas a los requisitos funcionales del SRS. Todas cumplen con los seis criterios **INVEST** (Independent, Negotiable, Valuable, Estimable, Small, Testable).

---

## HU-01 — Consultar estado de solicitudes

**Como** estudiante,
**quiero** poder consultar el estado de mis solicitudes de tutoría (pendiente, aceptada, rechazada, realizada),
**para** saber en qué situación se encuentra cada solicitud y cuándo debo esperar respuesta del docente.

**Trazado a**: RF-06 (Consulta de estado)

**Prioridad MoSCoW**: Must
**Clasificación Kano**: Imprescindible (insatisfactor)

**Criterios de aceptación (Gherkin)**:

```gherkin
Escenario: consulta de solicitudes activas
  Dado que soy un estudiante autenticado con al menos una solicitud registrada
  Cuando accedo a la vista "Mis solicitudes"
  Entonces el sistema muestra la lista de solicitudes con su estado actualizado

Escenario: actualizacion en tiempo cuasi-real
  Dado que el docente cambia el estado de una solicitud
  Cuando el cambio se guarda en la base de datos
  Entonces el estado actualizado se refleja en la vista del estudiante en menos de 30 segundos
```

---

## HU-02 — Registrar tutoría realizada

**Como** docente,
**quiero** poder registrar las tutorías realizadas con información como duración, temas cubiertos y observaciones,
**para** llevar un control adecuado de las sesiones y tener un historial accesible para futuras referencias y reportes.

**Trazado a**: RF-04 (Registro de tutoría realizada), RF-11 (Historial), RF-17 (Duración)

**Prioridad MoSCoW**: Must
**Clasificación Kano**: Imprescindible

**Criterios de aceptación**:

```gherkin
Escenario: registro despues de una sesion aceptada
  Dado que soy un docente con una tutoria en estado "aceptada" y su hora ya paso
  Cuando accedo a la vista "Registrar sesion realizada"
  Entonces el sistema me permite ingresar duracion real, asistentes y observaciones

Escenario: validacion de campos obligatorios
  Dado que intento registrar una sesion sin campos obligatorios completados
  Cuando presiono "Guardar"
  Entonces el sistema muestra los campos faltantes con asterisco rojo y no permite el guardado
```

---

## HU-03 — Generar reportes institucionales

**Como** coordinador académico,
**quiero** poder generar reportes filtrables por carrera, asignatura, docente y estudiante,
**para** analizar la distribución y el impacto de las tutorías académicas en cada área.

**Trazado a**: RF-07 (Reportes institucionales), RF-24 (Exportación)

**Prioridad MoSCoW**: Should
**Clasificación Kano**: Imprescindible

**Criterios de aceptación**:

```gherkin
Escenario: reporte por carrera y periodo
  Dado que soy un coordinador autenticado
  Cuando accedo al panel de reportes y aplico filtros por carrera y periodo academico
  Entonces el sistema genera un reporte con los datos actualizados en menos de 5 segundos

Escenario: exportacion PDF y Excel
  Dado que genero un reporte
  Cuando presiono "Exportar PDF" o "Exportar Excel"
  Entonces el sistema entrega un archivo valido con el mismo contenido visible en pantalla
```

---

## HU-04 — Elegir modalidad de tutoría

**Como** estudiante,
**quiero** poder elegir si prefiero una tutoría individual o grupal,
**para** seleccionar el tipo que mejor se ajuste a mis necesidades y horarios.

**Trazado a**: RF-09 (Modalidad), RF-12 (Tipo de tutoría)

**Prioridad MoSCoW**: Must
**Clasificación Kano**: Imprescindible

**Criterios de aceptación**:

```gherkin
Escenario: modalidades disponibles
  Dado que estoy registrando una nueva solicitud de tutoria
  Cuando el docente elegido tiene ambas modalidades habilitadas
  Entonces el sistema muestra las opciones "Individual" y "Grupal" seleccionables

Escenario: modalidad restringida por el docente
  Dado que el docente solo tiene habilitada la modalidad "Grupal"
  Cuando intento seleccionar "Individual"
  Entonces el sistema muestra un mensaje explicativo y bloquea la opcion
```

---

## HU-05 — Configurar disponibilidad del docente

**Como** docente,
**quiero** poder configurar mi disponibilidad de tutoría en el sistema,
**para** que los estudiantes puedan ver mis horarios disponibles y solicitar tutorías acordes con mi tiempo libre.

**Trazado a**: RF-02 (Configurar disponibilidad), RF-20 (Configurar horario)

**Prioridad MoSCoW**: Must
**Clasificación Kano**: Imprescindible

**Criterios de aceptación**:

```gherkin
Escenario: agregar franja horaria
  Dado que soy un docente autenticado
  Cuando accedo a la vista "Mi disponibilidad"
  Entonces el sistema me permite anadir, modificar o eliminar franjas horarias en formato semanal

Escenario: prevencion de solapamiento
  Dado que intento crear una franja horaria que se solapa con otra ya registrada
  Cuando guardo el cambio
  Entonces el sistema rechaza el guardado y muestra el mensaje "Franja solapada con otra existente"
```

---

## HU-06 — Registrar solicitud de tutoría

**Como** estudiante,
**quiero** poder registrar una solicitud de tutoría indicando asignatura, tema, modalidad y tipo de sesión,
**para** que el sistema notifique al docente y quede registrada en el historial.

**Trazado a**: RF-01 (Registro de solicitud), RF-09, RF-12, RF-14 (Notificación), RF-16 (Visualización de horarios)

**Prioridad MoSCoW**: Must
**Clasificación Kano**: Imprescindible

**Criterios de aceptación**:

```gherkin
Escenario: solicitud valida con asignatura activa
  Dado que soy un estudiante autenticado con asignaturas activas
  Cuando completo el formulario de solicitud y presiono "Enviar"
  Entonces el sistema registra la solicitud, notifica al docente y responde con codigo HTTP 201

Escenario: asignatura no activa
  Dado que intento enviar una solicitud con una asignatura no activa en el ciclo academico
  Cuando presiono "Enviar"
  Entonces el sistema bloquea el envio con codigo HTTP 400 y ProblemDetails con detalle explicativo
```

---

## HU-07 — Recibir notificaciones automáticas

**Como** estudiante o docente,
**quiero** recibir notificaciones automáticas sobre el estado de una solicitud (aceptada, rechazada, reprogramada),
**para** mantenerme informado en tiempo real.

**Trazado a**: RF-14 (Notificación de solicitudes)

**Prioridad MoSCoW**: Must
**Clasificación Kano**: Satisfactorio (unidimensional)

**Criterios de aceptación**:

```gherkin
Escenario: envio por canal preferido
  Dado que una solicitud cambia de estado
  Cuando el cambio se confirma en la base de datos
  Entonces el sistema envia notificacion automatica al canal configurado por el usuario en menos de 30 segundos

Escenario: canal principal indisponible
  Dado que el canal preferido del usuario no esta disponible temporalmente
  Cuando el sistema intenta enviar la notificacion
  Entonces aplica el canal de respaldo (correo institucional) y registra el intento fallido en bitacora auditable
```

---

## HU-08 — Configurar preferencias de notificación

**Como** estudiante o docente,
**quiero** configurar mis preferencias de notificación (canal y frecuencia),
**para** recibir avisos según mis necesidades y evitar sobrecarga.

**Trazado a**: RF-13 (Preferencias), RF-15 (Frecuencia de recordatorio)

**Prioridad MoSCoW**: Could
**Clasificación Kano**: Satisfactorio

**Criterios de aceptación**:

```gherkin
Escenario: seleccion de canal
  Dado que soy un usuario autenticado
  Cuando accedo a "Preferencias de notificacion"
  Entonces el sistema me permite elegir canal (correo, plataforma o WhatsApp) y frecuencia de recordatorio

Escenario: aplicacion inmediata de preferencias
  Dado que guardo mis preferencias
  Cuando el sistema envia la siguiente notificacion
  Entonces usa el canal y la frecuencia configurados
```

---

## HU-09 — Rechazar o reprogramar tutoría

**Como** docente,
**quiero** poder rechazar o reprogramar una tutoría indicando motivos y proponiendo nuevas fechas,
**para** gestionar eficientemente mi tiempo y la disponibilidad de los estudiantes.

**Trazado a**: RF-03 (Aceptar/rechazar), RF-21 (Rechazo), RF-22 (Reprogramación), RF-25 (Reasignación grupal)

**Prioridad MoSCoW**: Must
**Clasificación Kano**: Satisfactorio

**Criterios de aceptación**:

```gherkin
Escenario: reprogramacion con validacion cruzada
  Dado que tengo una tutoria en estado "aceptada"
  Cuando presiono "Reprogramar" y propongo un nuevo horario
  Entonces el sistema valida compatibilidad con el horario del estudiante y notifica automaticamente

Escenario: rechazo con motivo obligatorio
  Dado que presiono "Rechazar" en una tutoria aceptada
  Cuando el motivo esta vacio
  Entonces el sistema muestra HTTP 400 con ProblemDetails ("motivo requerido") y no cambia el estado
```

---

## HU-10 — Generar reportes personales del docente

**Como** docente,
**quiero** generar reportes de mis tutorías filtrados por asignatura, grupo o fechas,
**para** analizar el seguimiento académico de mis estudiantes y evaluar mi carga tutorial.

**Trazado a**: RF-23 (Reportes docente), RF-24 (Exportación)

**Prioridad MoSCoW**: Should
**Clasificación Kano**: Satisfactorio

**Criterios de aceptación**:

```gherkin
Escenario: reporte filtrado por asignatura
  Dado que soy un docente autenticado
  Cuando accedo a "Mis reportes" y aplico filtros por asignatura y rango de fechas
  Entonces el sistema entrega un reporte con las tutorias correspondientes en menos de 3 segundos

Escenario: exportacion de mis reportes
  Dado que presiono "Exportar PDF" o "Exportar Excel"
  Cuando el sistema completa la generacion
  Entonces entrega un archivo valido descargable con encabezado institucional
```

---

## HU-11 — Consultar historial de tutorías

**Como** estudiante o docente,
**quiero** consultar el historial de tutorías realizadas,
**para** tener acceso a sesiones pasadas y sus detalles.

**Trazado a**: RF-11 (Historial)

**Prioridad MoSCoW**: Should
**Clasificación Kano**: Imprescindible

**Criterios de aceptación**:

```gherkin
Escenario: acceso al historial paginado
  Dado que soy un usuario autenticado con tutorias finalizadas
  Cuando accedo a "Mi historial"
  Entonces el sistema muestra la lista filtrable por fecha, estado, tipo y tema con paginacion de 20 por pagina

Escenario: consulta de detalle de sesion
  Dado que selecciono una tutoria del historial
  Cuando presiono "Ver detalles"
  Entonces el sistema muestra duracion real, asistentes, observaciones y adjuntos si los hay
```

---

## Verificación INVEST agregada

| Criterio | HU-01 | HU-02 | HU-03 | HU-04 | HU-05 | HU-06 | HU-07 | HU-08 | HU-09 | HU-10 | HU-11 |
|----------|-------|-------|-------|-------|-------|-------|-------|-------|-------|-------|-------|
| **I**ndependent | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **N**egotiable  | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **V**aluable    | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **E**stimable   | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **S**mall       | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **T**estable    | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |

**Total historias**: 11
**Cumplimiento INVEST**: 11/11 (100 %)
