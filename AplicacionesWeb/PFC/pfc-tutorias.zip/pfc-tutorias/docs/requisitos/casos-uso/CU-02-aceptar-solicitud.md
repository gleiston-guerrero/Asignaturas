# CU-02 — Aceptar o rechazar solicitud de tutoría

## Metadatos

| Campo | Valor |
|-------|-------|
| **Identificador** | CU-02 |
| **Nombre** | Aceptar o rechazar solicitud de tutoría |
| **Actor principal** | Docente |
| **Actores secundarios** | Estudiante (destinatario de la notificación), Servidor SMTP, Servicio WhatsApp Business (opcional) |
| **Requisitos trazados** | RF-03, RF-14, RF-21, RF-22, RF-25 |
| **Historia trazada** | HU-09 |
| **Prioridad MoSCoW / Kano** | Must / Imprescindible |
| **Nivel Cockburn** | Objetivo de usuario |
| **Complejidad estimada** | Media |
| **Frecuencia esperada** | Alta |

## Precondiciones

- El docente está autenticado en el sistema con credenciales válidas.
- Existe al menos una solicitud dirigida al docente en estado `PENDIENTE`.

## Postcondiciones

**De éxito (aceptación)**:

- La solicitud cambia a estado `ACEPTADA` con marca temporal `fecha_decision`.
- El sistema calcula el `token_acceso_sesion` que se usará el día de la tutoría (implementado en Entrega 2).
- Se notifica al estudiante por su canal preferido.
- Se registra evento `SOLICITUD_ACEPTADA` en `auditoria_evento`.

**De éxito (rechazo)**:

- La solicitud cambia a estado `RECHAZADA` con marca temporal, motivo obligatorio y sugerencias opcionales.
- Se notifica al estudiante con el motivo del rechazo.
- Se registra evento `SOLICITUD_RECHAZADA` en `auditoria_evento`.

**De éxito (reprogramación)**:

- Se crea una nueva solicitud vinculada con estado `PENDIENTE_CONFIRMACION_ESTUDIANTE`.
- La solicitud original queda en estado `REPROGRAMADA` conservando trazabilidad.
- Se notifica al estudiante con las nuevas fechas propuestas.
- Se registra evento `SOLICITUD_REPROGRAMADA`.

**De fallo**:

- No se cambia el estado de la solicitud.
- Se responde al docente con mensaje explicativo en RFC 7807.

## Escenario principal (aceptación simple)

1. El docente accede a "Mis solicitudes pendientes" desde el menú principal.
2. El sistema muestra la lista de solicitudes en estado `PENDIENTE` ordenadas por fecha de recepción ascendente, con paginación de 20 por página.
3. El docente selecciona una solicitud y accede a "Ver detalle".
4. El sistema muestra los datos completos: estudiante, asignatura, tema, modalidad, tipo, franja propuesta y adjuntos si los hay.
5. El docente presiona "Aceptar".
6. El sistema (SPA) solicita confirmación con diálogo modal: "¿Confirma aceptar esta tutoría? Se notificará al estudiante".
7. El docente confirma.
8. La SPA envía `PATCH /solicitudes/<uuid>` con cuerpo `{"accion": "ACEPTAR"}`.
9. El backend valida el JWT del docente y su rol.
10. El backend valida que la solicitud está en estado `PENDIENTE` y pertenece al docente.
11. El backend actualiza el estado a `ACEPTADA` con `fecha_decision = now()`.
12. El backend registra el evento en `auditoria_evento`.
13. El backend encola la notificación al estudiante.
14. El backend responde HTTP 200 con la solicitud actualizada.
15. La SPA actualiza la vista y muestra el mensaje verde "Solicitud aceptada. El estudiante ha sido notificado".

## Escenarios alternativos

### 5a — Docente elige rechazar

1. El docente presiona "Rechazar" en lugar de "Aceptar".
2. El sistema muestra un formulario modal con:
   - Campo obligatorio "Motivo del rechazo" (mínimo 20 caracteres).
   - Campo opcional "Sugerencias" (para orientar al estudiante).
3. El docente completa y presiona "Confirmar rechazo".
4. La SPA envía `PATCH /solicitudes/<uuid>` con cuerpo `{"accion": "RECHAZAR", "motivo": "...", "sugerencias": "..."}`.
5. El backend valida que el motivo no está vacío y tiene al menos 20 caracteres.
6. El backend actualiza el estado a `RECHAZADA`.
7. Continúa como el escenario principal desde el paso 12.

### 5b — Docente elige reprogramar

1. El docente presiona "Reprogramar" en lugar de "Aceptar".
2. El sistema muestra el calendario del docente con las franjas disponibles.
3. El docente selecciona hasta 3 franjas alternativas para proponer al estudiante.
4. El docente añade un motivo obligatorio de la reprogramación.
5. La SPA envía `PATCH /solicitudes/<uuid>` con `{"accion": "REPROGRAMAR", "franjas_propuestas": [...], "motivo": "..."}`.
6. El backend valida las franjas propuestas.
7. El backend actualiza el estado original a `REPROGRAMADA` y crea una nueva solicitud vinculada con estado `PENDIENTE_CONFIRMACION_ESTUDIANTE`.
8. Continúa como el escenario principal desde el paso 12.

### 5c — Aceptación con nota interna

1. El docente presiona "Aceptar con nota".
2. El sistema muestra un formulario opcional para nota interna visible solo para el docente (no se envía al estudiante).
3. El docente completa y confirma.
4. Se sigue el escenario principal, guardando la nota en el campo `nota_interna_docente`.

## Escenarios de excepción

### E1 — Solicitud ya procesada

- El docente intenta aceptar/rechazar una solicitud cuyo estado ya no es `PENDIENTE` (otro docente titular la procesó, o el estudiante la canceló).
- El backend responde HTTP 409 (Conflict) con `application/problem+json` explicando el estado actual.
- La SPA muestra: "Esta solicitud ya fue procesada (estado actual: <estado>). Recargue la vista para ver el estado actualizado."

### E2 — Sesión expirada durante el proceso

- El JWT del docente expira mientras completa el formulario de rechazo.
- La SPA intercepta el 401 y solicita renovación silenciosa.
- Si la renovación falla, la SPA guarda el formulario en `sessionStorage` y redirige al login.
- Tras autenticarse, la SPA restaura el formulario y permite reenviarlo.

### E3 — Notificación al estudiante falla

- El backend actualiza el estado exitosamente pero la notificación por correo falla (SMTP indisponible).
- La actualización se conserva.
- El evento se encola para reintento hasta 5 veces con backoff exponencial.
- El evento se registra con marca `notificacion_pendiente=true`.

## Reglas de negocio aplicables

- **RN-05**: El motivo de rechazo debe tener al menos 20 caracteres para forzar retroalimentación útil al estudiante.
- **RN-06**: Un docente solo puede procesar solicitudes que fueron dirigidas a él o a las asignaturas que dicta.
- **RN-07**: Una solicitud aceptada no puede pasar directamente a rechazada; el docente debe usar el flujo de cancelación (futuro CU).
- **RN-08**: La reprogramación no puede proponer franjas menores a 24 horas en el futuro.

## Requisitos especiales

- **Rendimiento**: la operación de aceptación simple debe completarse en $p_{95} \leq 300$ ms.
- **Seguridad**: el cambio de estado debe registrarse en auditoría con el hash de la cédula del docente y su IP (RNF-08).
- **Concurrencia**: la actualización usa bloqueo optimista con la columna `version` (JPA `@Version`) para evitar sobrescrituras cruzadas si dos pestañas del docente actúan sobre la misma solicitud.

## Notas de análisis

La reprogramación fue identificada por los docentes entrevistados (ver `docs/observaciones/OBSERVACIONES.md` de la Entrega 2) como la funcionalidad más solicitada tras las tres operaciones básicas (aceptar, rechazar, registrar). Se prevé que representará hasta el 20 % de las acciones sobre solicitudes en producción.

El diseño con creación de nueva solicitud vinculada (en lugar de mutar la existente) preserva la trazabilidad histórica y permite reportes precisos sobre cuántas tutorías se reprograman por docente y por asignatura.
