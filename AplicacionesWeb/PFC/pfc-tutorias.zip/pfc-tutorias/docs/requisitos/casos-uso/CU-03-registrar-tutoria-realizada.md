# CU-03 — Registrar tutoría realizada

## Metadatos

| Campo | Valor |
|-------|-------|
| **Identificador** | CU-03 |
| **Nombre** | Registrar tutoría realizada |
| **Actor principal** | Docente |
| **Actores secundarios** | Estudiante(s) participante(s), Coordinación académica (consulta posterior en reportes) |
| **Requisitos trazados** | RF-04, RF-05, RF-11, RF-17 |
| **Historia trazada** | HU-02 |
| **Prioridad MoSCoW / Kano** | Must / Imprescindible |
| **Complejidad estimada** | Baja |
| **Frecuencia esperada** | Alta (una por cada sesión aceptada) |

## Precondiciones

- El docente está autenticado.
- Existe al menos una solicitud del docente en estado `ACEPTADA` cuya fecha planificada ya transcurrió.
- La tutoría aún no está registrada como realizada.

## Postcondiciones

**De éxito**:

- La solicitud pasa a estado `REALIZADA` con marca temporal.
- Se persiste el registro detallado en la tabla `sesion_tutoria` con: duración real, asistentes efectivos, temas cubiertos, observaciones, adjuntos.
- Se registra evento `TUTORIA_REGISTRADA` en `auditoria_evento`.
- Los estudiantes reciben notificación con enlace opcional para evaluar la tutoría (funcionalidad futura, Entrega 2+).

**De fallo**:

- No se modifica el estado de la solicitud original.
- Se responde al docente con mensaje explicativo del motivo.

## Escenario principal

1. El docente accede a "Tutorías pendientes de registro" desde el menú.
2. El sistema muestra las tutorías `ACEPTADA` cuya fecha ya pasó y no han sido registradas.
3. El docente selecciona una y accede a "Registrar sesión realizada".
4. El sistema muestra un formulario prellenado con datos de la solicitud (asignatura, estudiante(s), franja original) y campos a completar por el docente:
   - Duración real de la sesión (en minutos, sugerido igual a la duración planificada).
   - Lista de asistentes (marcada por defecto con el estudiante que solicitó; el docente marca/desmarca a los presentes).
   - Temas efectivamente cubiertos (texto libre, mínimo 20 caracteres).
   - Observaciones del docente (texto libre opcional, máximo 2000 caracteres).
   - Adjuntos opcionales (materiales usados, hasta 3 archivos PDF de 10 MiB cada uno).
5. El docente completa los campos.
6. El docente presiona "Guardar".
7. La SPA valida cliente-side los campos obligatorios.
8. La SPA envía `POST /solicitudes/<uuid>/sesion` con el cuerpo del formulario.
9. El backend valida JWT y rol.
10. El backend valida que la solicitud está en estado `ACEPTADA` y pertenece al docente.
11. El backend valida que no existe ya una sesión registrada para esa solicitud.
12. El backend persiste el registro en `sesion_tutoria` (transacción con actualización del estado de la solicitud a `REALIZADA`).
13. El backend encola notificaciones para los estudiantes marcados como asistentes.
14. El backend registra el evento en `auditoria_evento`.
15. El backend responde HTTP 201 con el registro creado.
16. La SPA muestra confirmación verde "Sesión registrada. Estudiantes notificados".

## Escenarios alternativos

### 4a — Docente marca tutoría como no realizada

1. En el formulario el docente marca la casilla "Tutoría no se realizó".
2. El sistema exige motivo obligatorio (mínimo 20 caracteres).
3. El docente indica el motivo (por ejemplo, "estudiante no asistió sin aviso previo").
4. La SPA envía `POST /solicitudes/<uuid>/sesion` con `{"realizada": false, "motivo": "..."}`.
5. El backend cambia el estado de la solicitud a `NO_REALIZADA` con el motivo.
6. Continúa como el escenario principal desde el paso 13.

### 5a — Docente registra parcialmente (tutoría grupal con inasistencias)

1. En una tutoría grupal el docente desmarca a algunos estudiantes que no asistieron.
2. El sistema calcula automáticamente el porcentaje de asistencia y lo muestra.
3. Continúa como el escenario principal desde el paso 6.

## Escenarios de excepción

### E1 — Fecha de la tutoría todavía no ha pasado

- El docente intenta registrar una tutoría cuya fecha planificada aún no llegó.
- El backend responde HTTP 400 con `application/problem+json` explicando la restricción temporal.

### E2 — Tutoría ya registrada

- El docente intenta registrar dos veces la misma tutoría (por ejemplo, doble clic).
- El backend detecta la existencia previa y responde HTTP 409 (Conflict) con enlace al registro existente.

### E3 — Adjuntos exceden tamaño total

- El docente sube 4 archivos que suman más de 30 MiB.
- La SPA rechaza cliente-side sin enviar al backend.

## Reglas de negocio aplicables

- **RN-09**: La duración real registrada no puede ser superior al doble de la duración planificada; si lo es, se solicita justificación explícita.
- **RN-10**: Los temas cubiertos deben ser distintos de la cadena vacía o de placeholders como "N/A" (validación léxica básica).
- **RN-11**: El registro solo puede hacerse dentro de los 7 días siguientes a la fecha planificada; después de ese plazo, el registro requiere autorización de la coordinación (flujo excepcional futuro).

## Requisitos especiales

- **Rendimiento**: la operación completa debe completarse en $p_{95} \leq 500$ ms (incluye subida de adjuntos hasta 10 MiB).
- **Almacenamiento**: los adjuntos se almacenan en el sistema de archivos del contenedor con volumen Docker persistente, con nombre generado como `<uuid>_<hash-sha256-corto>.<ext>` para evitar colisiones y filtrado por nombre original.
- **Seguridad**: los adjuntos se validan por tipo MIME real (usando magic bytes, no solo extensión) para prevenir subida de ejecutables enmascarados como PDF (mitigación OWASP A03).

## Notas de análisis

Este caso de uso alimenta directamente los reportes institucionales y por docente. La calidad de los datos capturados aquí determina la utilidad de los reportes del CU-05.

Se recomienda que la SPA prellene tantos campos como sea posible (duración = franja planificada, asistentes = estudiantes solicitantes) para reducir la fricción y aumentar la tasa de registro efectivo. En sistemas similares (Rojas et al., 2023) se documentan tasas de registro por debajo del 60 % cuando el formulario requiere entrada manual completa.

## Referencias

- Rojas Cabrera, F. et al. (2023). Sistema web para la gestión de tutorías en EPIS-UNH. *Referencia consultada en el corpus base*.
