# CU-01 — Registrar solicitud de tutoría

## Metadatos

| Campo | Valor |
|-------|-------|
| **Identificador** | CU-01 |
| **Nombre** | Registrar solicitud de tutoría |
| **Actor principal** | Estudiante |
| **Actores secundarios** | Docente (destinatario de la notificación), SGA UTEQ (validador de asignaturas activas), Servidor SMTP (envío de notificación) |
| **Requisitos trazados** | RF-01, RF-09, RF-12, RF-14, RF-16 |
| **Historia trazada** | HU-06 |
| **Prioridad MoSCoW / Kano** | Must / Imprescindible |
| **Nivel Cockburn** | Objetivo de usuario (*user goal*) |
| **Alcance** | Sistema completo de tutorías UTEQ |
| **Complejidad estimada** | Media |
| **Frecuencia esperada** | Alta (diaria durante horario académico) |

## Precondiciones

- El estudiante está autenticado en el sistema con credenciales válidas (ver CU de autenticación, futuro CU-06).
- El estudiante tiene al menos una asignatura activa registrada en el SGA en el ciclo académico en curso.
- Existe al menos un docente con disponibilidad configurada para la(s) asignatura(s) del estudiante.

## Postcondiciones

**De éxito**:

- La solicitud queda registrada con estado `PENDIENTE` en la tabla `solicitud_tutoria`.
- Se genera un identificador único de solicitud (UUID v4) que se retorna al estudiante.
- Se envía una notificación al docente por su canal configurado (correo institucional por defecto).
- Se registra un evento de auditoría en `auditoria_evento` con tipo `SOLICITUD_CREADA`.

**De fallo**:

- No se crea ningún registro persistente en la base de datos.
- Se responde al estudiante con un mensaje explicativo del motivo del fallo en formato RFC 7807 *Problem Details*.
- Se registra un evento de auditoría con tipo `SOLICITUD_RECHAZADA_VALIDACION` y el motivo específico.

## Escenario principal (camino feliz)

1. El estudiante accede al menú principal y selecciona "Nueva solicitud de tutoría".
2. El sistema muestra el formulario con los campos: asignatura (lista desplegable poblada dinámicamente desde el SGA), tema o motivo (texto libre, máximo 500 caracteres), modalidad (individual o grupal, según disponibilidad del docente), tipo (presencial o virtual), franja horaria preferida (calendario) y archivo adjunto opcional (PDF hasta 10 MiB).
3. El estudiante completa los campos y presiona "Enviar".
4. El sistema valida cliente-side los campos obligatorios (asignatura, tema, modalidad, tipo, franja).
5. El sistema envía la solicitud al backend con `POST /solicitudes`.
6. El backend valida la sesión JWT del estudiante y su rol.
7. El backend valida contra el SGA que la asignatura está activa en el ciclo académico vigente.
8. El backend valida que el docente asignado a la asignatura tiene la franja horaria disponible.
9. El backend persiste el registro en `solicitud_tutoria` con estado `PENDIENTE` y genera un UUID v4.
10. El backend registra el evento en `auditoria_evento`.
11. El backend encola la notificación al docente en la cola de correo.
12. El backend responde HTTP 201 con `{"id": "<uuid>", "estado": "PENDIENTE"}` y cabecera `Location: /solicitudes/<uuid>`.
13. El sistema (SPA) redirige al estudiante a la vista "Mis solicitudes" con un mensaje verde: "Solicitud registrada exitosamente. El docente recibirá notificación por su canal preferido."

## Escenarios alternativos

### 4a — Campo obligatorio vacío

1. El estudiante presiona "Enviar" sin completar todos los campos obligatorios.
2. El sistema (SPA) resalta los campos faltantes con borde rojo y muestra el mensaje "Este campo es obligatorio" debajo de cada uno.
3. No se envía nada al backend.
4. El escenario retorna al paso 3 del escenario principal.

### 7a — Asignatura no activa en el ciclo académico

1. El backend consulta al SGA y confirma que la asignatura seleccionada no está activa en el ciclo académico vigente para el estudiante.
2. El backend responde HTTP 400 con `application/problem+json`:
   ```json
   {
     "type": "https://uteq.edu.ec/errores/asignatura-no-activa",
     "title": "Asignatura no activa",
     "status": 400,
     "detail": "La asignatura <codigo> no esta activa en el ciclo academico vigente para el estudiante <cedula>",
     "instance": "/solicitudes"
   }
   ```
3. La SPA muestra el error al estudiante con acción sugerida: "Verifique en el SGA su matrícula del ciclo actual".
4. El escenario finaliza sin persistir nada.

### 8a — Franja horaria no disponible

1. El backend valida que la franja horaria propuesta ya está ocupada por otra tutoría del mismo docente.
2. El backend responde HTTP 409 (Conflict) con `application/problem+json` explicando el conflicto y proponiendo hasta tres franjas alternativas.
3. La SPA muestra las franjas alternativas al estudiante para que reelija.
4. El escenario retorna al paso 4 del escenario principal.

### 11a — Fallo temporal del servicio SMTP

1. El servidor SMTP institucional no está disponible al momento de encolar la notificación.
2. El backend persiste igualmente la solicitud con estado `PENDIENTE`.
3. El backend encola la notificación en cola de reintento (Redis, hasta 5 reintentos con backoff exponencial).
4. El backend responde HTTP 201 al estudiante (la solicitud queda registrada).
5. El evento se registra con marca `notificacion_pendiente=true` en `auditoria_evento`.

## Escenarios de excepción

### E1 — Sesión JWT expirada

- El backend detecta que el JWT ha expirado o es inválido.
- Responde HTTP 401 con `WWW-Authenticate: Bearer error="invalid_token"`.
- La SPA intercepta el 401, intenta renovación silenciosa con el `refresh token` (implementado en Entrega 2). Si falla, redirige al login.

### E2 — SGA institucional no accesible

- El backend intenta consultar al SGA para validar la asignatura y recibe timeout tras 3 segundos.
- El backend activa el patrón *Circuit Breaker* (Resilience4j 2.x), abre el circuito y responde HTTP 503 con `application/problem+json`.
- La SPA muestra al estudiante: "El sistema académico (SGA) está temporalmente no disponible. Reintente en unos minutos".
- Se registra el evento en `auditoria_evento` con tipo `SGA_INDISPONIBLE`.

### E3 — Archivo adjunto excede tamaño máximo

- El estudiante intenta subir un adjunto mayor a 10 MiB.
- La SPA rechaza cliente-side sin enviar al backend, mostrando el mensaje "El archivo excede el tamaño máximo permitido (10 MiB)".

## Reglas de negocio aplicables

- **RN-01**: El tema de la solicitud debe tener entre 10 y 500 caracteres.
- **RN-02**: Solo se permiten adjuntos en formato PDF, DOCX u ODT.
- **RN-03**: La franja horaria propuesta debe estar al menos 24 horas en el futuro respecto al momento de la solicitud.
- **RN-04**: Un estudiante no puede tener más de 5 solicitudes en estado `PENDIENTE` simultáneamente.

## Requisitos especiales

- **Rendimiento**: la operación completa (paso 3 a paso 13) debe completarse en $p_{95} \leq 300$ ms bajo carga esperada (véase RNF-01).
- **Seguridad**: el cuerpo del `POST` debe validarse contra un esquema JSON estricto para prevenir inyección (RNF-03).
- **Auditoría**: el evento debe registrarse en `auditoria_evento` con marca temporal, hash del cédula del estudiante, IP de origen y resultado (RNF-08).

## Frecuencia de ocurrencia

Se estima entre 30 y 80 solicitudes por día durante días académicos regulares, con picos de hasta 150 solicitudes durante las semanas previas a evaluaciones parciales o finales.

## Notas de análisis

Este caso de uso es el flujo central del sistema y su calidad determina la percepción global del estudiante. La priorización Kano lo clasifica como **imprescindible** (insatisfactor): su ausencia o mal funcionamiento genera insatisfacción inmediata, pero su existencia impecable no genera satisfacción por encima de lo esperado.

Se recomienda implementar este caso de uso al inicio de la Entrega 2 (semana 7 del calendario académico) para permitir su prueba temprana con estudiantes voluntarios en las semanas 10-11.
