# CU-04 — Consultar estado de solicitudes

## Metadatos

| Campo | Valor |
|-------|-------|
| **Identificador** | CU-04 |
| **Nombre** | Consultar estado de solicitudes |
| **Actor principal** | Estudiante |
| **Actores secundarios** | (Ninguno) |
| **Requisitos trazados** | RF-06, RF-11 |
| **Historia trazada** | HU-01, HU-11 |
| **Prioridad MoSCoW / Kano** | Must / Imprescindible |
| **Nivel Cockburn** | Objetivo de usuario |
| **Complejidad estimada** | Baja |
| **Frecuencia esperada** | Muy alta (consultas repetidas por el mismo usuario) |

## Precondiciones

- El estudiante está autenticado en el sistema con credenciales válidas.
- El estudiante tiene al menos una solicitud registrada previamente (activa o histórica).

## Postcondiciones

**De éxito**:

- El estudiante visualiza la lista de sus solicitudes con el estado actualizado al momento de la consulta.
- Cada solicitud muestra: identificador corto, asignatura, docente, fecha de solicitud, fecha planificada, estado actual y canal de notificación.
- Se registra evento `CONSULTA_ESTADO` en `auditoria_evento` únicamente cuando la consulta se hace desde la SPA (no cuando es un polling automático) para evitar inflación de la tabla de auditoría.

**De fallo**:

- Se responde con mensaje explicativo en formato RFC 7807 sin exponer detalles internos.

## Escenario principal (camino feliz)

1. El estudiante accede a la SPA y selecciona "Mis solicitudes" en el menú lateral.
2. La SPA envía `GET /solicitudes/mias?page=0&size=20&sort=fechaSolicitud,desc` con el JWT del estudiante.
3. El backend valida el JWT y extrae el `sub` (identificador del estudiante).
4. El backend consulta la vista materializada `v_solicitudes_estudiante` filtrando por `estudiante_id = sub`.
5. El backend construye la respuesta HTTP 200 con el arreglo paginado en JSON, incluyendo cabeceras `X-Total-Count` y `Link` (RFC 8288) para paginación.
6. La SPA renderiza la tabla con las columnas: identificador corto, asignatura, docente, fecha planificada, estado y una etiqueta de color (verde `ACEPTADA`, amarillo `PENDIENTE`, rojo `RECHAZADA`, azul `REALIZADA`, gris `CANCELADA`).
7. La SPA muestra el conteo total en el encabezado "Mostrando 20 de N solicitudes".
8. El estudiante puede filtrar por estado usando los chips visibles en la parte superior.
9. El estudiante puede refrescar la vista con el botón "Actualizar" o esperar la actualización automática cada 30 segundos.

## Escenarios alternativos

### 8a — Filtrado por estado

1. El estudiante presiona el chip "PENDIENTE".
2. La SPA reenvía la solicitud con `GET /solicitudes/mias?page=0&size=20&estado=PENDIENTE`.
3. Continúa como el escenario principal desde el paso 3, filtrando por estado.

### 8b — Búsqueda por asignatura

1. El estudiante escribe en la caja de búsqueda el nombre parcial de la asignatura.
2. Tras 400 ms de inactividad (debounce), la SPA envía `GET /solicitudes/mias?asignaturaLike=<term>`.
3. Continúa como el escenario principal desde el paso 3, con el filtro adicional.

### 9a — Consulta de detalle de una solicitud

1. El estudiante presiona sobre una fila de la tabla.
2. La SPA envía `GET /solicitudes/<uuid>` para obtener el detalle completo.
3. El backend valida que la solicitud pertenece al estudiante (control OWASP A01: Broken Access Control).
4. El backend responde con la solicitud incluyendo bitácora completa de cambios de estado.
5. La SPA muestra un panel lateral con el detalle: adjuntos, motivo (si aplica), timeline de cambios de estado con marca temporal e iniciador.

## Escenarios de excepción

### E1 — Ninguna solicitud registrada aún

- El backend responde HTTP 200 con arreglo vacío `[]` y `X-Total-Count: 0`.
- La SPA muestra un estado vacío con ilustración amable y el mensaje "Aún no has registrado ninguna solicitud" y un botón CTA "Registrar mi primera solicitud" que redirige al CU-01.

### E2 — Sesión JWT expirada

- El backend responde HTTP 401.
- La SPA intercepta y solicita renovación silenciosa mediante el `refresh token`.
- Si la renovación falla, redirige al login preservando el destino en `sessionStorage.returnTo` para redirigir de vuelta tras autenticarse.

### E3 — Solicitud de detalle sobre solicitud ajena

- El estudiante manipula la URL para consultar `GET /solicitudes/<uuid>` de otro estudiante.
- El backend detecta el intento y responde HTTP 404 (no HTTP 403, para no revelar la existencia del recurso; mitigación OWASP A01).
- Se registra evento `ACCESO_NO_AUTORIZADO` en `auditoria_evento` con severidad `WARN`.

### E4 — Backend temporalmente lento

- La consulta demora más de 5 segundos.
- La SPA muestra un *skeleton loader* animado y no bloquea la interfaz.
- Si supera los 15 segundos, la SPA aborta la petición y muestra: "La consulta demora más de lo esperado. Verifique su conexión o reintente".

## Reglas de negocio aplicables

- **RN-12**: El listado por defecto ordena por `fechaSolicitud` descendente (las más recientes arriba).
- **RN-13**: El tamaño de página por defecto es 20; los valores permitidos son 10, 20, 50 y 100.
- **RN-14**: Los estados históricos (`REALIZADA`, `RECHAZADA`, `CANCELADA`) están visibles pero se pueden ocultar con el filtro "Solo activas".

## Requisitos especiales

- **Rendimiento**: la consulta paginada de 20 solicitudes debe responder en $p_{95} \leq 200$ ms bajo carga esperada de 50 usuarios concurrentes (véase RNF-01).
- **Escalabilidad**: se usa una vista materializada `v_solicitudes_estudiante` refrescada por trigger tras cada `INSERT` o `UPDATE` sobre `solicitud_tutoria` para evitar los `JOIN` en cada consulta interactiva.
- **Seguridad**: cada consulta valida que el `sub` del JWT coincide con el propietario de las solicitudes retornadas (mitigación OWASP A01: Broken Access Control).
- **Cache**: la SPA cachea el resultado en memoria (RxJS `shareReplay(1)`) durante 30 segundos para evitar peticiones redundantes por navegación.

## Frecuencia de ocurrencia

Cada estudiante activo consulta esta vista entre 3 y 8 veces por día durante períodos académicos regulares, con picos de hasta 20 consultas por día durante semanas de evaluación. Con 400 estudiantes activos estimados se prevén entre 1200 y 3200 consultas diarias.

## Notas de análisis

Este caso de uso es de solo lectura y por su alta frecuencia se convierte en el candidato natural para las optimizaciones agresivas de cache. Se recomienda que en la Entrega 3 se instrumente con métricas Prometheus (`http_requests_seconds{route="/solicitudes/mias"}`) para monitorear el percentil 95 y detectar regresiones tempranamente.

La actualización automática cada 30 segundos (paso 9) es una decisión de UX que reduce la necesidad de que el estudiante refresque manualmente la vista tras interactuar con el docente por otro canal (por ejemplo, tras recibir un correo). En pruebas de usabilidad tempranas se recomienda validar que esta frecuencia no sea percibida como intrusiva ni consuma excesivos recursos del dispositivo.
