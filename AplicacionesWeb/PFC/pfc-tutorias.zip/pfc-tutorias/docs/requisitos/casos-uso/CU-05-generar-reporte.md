# CU-05 — Generar reporte institucional

## Metadatos

| Campo | Valor |
|-------|-------|
| **Identificador** | CU-05 |
| **Nombre** | Generar reporte institucional |
| **Actor principal** | Coordinación académica |
| **Actores secundarios** | Docente (fuente de datos), Estudiante (fuente de datos), SGA UTEQ (para contextualización de asignaturas) |
| **Requisitos trazados** | RF-07, RF-08, RF-23, RF-24, RF-26 |
| **Historia trazada** | HU-03, HU-10 |
| **Prioridad MoSCoW / Kano** | Should / Imprescindible para coordinación |
| **Nivel Cockburn** | Objetivo de usuario |
| **Complejidad estimada** | Alta |
| **Frecuencia esperada** | Media (semanal a mensual por coordinador) |

## Precondiciones

- El coordinador está autenticado con rol `COORDINACION` en el sistema.
- Existen tutorías registradas (estados `REALIZADA`, `NO_REALIZADA`, `RECHAZADA`) en el período consultado.
- El catálogo de asignaturas activas está sincronizado con el SGA.

## Postcondiciones

**De éxito**:

- El coordinador visualiza el reporte agregado con los filtros aplicados.
- Los indicadores agregados se calculan mediante procedimiento almacenado `sp_reporte_institucional_generar` (conforme al ADR-004).
- Si se solicita exportación, el sistema genera el archivo PDF o Excel y lo entrega para descarga.
- Se registra evento `REPORTE_GENERADO` en `auditoria_evento` con los filtros aplicados.

**De fallo**:

- Se responde con mensaje explicativo en formato RFC 7807.
- El reporte parcialmente generado no se persiste.

## Escenario principal (camino feliz)

1. El coordinador accede a "Panel de reportes" desde el menú principal.
2. El sistema muestra el formulario de filtros con:
   - Período académico (obligatorio, valor por defecto: ciclo académico vigente).
   - Rango de fechas (opcional, si se omite se toma el período académico completo).
   - Carrera (multi-selección, por defecto todas las carreras a las que el coordinador tiene acceso).
   - Asignatura (multi-selección, filtrada dinámicamente por las carreras elegidas).
   - Docente (multi-selección, opcional).
   - Modalidad (individual, grupal, o ambas).
   - Tipo de sesión (presencial, virtual, o ambas).
3. El coordinador aplica los filtros y presiona "Generar reporte".
4. La SPA envía `POST /reportes/institucional` con los filtros en el cuerpo JSON.
5. El backend valida el JWT y el rol `COORDINACION`.
6. El backend valida los filtros contra el esquema JSON estricto.
7. El backend invoca el procedimiento almacenado `sp_reporte_institucional_generar(filtros JSONB)` en PostgreSQL, que retorna una tabla con los indicadores agregados.
8. El backend construye la respuesta JSON con la estructura:
   ```json
   {
     "resumen": {
       "solicitudes_totales": N, "aceptadas": N, "rechazadas": N,
       "realizadas": N, "no_realizadas": N,
       "tasa_aceptacion": 0.85, "tasa_realizacion": 0.92,
       "duracion_promedio_min": 47.3
     },
     "por_carrera": [ {...} ],
     "por_asignatura": [ {...} ],
     "por_docente": [ {...} ],
     "por_semana": [ {...} ],
     "meta": { "generado_en": "2026-...", "filtros_aplicados": {...} }
   }
   ```
9. El backend responde HTTP 200 con el JSON.
10. La SPA renderiza el reporte con cuatro secciones visibles: KPIs resumen (tarjetas grandes), gráfico de barras por carrera, tabla ordenable por asignatura, y serie temporal por semana.
11. El coordinador puede: (a) filtrar interactivamente sin llamar de nuevo al backend (filtros aplicados en el cliente sobre el JSON), o (b) presionar "Exportar PDF" o "Exportar Excel".

## Escenarios alternativos

### 11a — Exportar como PDF

1. El coordinador presiona "Exportar PDF".
2. La SPA envía `POST /reportes/institucional/pdf` con los filtros y el resultado ya obtenido.
3. El backend genera el PDF con Apache PDFBox 3.x usando la plantilla institucional (encabezado con logo UTEQ, colores verde `#006633` y dorado `#CC9900`, pie con paginación y fecha).
4. El backend responde HTTP 200 con `Content-Type: application/pdf` y `Content-Disposition: attachment; filename="reporte-institucional-<fecha>.pdf"`.
5. La SPA dispara la descarga automática del archivo.

### 11b — Exportar como Excel

1. El coordinador presiona "Exportar Excel".
2. La SPA envía `POST /reportes/institucional/xlsx`.
3. El backend genera el archivo `.xlsx` con Apache POI 5.x, incluyendo cuatro hojas: `Resumen`, `Por asignatura`, `Por docente`, `Serie temporal`.
4. El backend responde HTTP 200 con `Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`.
5. La SPA dispara la descarga.

### 3a — Filtros muy restrictivos

1. Los filtros aplicados no retornan datos (por ejemplo, un docente sin tutorías registradas en el período).
2. El backend responde HTTP 200 con la estructura completa pero con todos los agregados en cero.
3. La SPA muestra un estado vacío con el mensaje "Los filtros aplicados no arrojaron resultados. Ajuste los filtros e intente de nuevo".

## Escenarios de excepción

### E1 — Sin permisos para la carrera solicitada

- El coordinador intenta consultar una carrera fuera de su ámbito de autoridad.
- El backend responde HTTP 403 (Forbidden) con `application/problem+json` explicando la restricción.
- Se registra evento `ACCESO_NO_AUTORIZADO_REPORTE` en auditoría.

### E2 — Timeout en el procedimiento almacenado

- El procedimiento excede 30 segundos de ejecución (típicamente por filtros muy amplios sobre grandes volúmenes históricos).
- El backend cancela la consulta con `SET statement_timeout = 30000` a nivel de sesión JDBC.
- Responde HTTP 504 (Gateway Timeout) con `application/problem+json` sugiriendo restringir los filtros.
- Se registra evento `REPORTE_TIMEOUT` con los filtros que provocaron la falla para análisis posterior.

### E3 — Generación de PDF/Excel falla

- La generación del archivo binario falla por error interno (memoria insuficiente, plantilla corrupta).
- El backend responde HTTP 500 con `application/problem+json` sin exponer detalles internos.
- El error completo se registra en el log estructurado del backend.
- Se registra evento `REPORTE_EXPORTACION_FALLIDA` en auditoría.

### E4 — Backend cae durante la generación

- El proceso del backend se reinicia durante la generación de un reporte.
- El JSON parcial no se persiste (la operación es idempotente).
- El coordinador reintenta desde la SPA sin efectos secundarios.

## Reglas de negocio aplicables

- **RN-15**: Los reportes solo consideran tutorías con estado `REALIZADA` para las métricas de duración y asistencia efectiva; los estados `PENDIENTE` y `ACEPTADA` se incluyen únicamente en la métrica de solicitudes totales.
- **RN-16**: La tasa de aceptación se calcula como `(aceptadas + realizadas) / (solicitudes_totales - canceladas)`.
- **RN-17**: La duración promedio se calcula solo sobre tutorías con `duracion_real` no nula.
- **RN-18**: Los reportes exportados llevan el sello de agua "Reporte generado por <coordinador> el <fecha> — Universidad Técnica Estatal de Quevedo" para trazabilidad.

## Requisitos especiales

- **Rendimiento**: el reporte agregado sobre hasta 5000 registros debe completarse en $p_{95} \leq 5$ segundos (véase HU-03). La exportación a PDF/Excel puede tomar hasta 15 segundos adicionales.
- **Consistencia**: los reportes reflejan el estado de la base de datos al momento de la consulta (lectura no repetible aceptada); no se garantiza que dos reportes generados en momentos diferentes coincidan si hubo actualizaciones intermedias.
- **Seguridad**: el procedimiento almacenado usa parámetros nominales (`filtros JSONB`) y no permite construcción dinámica de SQL, cumpliendo la restricción del ADR-004 y mitigando OWASP A03 (Injection).
- **Trazabilidad**: cada exportación queda registrada en `auditoria_evento` con el hash del identificador del coordinador, los filtros aplicados y el formato exportado, cumpliendo RNF-08.

## Frecuencia de ocurrencia

Se estima entre 5 y 15 generaciones de reporte por semana por coordinador durante períodos académicos regulares, con picos de hasta 40 generaciones durante las semanas de cierre de ciclo (semana 20 y semana 32 del calendario académico).

## Notas de análisis

La complejidad de este caso de uso es alta por tres factores: (1) la cantidad de dimensiones de filtrado, (2) la necesidad de agregaciones eficientes sobre volúmenes crecientes de datos históricos, y (3) la exigencia de exportación a formatos institucionales.

La implementación mediante procedimiento almacenado (ADR-004) es especialmente adecuada aquí porque las agregaciones se calculan en el motor con acceso directo a los datos, sin transferir volúmenes intermedios al backend. Esta decisión debe validarse empíricamente en la Entrega 3 con pruebas de rendimiento sobre datos sintéticos de al menos 50 000 solicitudes.

Se recomienda cachear los reportes generados por 15 minutos en Redis usando como clave el hash SHA-256 de los filtros aplicados, para que consultas repetidas del mismo reporte por diferentes navegadores del mismo coordinador se sirvan desde el cache. La invalidación se dispara automáticamente al llegar nuevos eventos de tipo `TUTORIA_REGISTRADA`, `SOLICITUD_ACEPTADA` o similares.
