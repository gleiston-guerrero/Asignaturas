# Catálogo de Requisitos No Funcionales — Sistema de Tutorías UTEQ

**Versión**: `v0.3.0` (Entrega 1)
**Norma base**: ISO/IEC 25010:2011 — Systems and software Quality Requirements and Evaluation (SQuaRE), característica de calidad "Quality in Use" y "Product Quality".
**Norma de redacción**: ISO/IEC/IEEE 29148:2018, cláusula 9.5.4.

Cada RNF declara: (i) categoría ISO/IEC 25010, (ii) descripción operacional, (iii) métrica cuantitativa, (iv) instrumento de medición previsto y (v) umbral de aceptación. Los RNF sin métrica se rechazan.

---

## RNF-01 — Latencia de operaciones interactivas (Eficiencia · Comportamiento temporal)

- **Categoría ISO/IEC 25010**: Performance efficiency · Time behaviour
- **Descripción operacional**: El tiempo de respuesta del percentil 95 (p95) de las operaciones interactivas del sistema (registro de solicitud, aceptación, consulta de historial paginado, generación de reporte con hasta 100 registros) debe mantenerse por debajo del umbral bajo carga esperada de 50 usuarios concurrentes.
- **Métrica**: $p_{95}(t_{\text{respuesta}}) \leq 300$ ms
- **Instrumento**: k6 (grafana/k6:latest) con escenario de carga estable durante 5 minutos, midiendo desde la SPA hasta la respuesta completa incluyendo TLS.
- **Umbral de aceptación**: Excelente $\leq 200$ ms; Bueno $\leq 300$ ms; En desarrollo $\leq 500$ ms; Insuficiente $> 500$ ms.

---

## RNF-02 — Disponibilidad del sistema (Confiabilidad · Disponibilidad)

- **Categoría ISO/IEC 25010**: Reliability · Availability
- **Descripción operacional**: El sistema debe estar disponible al menos el 99.5 % del tiempo durante el horario académico institucional, medido como tiempo total disponible sobre tiempo total en ventana de servicio.
- **Métrica**: $\text{Disponibilidad} = \dfrac{T_{\text{up}}}{T_{\text{total}}} \geq 99.5\,\%$ en ventana lunes-viernes 06:00-22:00 hora Ecuador durante un semestre académico completo.
- **Instrumento**: Prometheus 2.x + Grafana con exportador de Spring Boot Actuator; alerta automática por indisponibilidad superior a 3 minutos consecutivos.
- **Umbral de aceptación**: Excelente $\geq 99.9\,\%$; Bueno $\geq 99.5\,\%$; En desarrollo $\geq 99.0\,\%$; Insuficiente $< 99.0\,\%$.

---

## RNF-03 — Seguridad de autenticación y autorización (Seguridad · Confidencialidad e Integridad)

- **Categoría ISO/IEC 25010**: Security · Confidentiality + Integrity + Authenticity
- **Descripción operacional**: Todas las operaciones que modifican estado deben requerir autenticación por JWT firmado con HS256 y clave de al menos 256 bits (RFC 7519). Los tokens deben transportarse por cookie `HttpOnly + Secure + SameSite=Strict`. Los intentos de autorización deben ser auditados con hash de identificador de usuario, fecha, IP y resultado.
- **Métrica**: Conformidad con OWASP Top 10:2021 controles A01, A02, A03, A05, A07, verificable por OWASP ZAP 2.14 en modo *baseline scan*.
- **Instrumento**: OWASP ZAP 2.14, ejecutado desde el pipeline de CI en cada tag `v*`.
- **Umbral de aceptación**: Cero hallazgos de severidad alta o media. Los hallazgos de severidad baja se documentan en `docs/observaciones/` con plan de mitigación.

---

## RNF-04 — Usabilidad global (Usabilidad · Aprendibilidad + Operabilidad)

- **Categoría ISO/IEC 25010**: Usability · Learnability + Operability
- **Descripción operacional**: Un estudiante nuevo debe poder registrar exitosamente su primera solicitud de tutoría sin necesidad de manual, en un tiempo razonable.
- **Métrica**: System Usability Scale (SUS) $\geq 68$ puntos (Brooke, 1996), sobre una muestra de al menos 30 estudiantes en la Entrega 3.
- **Instrumento**: Cuestionario SUS de 10 ítems (Likert 1-5) aplicado post-tarea; cálculo automatizado con hoja de Excel replicable.
- **Umbral de aceptación**: Excelente SUS $\geq 80$; Bueno $\geq 68$; En desarrollo $\geq 51$; Insuficiente $< 51$ (según el marco interpretativo de Bangor et al. 2008).

---

## RNF-05 — Mantenibilidad del código (Mantenibilidad · Modularidad + Testabilidad)

- **Categoría ISO/IEC 25010**: Maintainability · Modularity + Testability + Analysability
- **Descripción operacional**: El backend debe alcanzar cobertura de líneas por pruebas unitarias e integración en un umbral que garantice detección temprana de regresiones.
- **Métrica**: Cobertura de líneas $\geq 70\,\%$ medida por JaCoCo 0.8.x, con complejidad ciclomática promedio por método $\leq 8$.
- **Instrumento**: JaCoCo integrado en el pipeline de Maven; reporte generado en cada `mvn verify` y publicado como artefacto en GitHub Actions.
- **Umbral de aceptación**: Excelente $\geq 80\,\%$; Bueno $\geq 70\,\%$; En desarrollo $\geq 55\,\%$; Insuficiente $< 55\,\%$.

---

## RNF-06 — Rendimiento del frontend (Eficiencia · Comportamiento temporal)

- **Categoría ISO/IEC 25010**: Performance efficiency · Time behaviour (client side)
- **Descripción operacional**: Las tres páginas críticas de la SPA (bienvenida, solicitud nueva, mis solicitudes) deben alcanzar un puntaje mínimo en Lighthouse en categorías de rendimiento, accesibilidad y buenas prácticas.
- **Métrica**: Lighthouse (Chrome DevTools) categorías Performance $\geq 90$, Accessibility $\geq 90$, Best Practices $\geq 90$, en modo *mobile* con throttling *Slow 4G*.
- **Instrumento**: Lighthouse CI, ejecutado desde el pipeline de GitHub Actions en cada tag `v*`.
- **Umbral de aceptación**: Excelente los tres $\geq 95$; Bueno los tres $\geq 90$; En desarrollo al menos dos $\geq 80$; Insuficiente si alguno $< 80$.

---

## RNF-07 — Portabilidad y reproducibilidad del ambiente (Portabilidad · Instalabilidad)

- **Categoría ISO/IEC 25010**: Portability · Installability + Adaptability
- **Descripción operacional**: Un tercero debe poder clonar el repositorio y levantar el sistema completo con un solo comando en una máquina limpia con Docker Engine, sin instalación manual de dependencias de aplicación.
- **Métrica**: Tiempo desde `git clone` hasta `curl /actuator/health` respondiendo `{"status":"UP"}` $\leq 3$ minutos en la primera ejecución (descarga de imágenes) y $\leq 60$ segundos en ejecuciones subsiguientes.
- **Instrumento**: Pipeline de CI en GitHub Actions con temporizador (`time bash scripts/up.sh`); reproducido manualmente por el docente en máquina limpia antes de la calificación.
- **Umbral de aceptación**: Excelente primera ejecución $\leq 2$ min; Bueno $\leq 3$ min; En desarrollo $\leq 5$ min; Insuficiente $> 5$ min o no levanta.

---

## RNF-08 — Trazabilidad y auditabilidad (Confiabilidad · Recuperabilidad + Seguridad · No repudio)

- **Categoría ISO/IEC 25010**: Security · Non-repudiation + Accountability
- **Descripción operacional**: Toda acción crítica (login, cambio de estado de una solicitud, generación de reporte, modificación de disponibilidad) debe quedar registrada en una tabla de auditoría con marca temporal, identificador de usuario, IP y detalle de la acción, con retención mínima de un semestre académico.
- **Métrica**: 100 % de las acciones críticas registradas en la tabla `auditoria_evento`, verificable por consulta SQL de cobertura sobre las 15 acciones críticas definidas en el catálogo de eventos.
- **Instrumento**: Consulta SQL agregada de cobertura ejecutada mensualmente; alerta automática si la cobertura cae por debajo del 100 %.
- **Umbral de aceptación**: Cobertura del 100 % es no negociable. Cualquier valor menor se cataloga Insuficiente.

---

## Referencias

- ISO/IEC 25010:2011. *Systems and software engineering — Systems and software Quality Requirements and Evaluation (SQuaRE) — System and software quality models*. International Organization for Standardization.
- ISO/IEC/IEEE 29148:2018. *Systems and software engineering — Life cycle processes — Requirements engineering*, cláusula 9.5.4.
- Jones, M., Bradley, J., Sakimura, N. (2015). *JSON Web Token (JWT)*. IETF, RFC 7519.
- OWASP Foundation (2021). *OWASP Top 10:2021 — The Ten Most Critical Web Application Security Risks*.
- Brooke, J. (1996). SUS: A "Quick and Dirty" Usability Scale. En *Usability Evaluation in Industry* (pp. 189-194). Taylor and Francis.
- Bangor, A., Kortum, P. T., Miller, J. T. (2008). An Empirical Evaluation of the System Usability Scale. *International Journal of Human-Computer Interaction*, 24(6), 574-594. DOI: 10.1080/10447310802205776.
