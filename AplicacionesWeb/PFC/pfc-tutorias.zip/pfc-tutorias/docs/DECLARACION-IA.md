# Declaración de uso de inteligencia artificial generativa

Conforme al aviso operativo declarado en la Guía de la Primera Entrega del PFC, el equipo declara aquí el uso de asistentes de inteligencia artificial generativa durante la producción de los artefactos del proyecto.

Esta práctica se alinea con las políticas vigentes de las principales revistas científicas (por ejemplo, IEEE, ACM, Elsevier, Springer Nature) que a partir de 2023-2024 exigen la declaración explícita del uso de estos asistentes en la producción de contenidos, así como con la taxonomía de contribuciones CRediT (ANSI/NISO Z39.104-2022) que se aplicará en la Entrega Final para asignar créditos de autoría.

---

## Registro de uso durante la Entrega 1 (v0.3.0)

*(Cada integrante del equipo llenará su sección al cierre de la Entrega. Si un integrante no usó ningún asistente, lo declara explícitamente.)*

### Integrante 1: `<Apellidos, Nombres>`

- **Herramienta(s) usada(s)**:
- **Versión / modelo**:
- **Fecha(s) de uso**:
- **Propósito**:
- **Sección del proyecto**:
- **Verificación humana**: sí / no. Descripción de la verificación realizada.

### Integrante 2: `<Apellidos, Nombres>`

- **Herramienta(s) usada(s)**:
- **Versión / modelo**:
- **Fecha(s) de uso**:
- **Propósito**:
- **Sección del proyecto**:
- **Verificación humana**:

### Integrante 3: `<Apellidos, Nombres>`

*(A completar por el integrante 3.)*

### Integrante 4: `<Apellidos, Nombres>`

*(A completar por el integrante 4.)*

---

## Principios operativos que rigen el uso de IA generativa en este PFC

1. **Verificación humana obligatoria**. Todo contenido generado por un asistente de IA es revisado y validado por al menos un integrante humano del equipo antes de ser commiteado al repositorio. La verificación incluye validez técnica, referencias citadas (contra fuente primaria) y coherencia con las decisiones arquitectónicas del ADR.
2. **Prohibición absoluta de referencias inventadas**. Cualquier referencia bibliográfica sugerida por un asistente debe verificarse contra la fuente primaria antes de ser incluida en el `.bib` del proyecto. Las referencias fantasma se rechazan sin apelación en la evaluación.
3. **Trazabilidad**. Los prompts significativos (por ejemplo, generación de esqueletos de código, redacción inicial de ADR, síntesis de literatura) se documentan en esta declaración con la sección del proyecto afectada.
4. **No sustitución del aprendizaje**. Los asistentes de IA son herramientas de productividad, no reemplazan la comprensión conceptual del equipo. Durante la defensa oral cada integrante debe poder explicar y justificar el contenido de sus contribuciones.
5. **Cumplimiento normativo**. Este PFC respeta las políticas institucionales de la UTEQ y las políticas editoriales de las revistas y conferencias objetivo a las que aspira contribuir (IEEE TSE, ACM TOSEM, EASE, ESEM, entre otras).

---

## Referencia

ANSI/NISO Z39.104-2022, *CRediT, Contributor Roles Taxonomy*. National Information Standards Organization, Baltimore, MD, febrero 2022.
