# ADR-001 — Estilo arquitectónico: monolito modular sobre REST

## Estado

`Aprobada` el 2026-06-02 en sesión de arquitectura del equipo con veto pedagógico del Product Owner institucional (Dr. Guerrero).

## Contexto

El sistema de gestión de tutorías académicas debe atender inicialmente a la Carrera de Ingeniería de Software (aproximadamente 400 estudiantes activos, 30 docentes y una coordinación), con posibilidad de expansión a otras carreras de la Facultad y eventualmente a toda la UTEQ. Los flujos de negocio identificados en el corpus base son cinco (solicitud, aprobación, ejecución, consulta y reportes) y comparten la misma información de dominio (usuarios, asignaturas, franjas horarias, sesiones).

El equipo debe decidir el estilo arquitectónico global de la aplicación. Las alternativas realistas dentro del alcance del PFC y del calendario académico (17 semanas totales, 12 semanas efectivas de desarrollo) son tres: monolito modular sobre estilo REST, arquitectura orientada a microservicios y arquitectura *serverless*.

La decisión afecta la organización del código, la estrategia de despliegue, la complejidad operativa, el consumo de recursos de las máquinas de desarrollo de los estudiantes y la trazabilidad de la evidencia empírica que se debe producir en las Entregas 3 y Final.

## Decisión

Se adopta un **monolito modular con módulos alineados a los subdominios del corpus de requisitos**, expuesto como API REST conforme a la sesión de disertación doctoral de Roy Fielding sobre el estilo arquitectónico REST (Fielding, 2000) y a la especificación vigente de semántica HTTP en el RFC 9110 (Fielding, Nottingham y Reschke, 2022).

Los módulos internos del monolito serán al menos cuatro: `identidad` (usuarios, roles, autenticación), `agenda` (disponibilidad docente y franjas horarias), `tutorias` (solicitudes, aceptación, ejecución) y `reportes` (agregados institucionales). Cada módulo se organiza en las capas `web` (controladores), `application` (servicios), `domain` (entidades y reglas) e `infrastructure` (persistencia, integraciones), siguiendo la disciplina de la arquitectura limpia de Martin (2017).

Los recursos REST se nombran en plural (`/solicitudes`, `/sesiones`, `/usuarios`) y emplean los métodos HTTP con la semántica canónica: `GET` sin efecto lateral, `POST` para creación, `PUT` para reemplazo completo, `PATCH` para actualización parcial y `DELETE` para eliminación lógica. Los errores se responden con el formato `application/problem+json` conforme al RFC 7807 (Nottingham y Wilde, 2016).

## Consecuencias positivas

Un monolito modular reduce drásticamente la complejidad operativa frente a microservicios (una única unidad desplegable, un único proceso, una única base de datos), lo cual es apropiado para un equipo de 3 a 5 estudiantes con 12 semanas efectivas de desarrollo (Richards y Ford, 2020).

La organización interna por módulos alineados al dominio prepara al sistema para una eventual descomposición futura en servicios independientes si el volumen de uso lo justifica, sin comprometer el diseño desde el inicio (Bass, Clements y Kazman, 2021).

REST como estilo de exposición es el estándar de facto para APIs web y está soportado nativamente por Spring Boot 3 con Spring Web, lo que reduce el esfuerzo de configuración y facilita la generación automática de documentación OpenAPI en la Entrega 2.

El uso de `application/problem+json` unifica la representación de errores desde el primer día, evitando la deuda técnica de definir formatos ad-hoc que después haya que refactorizar.

## Consecuencias negativas

Un monolito comparte el espacio de proceso entre todos los módulos, lo que exige disciplina para evitar acoplamiento entre módulos que compartan el mismo classpath. Se mitiga con reglas de compilación explícitas (visibilidad `package-private` por defecto en Java 21 y verificación estática con ArchUnit en la Entrega 3).

El escalado horizontal del monolito es todo-o-nada: si un módulo aumenta su carga, todo el monolito se replica. Esto no es un problema en el horizonte del PFC pero se documenta como decisión revisable si el sistema pasa a producción real.

## Alternativas consideradas

**Microservicios independientes**. Se rechazó porque el equipo no cuenta con la experiencia operativa (orquestación con Kubernetes, mesh de servicios, tracing distribuido) que exige esta arquitectura, y porque introduciría accidental complexity injustificable para el volumen de tráfico esperado en el horizonte del PFC (Richards y Ford, 2020, capítulo 17).

**Arquitectura serverless (funciones)**. Se rechazó porque introduce dependencia de un proveedor comercial cloud (AWS Lambda, Azure Functions), lo cual es inconsistente con el requisito de que un tercero pueda reproducir el ambiente completamente con `docker compose up`.

## Referencias

- Fielding, R. T. (2000). *Architectural Styles and the Design of Network-based Software Architectures* (Ph.D. dissertation, University of California, Irvine). Sección 5.
- Fielding, R. T., Nottingham, M. y Reschke, J. (2022). *HTTP Semantics*. IETF, RFC 9110. DOI: 10.17487/RFC9110.
- Nottingham, M. y Wilde, E. (2016). *Problem Details for HTTP APIs*. IETF, RFC 7807.
- Martin, R. C. (2017). *Clean Architecture: A Craftsman's Guide to Software Structure and Design*. Prentice Hall.
- Bass, L., Clements, P. y Kazman, R. (2021). *Software Architecture in Practice* (4.ª ed.). Addison-Wesley Professional.
- Richards, M. y Ford, N. (2020). *Fundamentals of Software Architecture: An Engineering Approach*. O'Reilly Media.
