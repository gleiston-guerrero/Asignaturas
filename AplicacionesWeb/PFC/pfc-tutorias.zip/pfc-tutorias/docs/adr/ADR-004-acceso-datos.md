# ADR-004 — Acceso a datos: política híbrida JPA + procedimientos almacenados

## Estado

`Aprobada` el 2026-06-02 en sesión de arquitectura del equipo con veto pedagógico del Product Owner institucional (Dr. Guerrero).

## Contexto

La política académica del programa de la asignatura *Aplicaciones Web* (5.º nivel, PPA 2026-2027), declarada por el docente responsable en la unidad II del sílabo, establece una restricción arquitectónica **no negociable** sobre el acceso a datos: la aplicación debe combinar dos mecanismos distintos según la naturaleza de la operación.

Esta política persigue tres objetivos pedagógicos: (a) que el estudiante ejercite ambos paradigmas (mapeo objeto-relacional y SQL directo en el motor), (b) que la lógica compleja de reportes y agregaciones se resuelva en el motor de base de datos donde es óptima, y (c) que el estudiante experimente en primera persona el patrón profesional de segmentación de responsabilidades entre la aplicación y el motor relacional.

La decisión afecta la organización del código del backend, la estructura de la carpeta `db/procs/`, la generación de migraciones Flyway y la construcción de la matriz de trazabilidad `docs/basedatos/CATALOGO-SP.md` exigida en la Entrega Final.

## Decisión

Se adopta una **política híbrida de acceso a datos** con las siguientes reglas de asignación estrictas.

**Vía JPA (Spring Data JPA + Hibernate) exclusivamente** para las cinco operaciones CRUD elementales:

1. Persistencia individual (`save` sobre una entidad).
2. Consulta por clave primaria (`findById`).
3. Listado completo o paginado (`findAll`, `findAll(Pageable)`).
4. Actualización escalar por clave primaria (asignación de campo simple).
5. Eliminación lógica por clave primaria (marca de baja en columna `estado`).

**Vía procedimientos almacenados versionados** exclusivamente para todas las demás operaciones:

- Consultas con JOIN entre dos o más tablas.
- Agregaciones (SUM, AVG, COUNT con GROUP BY).
- Reportes con múltiples filtros dinámicos.
- Actualizaciones masivas condicionadas.
- Validaciones que involucran datos de varias tablas.
- Proyecciones a DTO para transferencia de datos.

Los procedimientos almacenados se versionarán en la carpeta `backend/src/main/resources/db/procs/` con el patrón de nombre `V<seq>__<descripcion>.sql` y se catalogarán en el archivo `docs/basedatos/CATALOGO-SP.md`. Cada procedimiento almacenado tendrá una columna `tipo_acceso` en la matriz de trazabilidad, con los valores válidos `JPA` o `SP`.

La **concatenación dinámica de SQL** queda **explícitamente prohibida** en todas las formas: en JPQL, en HQL, en SQL nativo dentro del código Java y en `EXECUTE IMMEDIATE` o `sp_executesql` dentro de los procedimientos almacenados. Los parámetros se pasan siempre por *binding* posicional o nominal.

## Consecuencias positivas

La separación reduce la complejidad del código Java: las operaciones CRUD elementales quedan resueltas con las interfaces genéricas de Spring Data JPA sin escribir SQL, mientras que la lógica compleja se resuelve en el motor donde tiene el mejor plan de ejecución (Kleppmann, 2017, capítulo 3).

La prohibición absoluta de concatenación dinámica de SQL es la mitigación principal recomendada por el OWASP Top 10:2021 para el control A03 *Injection*, específicamente para inyección SQL (OWASP Foundation, 2021).

El uso de procedimientos almacenados versionados es coherente con la disciplina de las migraciones Flyway 9.x que ya se planea usar para el esquema, y facilita la revisión por pares de los cambios en la lógica compleja.

El catálogo `docs/basedatos/CATALOGO-SP.md` ofrece a un tercero una vista consolidada de qué operaciones se ejecutan dónde, sin necesidad de recorrer todo el código fuente. Esto es un requisito FAIR de reutilización (Wilkinson et al., 2016).

## Consecuencias negativas

Los procedimientos almacenados atan una parte de la lógica al motor específico (PostgreSQL 16 con PL/pgSQL). La portabilidad a otro motor requerirá traducción manual. Se acepta este costo porque la elección de PostgreSQL está declarada en el `docker-compose.yml` como parte de la reproducibilidad del ambiente.

La depuración de errores en procedimientos almacenados es más incómoda que en Java puro: no se pueden colocar *breakpoints* directamente desde IntelliJ IDEA. Se mitiga con `RAISE NOTICE` sistemático dentro de los procedimientos y con pruebas unitarias directas al procedimiento desde el pipeline de CI en las Entregas 3 y Final.

## Alternativas consideradas

**Solo JPA con JPQL o Criteria API** para todas las operaciones. Se descartó porque las consultas complejas producidas por JPQL o Criteria API tienden a ejecutar planes subóptimos cuando involucran más de tres uniones, y porque no cumple el objetivo pedagógico de la política académica.

**Solo SQL directo (JdbcTemplate)** para todas las operaciones. Se descartó porque obliga a escribir código repetitivo para los CRUD elementales que Spring Data JPA resuelve por convención en tres líneas.

**MyBatis con mapeadores XML** como única alternativa a JPA. Se descartó porque incorpora un mecanismo adicional distinto a los dos ya elegidos por la política académica, sin aportar valor pedagógico incremental.

## Referencias

- Kleppmann, M. (2017). *Designing Data-Intensive Applications: The Big Ideas Behind Reliable, Scalable, and Maintainable Systems*. O'Reilly Media, capítulo 3.
- OWASP Foundation (2021). *OWASP Top 10:2021 — The Ten Most Critical Web Application Security Risks*, control A03 (Injection).
- Wilkinson, M. D., Dumontier, M., Aalbersberg, I. J. et al. (2016). The FAIR Guiding Principles for scientific data management and stewardship. *Scientific Data*, 3, 160018. DOI: 10.1038/sdata.2016.18.
- Walls, C. (2022). *Spring in Action* (6.ª ed.). Manning Publications, capítulos sobre Spring Data JPA.
