# ADR-005 — Contenerización con Docker Compose y digests SHA-256 pinados

## Estado

`Aprobada` el 2026-06-02 en sesión de arquitectura del equipo con veto pedagógico del Product Owner institucional (Dr. Guerrero).

## Contexto

La Guía de la Primera Entrega del PFC exige que un tercero pueda clonar el repositorio y levantar el sistema completo con un solo comando (`docker compose up -d --wait`). Este requisito no negociable exige seleccionar una estrategia de contenerización coherente con dos objetivos: reproducibilidad ambiente-cliente (un principio FAIR) y trazabilidad de la infraestructura como código.

El equipo debe decidir qué runtime de contenedores usar, cómo declarar las imágenes base, cómo gestionar los volúmenes persistentes, cómo configurar los healthchecks y cómo manejar las variables sensibles.

## Decisión

Se adopta **Docker Compose plugin versión 2.20 o superior** con el archivo `docker-compose.yml` en la raíz del repositorio como única fuente de verdad para el ambiente de desarrollo.

Las cinco imágenes base del sistema se pinan por **digest SHA-256 verificado contra Docker Hub el 2026-06-04**, no por tag flotante. Los digests aplicados son:

| Imagen | Digest SHA-256 (verificado en Docker Hub) |
|--------|-------------------------------------------|
| `postgres:16-alpine` | `sha256:e013e867e712fec275706a6c51c966f0bb0c93cfa8f51000f85a15f9865a28cb` |
| `redis:7-alpine` | `sha256:b1addbe72465a718643cff9e60a58e6df1841e29d6d7d60c9a85d8d72f08d1a7` |
| `eclipse-temurin:21-jdk-alpine` | `sha256:3414367cd82328691d1fad30955b010de6e51775f8dd82c7f50f97ab5cbfd876` |
| `node:20-alpine` | `sha256:fb4cd12c85ee03686f6af5362a0b0d56d50c58a04632e6c0fb8363f609372293` |
| `nginx:1.27-alpine` | `sha256:65645c7bb6a0661892a8b03b89d0743208a18dd2f3f17a54ef4b76fb8e2f2a10` |

La verificación se realizará antes de cada tag mayor del proyecto mediante el comando `docker inspect --format='{{index .RepoDigests 0}}' <image>` después de un `docker pull` limpio, y los cambios se registrarán en el `CHANGELOG.md` en la sección `### Changed` correspondiente a la versión.

Cada uno de los cuatro servicios (`postgres`, `redis`, `api`, `web`) declara un **healthcheck** apropiado a su naturaleza: `pg_isready` para PostgreSQL, `redis-cli ping` para Redis, `wget -qO- http://localhost:8080/actuator/health` para la API Spring Boot y `wget -qO- http://localhost/` para el frontend Angular servido por Nginx. Las dependencias entre servicios se declaran con `depends_on.condition: service_healthy` para garantizar el orden correcto de arranque.

Los datos persistentes de PostgreSQL residen en un volumen Docker con nombre (`pfc_pgdata`) para preservarlos entre reinicios y facilitar la copia de seguridad. Los datos volátiles de Redis quedan en memoria y se pierden en cada reinicio, consistente con su uso como cache.

Las **variables sensibles** (contraseñas de base de datos, secreto JWT en la Entrega 2, orígenes CORS permitidos) se leen del archivo `.env` con el formato `KEY=VALUE`, no versionado. El archivo `.env.example` sí se versiona con los nombres de las variables y valores neutros o placeholders explícitos como referencia para nuevos desarrolladores.

## Consecuencias positivas

El *pinning* por digest garantiza que dos ejecuciones separadas del mismo `docker-compose.yml` con seis meses de diferencia arrancarán con **exactamente los mismos bytes** de imagen base, independientemente de que la etiqueta upstream haya recibido actualizaciones. Este es el estándar de facto en la disciplina de reproducibilidad de artefactos científicos (ACM, 2020; Wilkinson et al., 2016).

Los healthchecks convierten el arranque en un proceso auto-verificable: `docker compose up -d --wait` retorna solo cuando todos los servicios reportan `healthy`, o falla con un código de salida distinto de cero si algún servicio no llega a saludable dentro del período `start_period`. Esto habilita la integración con el pipeline de CI de GitHub Actions sin necesidad de `sleep` arbitrarios.

La separación estricta entre `.env.example` (versionado, sin valores sensibles) y `.env` (no versionado, con valores reales) es la mitigación estándar recomendada por OWASP para el control A05 (Security Misconfiguration) contra fuga accidental de secretos en el historial de Git (OWASP Foundation, 2021).

## Consecuencias negativas

Los digests deben actualizarse manualmente cuando se decide aprovechar parches de seguridad de las imágenes base. Se mitiga documentando el procedimiento en el `README.md` y registrando cada actualización en el `CHANGELOG.md`.

El primer `docker compose build` en una máquina limpia descarga aproximadamente 800 MiB de imágenes base, lo cual toma entre 2 y 5 minutos según la conexión. Los arranques posteriores usan la caché local y toman menos de 60 segundos. Se documenta en el `README.md` bajo la sección *Requisitos del ambiente*.

## Alternativas consideradas

**Podman con `podman-compose`** en lugar de Docker Compose. Se identificó como técnicamente equivalente pero se descartó porque el equipo trabaja mayoritariamente en máquinas Windows 11 Pro con WSL2 y Docker Desktop (proporcionadas por el laboratorio de la Carrera), donde Docker Compose es el flujo probado y sin fricciones.

**Kubernetes con `kind` o `minikube`** para el ambiente de desarrollo. Se descartó por complejidad injustificada para un monolito modular con cuatro contenedores; sería apropiado si se hubiera elegido microservicios, opción descartada en el ADR-001.

**Nix Flakes** para reproducibilidad total incluyendo el sistema operativo. Se descartó porque queda fuera de los conocimientos previos del equipo y añadiría una curva de aprendizaje excesiva para el calendario del PFC.

## Referencias

- ACM (2020). *Artifact Review and Badging — Version 1.1*. Association for Computing Machinery.
- Wilkinson, M. D., Dumontier, M., Aalbersberg, I. J. et al. (2016). The FAIR Guiding Principles for scientific data management and stewardship. *Scientific Data*, 3, 160018. DOI: 10.1038/sdata.2016.18.
- OWASP Foundation (2021). *OWASP Top 10:2021 — The Ten Most Critical Web Application Security Risks*, control A05 (Security Misconfiguration).
- Docker Inc. (2024). *Compose specification*, https://docs.docker.com/compose/compose-file/.
