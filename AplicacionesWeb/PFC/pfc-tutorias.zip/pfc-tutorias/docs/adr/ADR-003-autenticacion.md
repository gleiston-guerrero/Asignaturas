# ADR-003 — Modelo de autenticación: JWT stateless por cookie HttpOnly

## Estado

`Aprobada` el 2026-06-02 en sesión de arquitectura del equipo con veto pedagógico del Product Owner institucional (Dr. Guerrero).

## Contexto

El sistema debe autenticar a tres tipos de usuarios (estudiante, docente, coordinación académica) con permisos diferenciados. La autenticación se implementará en la Entrega 2 (`v0.7.0`, semana 12); en la Entrega 1 (`v0.3.0`) solo se declara la decisión y se preparan los cimientos en `docker-compose.yml` y `application.yml`.

Deben decidirse simultáneamente cuatro aspectos entrelazados: (1) modelo de sesión (stateful frente a stateless), (2) portador del token (cabecera HTTP `Authorization` frente a cookie), (3) estrategia de invalidación (lista negra frente a expiración corta con refresh) y (4) esquema criptográfico del token.

La decisión afecta directamente los controles A01 (Broken Access Control), A02 (Cryptographic Failures) y A07 (Identification and Authentication Failures) del OWASP Top 10:2021 (OWASP Foundation, 2021).

## Decisión

Se adopta **autenticación stateless con JSON Web Tokens (JWT) transportados por cookie `HttpOnly + Secure + SameSite=Strict`**.

El token se firmará con el algoritmo `HS256` (HMAC-SHA-256) usando una clave secreta simétrica de al menos 256 bits de entropía leída desde la variable de entorno `JWT_SECRET` en la Entrega 2. El formato del token seguirá estrictamente el RFC 7519 (Jones, Bradley y Sakimura, 2015): cabecera con `alg` y `typ`, *claims* estándar `iss`, `sub`, `aud`, `exp`, `iat`, `jti`, y *claims* propios `roles` y `carreraId`.

La expiración del token de acceso será de 15 minutos. La renovación se hará mediante un *refresh token* transportado en una segunda cookie `HttpOnly + Secure + SameSite=Strict` con duración de 24 horas y trazabilidad en la base de datos (tabla `refresh_token`).

La revocación se implementará mediante lista negra de identificadores `jti` almacenados en Redis 7 con TTL igual al tiempo restante de vida del token revocado. La biblioteca de referencia para la creación y verificación de tokens será `io.jsonwebtoken:jjwt-api:0.12.6` con la implementación runtime `jjwt-impl` y el serializador `jjwt-jackson`.

## Consecuencias positivas

El modelo stateless permite escalar horizontalmente la aplicación sin sesiones pegajosas (*sticky sessions*), preparándola para despliegue en múltiples instancias detrás de un balanceador de carga cuando el volumen lo justifique.

El transporte por cookie `HttpOnly` es la mitigación reconocida en el OWASP Top 10:2021 contra los ataques de robo de sesión por *cross-site scripting* (A03: Injection), porque el token no es accesible desde JavaScript en el navegador. La combinación con `Secure` (solo HTTPS) mitiga interceptación en tránsito y con `SameSite=Strict` mitiga *cross-site request forgery* (Ortega, 2022).

El uso de `jti` como identificador de token permite la revocación selectiva sin comprometer el diseño stateless, delegando el estado transitorio en Redis con expiración automática.

La expiración corta del token de acceso (15 min) reduce la ventana de exposición en caso de compromiso, y el mecanismo de *refresh token* preserva la experiencia de usuario evitando reautenticaciones frecuentes.

## Consecuencias negativas

El transporte por cookie exige la implementación cuidadosa de protección CSRF adicional en los endpoints que aceptan cambios de estado (POST, PUT, PATCH, DELETE), ya que `SameSite=Strict` protege contra CSRF pero puede ser eludido en ciertos escenarios (navegación en la misma pestaña desde otro dominio con redirecciones). Se mitiga añadiendo el patrón *double submit cookie* con el token CSRF en cabecera `X-CSRF-Token` desde la Entrega 2 (OWASP Foundation, 2021, A01).

El uso de `HS256` (simétrico) es aceptable para un monolito donde el mismo servicio firma y verifica, pero requeriría migración a `RS256` (asimétrico) si se descompusiera el sistema en microservicios. Se documenta como decisión revisable en un ADR futuro.

La expiración corta del token de acceso incrementa el volumen de llamadas al endpoint de renovación, con un costo adicional en base de datos por consultas a la tabla `refresh_token`. Se mitiga con el cache Redis y con índice sobre la columna `token_hash`.

## Alternativas consideradas

**Sesiones stateful en `HttpSession` de Spring**. Se descartó porque requeriría replicación de sesión entre instancias en un escenario de escalado horizontal, o alternativamente el uso de sesiones pegajosas en el balanceador, ninguna de las dos opciones consistente con la arquitectura elegida en el ADR-001.

**JWT en cabecera HTTP `Authorization: Bearer <token>`**. Se descartó porque exigiría almacenar el token en `localStorage` o `sessionStorage` del navegador, ambos accesibles desde JavaScript y por tanto vulnerables al robo por XSS. La cookie `HttpOnly` es la mitigación estándar recomendada por OWASP.

**Autenticación federada con OAuth 2.0 y OpenID Connect delegada al SGA institucional**. Se identificó como escenario deseable a mediano plazo pero se descartó para el alcance del PFC porque el SGA institucional no expone actualmente un proveedor de identidad OIDC. Se registra como trabajo futuro en el `docs/observaciones/OBSERVACIONES.md`.

## Referencias

- Jones, M., Bradley, J. y Sakimura, N. (2015). *JSON Web Token (JWT)*. IETF, RFC 7519.
- OWASP Foundation (2021). *OWASP Top 10:2021 — The Ten Most Critical Web Application Security Risks*.
- Ortega, J. M. (2022). *Mastering Python for Networking and Security* (2.ª ed.). Packt Publishing.
- Walls, C. (2022). *Spring in Action* (6.ª ed.). Manning Publications.
