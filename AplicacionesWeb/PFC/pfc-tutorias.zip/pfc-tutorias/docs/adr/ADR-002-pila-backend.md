# ADR-002 — Pila backend: Spring Boot 3.4 sobre Java 21 LTS

## Estado

`Aprobada` el 2026-06-02 en sesión de arquitectura del equipo con veto pedagógico del Product Owner institucional (Dr. Guerrero).

## Contexto

El equipo debe seleccionar la pila tecnológica del backend de la aplicación web. La asignatura *Aplicaciones Web* del quinto nivel de la Carrera de Ingeniería de Software acepta oficialmente tres pilas: (a) Spring Boot 3 sobre Java 21 LTS, (b) ASP.NET Core 8 sobre .NET 8 y (c) PHP 8.3 con PostgreSQL. La política académica exige que la pila elegida se justifique mediante ADR y se declare con versiones pinadas en `docker-compose.yml` y en los archivos de construcción del backend (`pom.xml`, `csproj` o `composer.json`).

La decisión afecta la productividad del equipo, la calidad del artefacto final y las oportunidades de aprendizaje transferible a la industria del cantón Quevedo y la región andina.

## Decisión

Se adopta **Spring Boot 3.4 sobre Java 21 LTS** como pila backend, empaquetada por Maven 3.9.

Se utilizarán los siguientes módulos de Spring Boot 3: `spring-boot-starter-web` para exponer la API REST, `spring-boot-starter-actuator` para exponer `/actuator/health` en la Entrega 1 y las métricas Prometheus en la Entrega 3, `spring-boot-starter-data-jpa` para el acceso a datos relacional (Entrega 2), `spring-boot-starter-data-redis` para el cache (Entrega 2), `spring-boot-starter-security` para la autenticación (Entrega 2), `spring-boot-starter-validation` para la validación de payloads y `springdoc-openapi-starter-webmvc-ui` versión 2.x para la documentación OpenAPI. Las pruebas se realizarán con `spring-boot-starter-test` (JUnit 5, Mockito, MockMvc) desde la Entrega 2 (Walls, 2022).

Java 21 LTS se selecciona como plataforma de ejecución. Es la versión con soporte a largo plazo (LTS) publicada por Oracle en septiembre de 2023 y respaldada por la distribución open source Eclipse Temurin de la Adoptium Working Group. Su soporte extendido está garantizado hasta septiembre de 2028 por Oracle y hasta 2029 por la comunidad Adoptium.

## Consecuencias positivas

Spring Boot 3 es el marco dominante de facto para aplicaciones empresariales Java en la industria y cuenta con la mayor comunidad de práctica, documentación oficial exhaustiva y ecosistema de integraciones (Walls, 2022; Washizaki, 2024, capítulo *Software Design*).

Java 21 LTS aporta características modernas del lenguaje (*records*, *pattern matching* para `switch`, *sealed classes*, *virtual threads* de Project Loom estables) que reducen el volumen de código repetitivo (*boilerplate*) y mejoran la legibilidad respecto a Java 8 o Java 11.

Spring Boot Actuator provee endpoints de operación estandarizados desde el primer día del proyecto (`/actuator/health`, `/actuator/info`, `/actuator/metrics`), permitiendo que el criterio C5 de la rúbrica de la Entrega 1 sea verificable con un simple `curl` sin requerir código de aplicación.

Springdoc OpenAPI 2.x genera automáticamente la documentación de la API a partir de las anotaciones estándar de Spring, lo que reduce el esfuerzo de mantener sincronizada la documentación con el código.

## Consecuencias negativas

Java 21 LTS exige que las máquinas de desarrollo del equipo tengan al menos 4 GiB de RAM para ejecutar la JVM cómodamente junto con IntelliJ IDEA Ultimate. Esta restricción se mitiga porque el Product Owner institucional puso a disposición del equipo licencias educativas de IntelliJ IDEA Ultimate y las máquinas del laboratorio de la Carrera cumplen el requisito de memoria.

Spring Boot 3 tiene una curva de aprendizaje más pronunciada que un backend en PHP puro para funcionalidades simples, pero esta diferencia se compensa a partir del segundo módulo funcional gracias a la reducción del código repetitivo por convención sobre configuración.

## Alternativas consideradas

**ASP.NET Core 8 sobre .NET 8**. Se descartó no por deficiencia técnica sino porque el equipo tiene mayor exposición previa a Java en las asignaturas de Programación II y Estructuras de Datos, y porque la línea editorial del docente responsable para el PPA 2026-2027 favorece Spring Boot 3 como pila de referencia principal.

**PHP 8.3 con PostgreSQL puro**. Se descartó porque, si bien es completamente válido para el alcance del PFC, no permite ejercitar disciplina profesional de tipado fuerte, inyección de dependencias formal y arquitectura por capas al nivel exigido para las publicaciones científicas que persigue el trabajo en las Entregas 3 y Final. PHP puede reconsiderarse para PFC posteriores con enfoque distinto.

## Referencias

- Walls, C. (2022). *Spring in Action* (6.ª ed.). Manning Publications.
- Washizaki, H. (Ed.) (2024). *SWEBOK Guide v4.0: Software Engineering Body of Knowledge*. IEEE Computer Society.
- Martin, R. C. (2017). *Clean Architecture: A Craftsman's Guide to Software Structure and Design*. Prentice Hall.
