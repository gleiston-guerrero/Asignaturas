# Changelog

Todos los cambios notables de este proyecto se documentan en este archivo.

El formato sigue [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/), y el proyecto adhiere a [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

Cambios previstos para la Entrega 2 (`v0.7.0`, viernes semana 12):

- Autenticación stateless JWT con jjwt 0.12 sobre cookie `HttpOnly + Secure + SameSite=Strict`.
- CRUD completo sobre la entidad `SolicitudTutoria` con Spring Data JPA.
- Migraciones Flyway 9.x versionadas en `backend/src/main/resources/db/migration/`.
- Cache Redis 7 para *blacklist* de JTI revocados.
- Springdoc OpenAPI 2.x expuesto en `/swagger-ui.html`.
- Interceptor JWT en Angular 17 con manejo de renovación silenciosa.
- Respuestas de error conforme a RFC 7807 *Problem Details for HTTP APIs*.
- Cinco pruebas unitarias con JUnit 5 y MockMvc pasando en verde.

## [0.3.0] — 2026-06-05 — Entrega 1 del PFC

### Added

- Estructura inicial del repositorio bajo licencia MIT.
- Corpus formalizado de ingeniería de requisitos en `docs/requisitos/`:
  - Especificación de Requisitos del Software conforme a ISO/IEC/IEEE 29148:2018 (`SRS-v0.3.0.tex` + PDF compilado).
  - Cinco fichas Cockburn detalladas (CU-01 a CU-05) para los flujos críticos.
  - Backlog de once historias de usuario en formato Connextra con criterios Gherkin.
  - Catálogo de ocho requisitos no funcionales medibles con métrica ISO/IEC 25010:2011, instrumento y umbral.
  - Bitácora `CHANGELOG-REQ.md` de cambios respecto al corpus base de Ingeniería de Requisitos.
- Arquitectura documentada con el modelo C4 de Simon Brown:
  - Diagrama C4 nivel 1 (System Context) en Structurizr DSL + PNG.
  - Diagrama C4 nivel 2 (Container) en Structurizr DSL + PNG.
- Cinco Architecture Decision Records de Nygard:
  - ADR-001: Estilo arquitectónico (monolito modular sobre REST).
  - ADR-002: Pila backend (Spring Boot 3 + Java 21 LTS).
  - ADR-003: Modelo de autenticación (JWT stateless con cookie HttpOnly).
  - ADR-004: Modelo de acceso a datos (política híbrida JPA + procedimientos almacenados).
  - ADR-005: Estrategia de contenerización (Docker Compose con digests pinados).
- Esqueleto ejecutable con Docker Compose:
  - `docker-compose.yml` con cuatro servicios y todas las imágenes base pinadas por digest SHA-256 verificado contra Docker Hub.
  - Backend Spring Boot 3.4 sobre Java 21 LTS que expone únicamente `GET /actuator/health`.
  - Frontend Angular 17 con página estática de bienvenida.
  - Healthchecks en los cuatro contenedores.
- Scripts `up.sh` y `down.sh` de un solo comando.
- Pipeline de integración continua en `.github/workflows/ci.yml` que compila el SRS LaTeX y valida el arranque de Docker Compose en cada push.
- Documentos raíz: `README.md`, `CITATION.cff` v1.2.0, `.gitignore` para Java, Node y ambientes IDE, `.env.example`.
- Bitácora `docs/observaciones/OBSERVACIONES.md` inicializada.
- Declaración `docs/DECLARACION-IA.md` sobre uso de asistentes generativos.

### Corpus de requisitos base

Los requisitos funcionales, no funcionales, de interfaz, de usabilidad y de proceso, así como los diagramas UML, la matriz de trazabilidad y la priorización Kano, provienen del documento *Análisis de Requisitos para un Sistema de Gestión de Tutorías Académicas en la UTEQ* elaborado en la asignatura de Ingeniería de Requisitos del cuarto nivel (PPA 2025–2026) por el equipo de estudiantes Toaquiza, Lombeida, Muñoz y Zambrano bajo la supervisión del docente responsable. Ese corpus se adopta como punto de partida verificable y se refina bajo la disciplina de ISO/IEC/IEEE 29148:2018.

## [0.0.0] — 2026-05-08 — Constitución del equipo

### Added

- Repositorio creado en GitHub bajo la organización pública del equipo.
- Correo de constitución enviado al docente responsable (Dr. Gleiston Guerrero Ulloa).
- README y LICENSE (MIT) iniciales.

[Unreleased]: https://github.com/<organizacion-del-equipo>/pfc-tutorias/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/<organizacion-del-equipo>/pfc-tutorias/releases/tag/v0.3.0
[0.0.0]: https://github.com/<organizacion-del-equipo>/pfc-tutorias/releases/tag/v0.0.0
