#!/usr/bin/env bash
# =============================================================================
#  up.sh - Levanta el sistema completo del PFC de Tutorias y verifica salud.
#
#  Uso:  bash scripts/up.sh
#
#  Requisitos verificables por este script:
#    - Docker Engine >= 24.0
#    - Docker Compose plugin >= 2.20
#    - 4 GiB RAM libres
#    - Puertos 8080, 80, 5432, 6379 libres
# =============================================================================

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${REPO_ROOT}"

# ----- Verificaciones de prerrequisitos -----
if ! command -v docker &> /dev/null; then
    echo "[ERROR] Docker Engine no esta instalado. Instalar Docker Desktop o Docker Engine >= 24.0"
    exit 1
fi

if ! docker compose version &> /dev/null; then
    echo "[ERROR] Docker Compose plugin no disponible. Instalar Docker Compose >= 2.20"
    exit 1
fi

if [ ! -f .env ]; then
    echo "[INFO] Copiando .env.example a .env (personalizarlo si es necesario)"
    cp .env.example .env
fi

# ----- Arranque -----
echo "===================================================="
echo "  PFC Tutorias - Levantando el sistema completo"
echo "  Version: v0.3.0 (Entrega 1)"
echo "===================================================="
echo ""

docker compose up -d --wait --wait-timeout 180

# ----- Verificaciones post-arranque -----
echo ""
echo "===================================================="
echo "  Verificando estado de los servicios"
echo "===================================================="

API_PORT="${API_PORT:-8080}"
WEB_PORT="${WEB_PORT:-80}"

check_service() {
    local name="$1"
    local url="$2"
    local expect="$3"
    local retries=6
    local wait=5

    for i in $(seq 1 $retries); do
        response=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null || echo "000")
        if [[ "$response" =~ $expect ]]; then
            echo "  [OK] $name responde: $response"
            return 0
        fi
        echo "  [.]  Esperando $name (intento $i/$retries)..."
        sleep $wait
    done
    echo "  [FAIL] $name no respondio con codigo esperado ($expect)"
    return 1
}

check_service "api  " "http://localhost:${API_PORT}/actuator/health" "200"
check_service "web  " "http://localhost:${WEB_PORT}/" "200"

# Verificar contenido del healthcheck
health_body=$(curl -s "http://localhost:${API_PORT}/actuator/health" || echo "")
if echo "$health_body" | grep -q '"status":"UP"'; then
    echo "  [OK] api reporta status UP"
else
    echo "  [FAIL] api no reporta status UP. Respuesta: $health_body"
    exit 1
fi

echo ""
echo "===================================================="
echo "  Sistema levantado exitosamente"
echo "===================================================="
echo ""
echo "  API health : http://localhost:${API_PORT}/actuator/health"
echo "  Frontend   : http://localhost:${WEB_PORT}/"
echo ""
echo "  Detener con: bash scripts/down.sh"
echo ""
