#!/usr/bin/env bash
# =============================================================================
#  down.sh - Apaga los contenedores del PFC de Tutorias.
#
#  Uso:  bash scripts/down.sh
#  Uso con limpieza completa (elimina volumenes):
#        bash scripts/down.sh --volumes
# =============================================================================

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${REPO_ROOT}"

if [[ "${1:-}" == "--volumes" ]]; then
    echo "[WARN] Eliminando contenedores Y volumenes (datos de PostgreSQL se perderan)"
    docker compose down --volumes
else
    echo "[INFO] Apagando contenedores (volumen pfc_pgdata preservado)"
    docker compose down
fi

echo "[OK] Sistema apagado."
