package ec.edu.uteq.pfc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal del backend del Sistema de Gestion de Tutorias Academicas
 * de la UTEQ (PFC Aplicaciones Web, PPA 2026-2027).
 *
 * Version 0.3.0 (Entrega 1): esqueleto ejecutable, expone unicamente
 * el endpoint estandar de Spring Boot Actuator GET /actuator/health,
 * que responde {"status":"UP"} cuando el proceso esta operativo.
 *
 * Los endpoints de negocio se implementan a partir de la Entrega 2
 * (v0.7.0, semana 12) siguiendo la Guia correspondiente.
 *
 * @author Equipo del PFC de Aplicaciones Web
 * @since 0.3.0
 */
@SpringBootApplication
public class PfcApplication {

    public static void main(String[] args) {
        SpringApplication.run(PfcApplication.class, args);
    }

}
