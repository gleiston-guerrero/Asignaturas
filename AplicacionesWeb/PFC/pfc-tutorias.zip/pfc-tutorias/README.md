# Sistema de Gestión de Tutorías Académicas — UTEQ

Repositorio del Proyecto Fin de Curso (PFC) de la asignatura **Aplicaciones Web** (5.º nivel, Ingeniería de Software, Facultad de Ciencias de la Computación y Diseño Digital, Universidad Técnica Estatal de Quevedo), período académico presencial 2026–2027.

Este proyecto instrumenta el sistema web institucional de gestión de tutorías académicas cuyo corpus de requisitos fue producido en la asignatura de Ingeniería de Requisitos del cuarto nivel (PPA 2025–2026). El objetivo del PFC es transformar ese corpus en una aplicación web funcional, reproducible y publicable, siguiendo la disciplina de la norma ISO/IEC/IEEE 29148:2018, el modelo C4 de Simon Brown y los principios FAIR de gestión de artefactos de investigación.

## Descripción del sistema

El Sistema de Gestión de Tutorías Académicas de la UTEQ formaliza la solicitud, aceptación, seguimiento y evaluación de sesiones de tutoría entre estudiantes, docentes y coordinación académica de la Carrera de Ingeniería de Software. Sustituye la gestión informal actual (WhatsApp, correos personales, hojas de cálculo) por una plataforma web institucional con notificaciones automáticas, integración con el SGA institucional y reportes consolidados para toma de decisiones.

Los actores principales son el **estudiante** (solicita tutorías, consulta estado, revisa historial), el **docente** (configura disponibilidad, gestiona solicitudes, registra sesiones realizadas) y la **coordinación académica** (monitorea actividad, genera reportes agregados). El sistema externo con el que se integra es el SGA institucional (para validar asignaturas activas y disponibilidad de aulas). Los canales de notificación soportados en la versión inicial son el correo institucional (por defecto) y la notificación en la plataforma; WhatsApp queda como canal opcional condicionado por la disponibilidad de la API oficial de Meta.

## Estado del proyecto

- **Etiqueta actual**: `v0.3.0` — Entrega 1 del PFC
- **Fecha de cierre**: viernes de la semana 5 del calendario académico 2026–2027
- **Lo que el sistema ya hace en esta versión**: expone el endpoint `GET /actuator/health` que responde `{"status":"UP"}` cuando la base de datos y el cache están saludables. La SPA Angular sirve una página de bienvenida con los créditos del equipo.
- **Lo que aún no hace**: no expone endpoints de negocio ni tiene autenticación operativa. Esos módulos se implementan en la Entrega 2 (`v0.7.0`) siguiendo la Guía correspondiente.

## Requisitos del ambiente

Un tercero sin conocimiento previo del proyecto debe poder ejecutarlo con los siguientes prerrequisitos:

- Docker Engine >= 24.0.0
- Docker Compose plugin >= 2.20.0
- 4 GiB de RAM disponibles
- Puertos libres: 8080 (API), 80 (SPA), 5432 (PostgreSQL), 6379 (Redis)

Las versiones de las imágenes base están **pinadas por digest SHA-256** verificado contra Docker Hub. Ver `docker-compose.yml`.

## Instrucciones de ejecución

```bash
git clone https://github.com/<organizacion-del-equipo>/pfc-tutorias.git
cd pfc-tutorias
cp .env.example .env
bash scripts/up.sh
```

El script `scripts/up.sh` levanta los cuatro contenedores, espera hasta que todos reporten *healthy* y verifica el endpoint de salud. Al terminar imprime:

```
[OK] postgres    healthy
[OK] redis       healthy
[OK] api         health endpoint UP
[OK] web         HTTP 200
Sistema levantado en menos de 2 minutos.
```

Para apagar el sistema:

```bash
bash scripts/down.sh
```

## Estructura del repositorio

```
pfc-tutorias/
├── README.md                       (este archivo)
├── CHANGELOG.md                    Historial semver
├── CITATION.cff                    Cómo citar este artefacto (CFF v1.2.0)
├── LICENSE                         Licencia MIT
├── .gitignore                      Exclusiones Git
├── .env.example                    Variables de entorno esperadas
├── docker-compose.yml              Orquestación de contenedores
├── backend/                        API REST Spring Boot 3 (Java 21)
├── frontend/                       SPA Angular 17
├── docs/
│   ├── requisitos/                 SRS ISO 29148, casos de uso Cockburn, historias, RNF
│   ├── arquitectura/               Diagramas C4 (Structurizr DSL + PNG)
│   ├── adr/                        Architecture Decision Records de Nygard
│   ├── observaciones/              Bitácora acumulativa de retroalimentación docente
│   └── DECLARACION-IA.md           Declaración de uso de IA generativa
├── scripts/                        up.sh, down.sh
└── .github/workflows/              CI: compila SRS y valida arranque de docker-compose
```

## Equipo

| Rol | Nombre | Correo institucional | ORCID |
|-----|--------|----------------------|-------|
| Product Owner institucional | Dr. Gleiston Cicerón Guerrero Ulloa, Ph.D. | gguerrero@uteq.edu.ec | *pending* |
| Scrum Master / Coordinador | *(equipo del PFC)* | *(a completar)* | *pending* |
| Backend Lead | *(equipo del PFC)* | *(a completar)* | *pending* |
| Frontend Lead | *(equipo del PFC)* | *(a completar)* | *pending* |
| DevOps / Data Lead | *(equipo del PFC)* | *(a completar)* | *pending* |

## Cómo citar este proyecto

Ver `CITATION.cff`. En `v0.3.0` el DOI Zenodo aún no está reservado; se reservará al cierre de la Entrega 3.

## Documentación técnica

- Especificación de Requisitos: [`docs/requisitos/SRS-v0.3.0.pdf`](docs/requisitos/SRS-v0.3.0.pdf) (fuente LaTeX en `SRS-v0.3.0.tex`)
- Arquitectura C4: [`docs/arquitectura/`](docs/arquitectura/)
- Decisiones arquitectónicas (ADR): [`docs/adr/`](docs/adr/)
- Bitácora de observaciones: [`docs/observaciones/OBSERVACIONES.md`](docs/observaciones/OBSERVACIONES.md)

## Licencia

Este proyecto está publicado bajo la licencia MIT. Véase `LICENSE`.
