-- V2: datos iniciales de demostracion

INSERT INTO socio (codigo, nombres, correo) VALUES
    ('E-0001', 'Ana Torres',     'ana.torres@uteq.edu.ec'),
    ('E-0002', 'Luis Mendoza',   'luis.mendoza@uteq.edu.ec'),
    ('E-0003', 'Maria Zambrano', 'maria.zambrano@uteq.edu.ec');

INSERT INTO libro (isbn, titulo, autor, anio, ejemplares_totales, ejemplares_disponibles) VALUES
    ('978-90-815406-3-6', 'Distributed Systems',                        'M. van Steen y A. S. Tanenbaum', 2023, 3, 3),
    ('978-1-098-11906-5', 'Designing Data-Intensive Applications',      'M. Kleppmann y C. Riccomini',    2026, 2, 2),
    ('978-1-4920-3402-5', 'Building Microservices',                     'S. Newman',                      2021, 1, 1),
    ('978-0-321-12742-6', 'Patterns of Enterprise Application Architecture', 'M. Fowler',                 2002, 2, 2);
