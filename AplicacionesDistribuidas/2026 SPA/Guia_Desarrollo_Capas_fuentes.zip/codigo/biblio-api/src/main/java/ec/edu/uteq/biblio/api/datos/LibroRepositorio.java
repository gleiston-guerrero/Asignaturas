package ec.edu.uteq.biblio.api.datos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import ec.edu.uteq.biblio.api.dominio.Libro;

/** Patron Repository: Spring Data genera la implementacion en tiempo de ejecucion. */
public interface LibroRepositorio extends JpaRepository<Libro, Long> {

    Optional<Libro> findByIsbn(String isbn);

    boolean existsByIsbn(String isbn);

    List<Libro> findByTituloContainingIgnoreCaseOrderByTitulo(String texto);

    List<Libro> findAllByOrderByTitulo();
}
