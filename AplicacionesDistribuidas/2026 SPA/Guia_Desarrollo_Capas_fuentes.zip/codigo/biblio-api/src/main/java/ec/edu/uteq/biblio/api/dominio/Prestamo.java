package ec.edu.uteq.biblio.api.dominio;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "prestamo")
public class Prestamo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "libro_id")
    private Libro libro;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "socio_id")
    private Socio socio;

    @Column(name = "fecha_prestamo", nullable = false)
    private LocalDate fechaPrestamo;

    @Column(name = "fecha_vencimiento", nullable = false)
    private LocalDate fechaVencimiento;

    @Column(name = "fecha_devolucion")
    private LocalDate fechaDevolucion;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private EstadoPrestamo estado;

    @Column(nullable = false, precision = 8, scale = 2)
    private BigDecimal multa = BigDecimal.ZERO;

    protected Prestamo() {
        // requerido por JPA
    }

    private Prestamo(Libro libro, Socio socio, LocalDate hoy, int diasPrestamo) {
        this.libro = libro;
        this.socio = socio;
        this.fechaPrestamo = hoy;
        this.fechaVencimiento = hoy.plusDays(diasPrestamo);
        this.estado = EstadoPrestamo.ACTIVO;
    }

    /**
     * Metodo fabrica (patron Factory Method): crea un prestamo valido y retira el ejemplar.
     * Es la unica forma de construir un prestamo desde fuera del paquete.
     */
    public static Prestamo registrar(Libro libro, Socio socio, LocalDate hoy, int diasPrestamo) {
        if (!socio.isActivo()) {
            throw new ReglaNegocioException("SOCIO_INACTIVO", "El socio " + socio.getCodigo() + " no esta activo");
        }
        libro.retirarEjemplar();
        return new Prestamo(libro, socio, hoy, diasPrestamo);
    }

    /** Registra la devolucion, calcula la multa por atraso y repone el ejemplar. */
    public void registrarDevolucion(LocalDate hoy, BigDecimal multaPorDia) {
        if (estado == EstadoPrestamo.DEVUELTO) {
            throw new ReglaNegocioException("YA_DEVUELTO", "El prestamo " + id + " ya fue devuelto");
        }
        long diasAtraso = Math.max(0, ChronoUnit.DAYS.between(fechaVencimiento, hoy));
        this.multa = multaPorDia.multiply(BigDecimal.valueOf(diasAtraso)).setScale(2, RoundingMode.HALF_UP);
        this.fechaDevolucion = hoy;
        this.estado = EstadoPrestamo.DEVUELTO;
        libro.devolverEjemplar();
    }

    public Long getId() {
        return id;
    }

    public Libro getLibro() {
        return libro;
    }

    public Socio getSocio() {
        return socio;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public LocalDate getFechaVencimiento() {
        return fechaVencimiento;
    }

    public LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }

    public EstadoPrestamo getEstado() {
        return estado;
    }

    public BigDecimal getMulta() {
        return multa;
    }
}
