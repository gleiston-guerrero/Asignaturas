package ec.edu.uteq.biblio.api.web;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.uteq.biblio.api.negocio.CatalogoServicio;
import ec.edu.uteq.biblio.api.negocio.PrestamoServicio;
import ec.edu.uteq.biblio.api.web.dto.PrestamoRespuesta;
import ec.edu.uteq.biblio.api.web.dto.SocioRespuesta;

@RestController
@RequestMapping("/api/v1/socios")
public class SocioControlador {

    private final CatalogoServicio catalogo;
    private final PrestamoServicio prestamos;

    public SocioControlador(CatalogoServicio catalogo, PrestamoServicio prestamos) {
        this.catalogo = catalogo;
        this.prestamos = prestamos;
    }

    @GetMapping
    public List<SocioRespuesta> listar() {
        return catalogo.listarSocios().stream().map(SocioRespuesta::desde).toList();
    }

    @GetMapping("/{id}/prestamos")
    public List<PrestamoRespuesta> prestamosDelSocio(@PathVariable Long id) {
        return prestamos.listarPorSocio(id).stream().map(PrestamoRespuesta::desde).toList();
    }
}
