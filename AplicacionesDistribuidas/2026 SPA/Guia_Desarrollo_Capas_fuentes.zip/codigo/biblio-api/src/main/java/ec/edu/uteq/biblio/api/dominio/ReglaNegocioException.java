package ec.edu.uteq.biblio.api.dominio;

/**
 * Se lanza cuando una operacion viola una regla del negocio
 * (por ejemplo, prestar un libro sin ejemplares disponibles).
 */
public class ReglaNegocioException extends RuntimeException {

    private final String codigo;

    public ReglaNegocioException(String codigo, String mensaje) {
        super(mensaje);
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }
}
