package ec.edu.uteq.biblio.api.dominio;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

@Entity
@Table(name = "libro")
public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 17)
    private String isbn;

    @Column(nullable = false, length = 200)
    private String titulo;

    @Column(nullable = false, length = 150)
    private String autor;

    @Column(nullable = false)
    private short anio;

    @Column(name = "ejemplares_totales", nullable = false)
    private int ejemplaresTotales;

    @Column(name = "ejemplares_disponibles", nullable = false)
    private int ejemplaresDisponibles;

    /** Control de concurrencia optimista: Hibernate incrementa y compara este valor. */
    @Version
    private long version;

    protected Libro() {
        // requerido por JPA
    }

    public Libro(String isbn, String titulo, String autor, short anio, int ejemplaresTotales) {
        if (ejemplaresTotales < 0) {
            throw new ReglaNegocioException("EJEMPLARES_INVALIDOS", "El numero de ejemplares no puede ser negativo");
        }
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.anio = anio;
        this.ejemplaresTotales = ejemplaresTotales;
        this.ejemplaresDisponibles = ejemplaresTotales;
    }

    /** Regla de dominio: solo se presta si queda al menos un ejemplar. */
    public void retirarEjemplar() {
        if (ejemplaresDisponibles == 0) {
            throw new ReglaNegocioException("SIN_EJEMPLARES",
                    "El libro '" + titulo + "' no tiene ejemplares disponibles");
        }
        ejemplaresDisponibles--;
    }

    public void devolverEjemplar() {
        if (ejemplaresDisponibles == ejemplaresTotales) {
            throw new ReglaNegocioException("DEVOLUCION_INVALIDA",
                    "Todos los ejemplares del libro ya estan en la biblioteca");
        }
        ejemplaresDisponibles++;
    }

    public void actualizarDatos(String titulo, String autor, short anio, int ejemplaresTotales) {
        int prestados = this.ejemplaresTotales - this.ejemplaresDisponibles;
        if (ejemplaresTotales < prestados) {
            throw new ReglaNegocioException("EJEMPLARES_INVALIDOS",
                    "No se puede reducir el total por debajo de los " + prestados + " ejemplares prestados");
        }
        this.titulo = titulo;
        this.autor = autor;
        this.anio = anio;
        this.ejemplaresTotales = ejemplaresTotales;
        this.ejemplaresDisponibles = ejemplaresTotales - prestados;
    }

    public Long getId() {
        return id;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public short getAnio() {
        return anio;
    }

    public int getEjemplaresTotales() {
        return ejemplaresTotales;
    }

    public int getEjemplaresDisponibles() {
        return ejemplaresDisponibles;
    }

    public long getVersion() {
        return version;
    }
}
