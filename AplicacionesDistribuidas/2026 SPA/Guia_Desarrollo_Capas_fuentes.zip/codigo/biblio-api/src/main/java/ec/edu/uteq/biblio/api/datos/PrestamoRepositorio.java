package ec.edu.uteq.biblio.api.datos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ec.edu.uteq.biblio.api.dominio.EstadoPrestamo;
import ec.edu.uteq.biblio.api.dominio.Prestamo;

public interface PrestamoRepositorio extends JpaRepository<Prestamo, Long> {

    long countBySocioIdAndEstado(Long socioId, EstadoPrestamo estado);

    /** Trae el libro y el socio en la misma consulta para evitar el problema N+1. */
    @Query("""
            select p from Prestamo p
              join fetch p.libro
              join fetch p.socio
             where p.socio.id = :socioId
             order by p.fechaPrestamo desc, p.id desc
            """)
    List<Prestamo> buscarPorSocio(@Param("socioId") Long socioId);

    @Query("""
            select p from Prestamo p
              join fetch p.libro
              join fetch p.socio
             where p.id = :id
            """)
    Optional<Prestamo> buscarConDetalle(@Param("id") Long id);
}
