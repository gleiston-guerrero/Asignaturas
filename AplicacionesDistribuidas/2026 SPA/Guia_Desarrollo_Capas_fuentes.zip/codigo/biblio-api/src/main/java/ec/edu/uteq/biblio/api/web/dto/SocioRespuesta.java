package ec.edu.uteq.biblio.api.web.dto;

import ec.edu.uteq.biblio.api.dominio.Socio;

public record SocioRespuesta(Long id, String codigo, String nombres, String correo, boolean activo) {

    public static SocioRespuesta desde(Socio socio) {
        return new SocioRespuesta(socio.getId(), socio.getCodigo(), socio.getNombres(), socio.getCorreo(),
                socio.isActivo());
    }
}
