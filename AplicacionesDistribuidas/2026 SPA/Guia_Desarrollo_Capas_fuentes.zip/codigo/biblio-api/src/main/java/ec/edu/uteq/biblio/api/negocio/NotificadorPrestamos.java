package ec.edu.uteq.biblio.api.negocio;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import ec.edu.uteq.biblio.api.dominio.PrestamoRegistradoEvento;

/**
 * Observador (patron Observer): reacciona a los prestamos confirmados sin que
 * PrestamoServicio lo conozca. Solo se ejecuta si la transaccion se confirmo.
 * En un sistema real enviaria un correo o publicaria el evento en un broker.
 */
@Component
public class NotificadorPrestamos {

    private static final Logger LOG = LoggerFactory.getLogger(NotificadorPrestamos.class);

    @TransactionalEventListener
    public void alRegistrarPrestamo(PrestamoRegistradoEvento evento) {
        LOG.info("Prestamo {} confirmado: socio={}, isbn={}, vence={}",
                evento.prestamoId(), evento.codigoSocio(), evento.isbn(), evento.fechaVencimiento());
    }
}
