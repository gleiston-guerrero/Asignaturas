package ec.edu.uteq.biblio.api.web.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import ec.edu.uteq.biblio.api.dominio.Prestamo;

public record PrestamoRespuesta(Long id, Long socioId, String codigoSocio, Long libroId, String tituloLibro,
        LocalDate fechaPrestamo, LocalDate fechaVencimiento, LocalDate fechaDevolucion,
        String estado, BigDecimal multa) {

    public static PrestamoRespuesta desde(Prestamo p) {
        return new PrestamoRespuesta(p.getId(), p.getSocio().getId(), p.getSocio().getCodigo(),
                p.getLibro().getId(), p.getLibro().getTitulo(), p.getFechaPrestamo(), p.getFechaVencimiento(),
                p.getFechaDevolucion(), p.getEstado().name(), p.getMulta());
    }
}
