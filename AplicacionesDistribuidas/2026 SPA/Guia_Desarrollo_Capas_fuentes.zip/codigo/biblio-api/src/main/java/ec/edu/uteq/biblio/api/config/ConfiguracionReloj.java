package ec.edu.uteq.biblio.api.config;

import java.time.Clock;
import java.time.ZoneId;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Expone el reloj del sistema como un bean. Las reglas de negocio piden la fecha
 * a este reloj y no a LocalDate.now(), de modo que las pruebas pueden fijarla.
 */
@Configuration
public class ConfiguracionReloj {

    @Bean
    Clock reloj() {
        return Clock.system(ZoneId.of("America/Guayaquil"));
    }
}
