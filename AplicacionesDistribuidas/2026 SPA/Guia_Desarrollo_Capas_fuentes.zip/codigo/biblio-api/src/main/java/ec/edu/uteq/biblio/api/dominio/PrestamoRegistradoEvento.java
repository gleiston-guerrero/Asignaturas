package ec.edu.uteq.biblio.api.dominio;

import java.time.LocalDate;

/** Evento de dominio que se publica cuando se confirma un prestamo (patron Observer). */
public record PrestamoRegistradoEvento(Long prestamoId, String codigoSocio, String isbn, LocalDate fechaVencimiento) {
}
