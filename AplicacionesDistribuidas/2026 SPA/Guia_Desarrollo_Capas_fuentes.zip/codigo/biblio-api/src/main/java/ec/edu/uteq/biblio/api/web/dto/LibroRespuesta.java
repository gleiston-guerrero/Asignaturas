package ec.edu.uteq.biblio.api.web.dto;

import ec.edu.uteq.biblio.api.dominio.Libro;

/** Lo que el API devuelve de un libro: nunca se expone la entidad JPA directamente. */
public record LibroRespuesta(Long id, String isbn, String titulo, String autor, short anio,
        int ejemplaresTotales, int ejemplaresDisponibles) {

    public static LibroRespuesta desde(Libro libro) {
        return new LibroRespuesta(libro.getId(), libro.getIsbn(), libro.getTitulo(), libro.getAutor(),
                libro.getAnio(), libro.getEjemplaresTotales(), libro.getEjemplaresDisponibles());
    }
}
