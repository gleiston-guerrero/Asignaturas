package ec.edu.uteq.biblio.api.web.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Datos que el cliente envia para crear o actualizar un libro. */
public record LibroSolicitud(
        @NotBlank @Pattern(regexp = "[0-9-]{10,17}", message = "debe contener solo digitos y guiones") String isbn,
        @NotBlank @Size(max = 200) String titulo,
        @NotBlank @Size(max = 150) String autor,
        @Min(1450) @Max(2100) short anio,
        @Min(0) @Max(1000) int ejemplaresTotales) {
}
