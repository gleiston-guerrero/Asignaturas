package ec.edu.uteq.biblio.api.datos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ec.edu.uteq.biblio.api.dominio.Socio;

public interface SocioRepositorio extends JpaRepository<Socio, Long> {

    List<Socio> findAllByOrderByNombres();
}
