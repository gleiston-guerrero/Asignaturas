package ec.edu.uteq.biblio.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

/** Metadatos del contrato OpenAPI que springdoc genera a partir de los controladores. */
@Configuration
public class ConfiguracionOpenApi {

    @Bean
    OpenAPI contratoBiblio() {
        return new OpenAPI().info(new Info()
                .title("BiblioUTEQ API")
                .version("1.0.0")
                .description("API REST del sistema de prestamos de la biblioteca (guia ISR-701)"));
    }
}
