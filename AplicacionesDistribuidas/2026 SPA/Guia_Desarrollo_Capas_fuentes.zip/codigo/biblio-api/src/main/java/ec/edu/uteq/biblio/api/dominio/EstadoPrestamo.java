package ec.edu.uteq.biblio.api.dominio;

public enum EstadoPrestamo {
    ACTIVO,
    DEVUELTO
}
