package ec.edu.uteq.biblio.api.web.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record PrestamoSolicitud(@NotNull @Positive Long socioId, @NotNull @Positive Long libroId) {
}
