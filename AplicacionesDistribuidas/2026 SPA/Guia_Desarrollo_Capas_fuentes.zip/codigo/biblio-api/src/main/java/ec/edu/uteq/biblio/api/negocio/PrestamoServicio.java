package ec.edu.uteq.biblio.api.negocio;

import java.time.Clock;
import java.time.LocalDate;
import java.util.List;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ec.edu.uteq.biblio.api.datos.LibroRepositorio;
import ec.edu.uteq.biblio.api.datos.PrestamoRepositorio;
import ec.edu.uteq.biblio.api.datos.SocioRepositorio;
import ec.edu.uteq.biblio.api.dominio.EstadoPrestamo;
import ec.edu.uteq.biblio.api.dominio.Libro;
import ec.edu.uteq.biblio.api.dominio.Prestamo;
import ec.edu.uteq.biblio.api.dominio.PrestamoRegistradoEvento;
import ec.edu.uteq.biblio.api.dominio.ReglaNegocioException;
import ec.edu.uteq.biblio.api.dominio.Socio;

/**
 * Capa de negocio: orquesta el caso de uso "prestar un libro".
 * Cada metodo publico es una transaccion: o se aplican todos los cambios, o ninguno.
 */
@Service
@Transactional(readOnly = true)
public class PrestamoServicio {

    private final PrestamoRepositorio prestamos;
    private final LibroRepositorio libros;
    private final SocioRepositorio socios;
    private final ReglasPrestamo reglas;
    private final Clock reloj;
    private final ApplicationEventPublisher eventos;

    public PrestamoServicio(PrestamoRepositorio prestamos, LibroRepositorio libros, SocioRepositorio socios,
            ReglasPrestamo reglas, Clock reloj, ApplicationEventPublisher eventos) {
        this.prestamos = prestamos;
        this.libros = libros;
        this.socios = socios;
        this.reglas = reglas;
        this.reloj = reloj;
        this.eventos = eventos;
    }

    @Transactional
    public Prestamo registrar(Long socioId, Long libroId) {
        Socio socio = socios.findById(socioId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Socio", socioId));

        long activos = prestamos.countBySocioIdAndEstado(socioId, EstadoPrestamo.ACTIVO);
        if (activos >= reglas.maxPrestamosActivos()) {
            throw new ReglaNegocioException("LIMITE_PRESTAMOS",
                    "El socio ya tiene " + activos + " prestamos activos (maximo " + reglas.maxPrestamosActivos() + ")");
        }

        Libro libro = libros.findById(libroId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Libro", libroId));

        Prestamo prestamo = Prestamo.registrar(libro, socio, LocalDate.now(reloj), reglas.diasPrestamo());
        Prestamo guardado = prestamos.save(prestamo);

        eventos.publishEvent(new PrestamoRegistradoEvento(guardado.getId(), socio.getCodigo(),
                libro.getIsbn(), guardado.getFechaVencimiento()));
        return guardado;
    }

    @Transactional
    public Prestamo devolver(Long prestamoId) {
        Prestamo prestamo = prestamos.buscarConDetalle(prestamoId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Prestamo", prestamoId));
        prestamo.registrarDevolucion(LocalDate.now(reloj), reglas.multaPorDia());
        return prestamo;
    }

    public List<Prestamo> listarPorSocio(Long socioId) {
        if (!socios.existsById(socioId)) {
            throw new RecursoNoEncontradoException("Socio", socioId);
        }
        return prestamos.buscarPorSocio(socioId);
    }
}
