package ec.edu.uteq.biblio.api.web;

import java.net.URI;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ec.edu.uteq.biblio.api.dominio.Prestamo;
import ec.edu.uteq.biblio.api.negocio.PrestamoServicio;
import ec.edu.uteq.biblio.api.web.dto.PrestamoRespuesta;
import ec.edu.uteq.biblio.api.web.dto.PrestamoSolicitud;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/prestamos")
public class PrestamoControlador {

    private final PrestamoServicio servicio;

    public PrestamoControlador(PrestamoServicio servicio) {
        this.servicio = servicio;
    }

    @PostMapping
    public ResponseEntity<PrestamoRespuesta> registrar(@Valid @RequestBody PrestamoSolicitud s) {
        Prestamo prestamo = servicio.registrar(s.socioId(), s.libroId());
        URI ubicacion = URI.create("/api/v1/prestamos/" + prestamo.getId());
        return ResponseEntity.created(ubicacion).body(PrestamoRespuesta.desde(prestamo));
    }

    /** La devolucion es una accion sobre el recurso: se modela como subrecurso con POST. */
    @PostMapping("/{id}/devolucion")
    public PrestamoRespuesta devolver(@PathVariable Long id) {
        return PrestamoRespuesta.desde(servicio.devolver(id));
    }
}
