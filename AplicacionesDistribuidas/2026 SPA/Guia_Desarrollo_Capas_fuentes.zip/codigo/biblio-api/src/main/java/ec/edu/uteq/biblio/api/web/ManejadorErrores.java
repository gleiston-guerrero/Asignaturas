package ec.edu.uteq.biblio.api.web;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import ec.edu.uteq.biblio.api.dominio.ReglaNegocioException;
import ec.edu.uteq.biblio.api.negocio.RecursoNoEncontradoException;

/**
 * Traduce las excepciones de las capas inferiores a respuestas HTTP con el formato
 * estandar Problem Details (RFC 9457). Las capas de negocio y datos no conocen HTTP.
 * La clase base ya responde en ese formato a los errores propios de Spring MVC.
 */
@RestControllerAdvice
public class ManejadorErrores extends ResponseEntityExceptionHandler {

    private static final String BASE = "https://biblio.uteq.edu.ec/errores/";

    @ExceptionHandler(RecursoNoEncontradoException.class)
    ProblemDetail noEncontrado(RecursoNoEncontradoException ex) {
        ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        p.setType(URI.create(BASE + "no-encontrado"));
        p.setTitle("Recurso no encontrado");
        return p;
    }

    @ExceptionHandler(ReglaNegocioException.class)
    ProblemDetail reglaNegocio(ReglaNegocioException ex) {
        ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_CONTENT, ex.getMessage());
        p.setType(URI.create(BASE + "regla-negocio"));
        p.setTitle("Regla de negocio incumplida");
        p.setProperty("codigo", ex.getCodigo());
        return p;
    }

    /** Errores de validacion (400): se agrega el detalle de cada campo invalido. */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
            HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        ProblemDetail p = ex.getBody();
        p.setTitle("Datos invalidos");
        p.setDetail("La solicitud tiene campos con valores no validos");
        Map<String, String> errores = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(e -> errores.put(e.getField(), e.getDefaultMessage()));
        p.setProperty("errores", errores);
        return handleExceptionInternal(ex, p, headers, status, request);
    }

    /** Dos transacciones modificaron el mismo libro a la vez y esta perdio: el cliente puede reintentar. */
    @ExceptionHandler(ObjectOptimisticLockingFailureException.class)
    ProblemDetail conflicto(ObjectOptimisticLockingFailureException ex) {
        ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT,
                "El recurso fue modificado por otra operacion al mismo tiempo; intente de nuevo");
        p.setType(URI.create(BASE + "conflicto-concurrencia"));
        p.setTitle("Conflicto de concurrencia");
        return p;
    }
}
