package ec.edu.uteq.biblio.api.web;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import ec.edu.uteq.biblio.api.dominio.Libro;
import ec.edu.uteq.biblio.api.negocio.CatalogoServicio;
import ec.edu.uteq.biblio.api.web.dto.LibroRespuesta;
import ec.edu.uteq.biblio.api.web.dto.LibroSolicitud;
import jakarta.validation.Valid;

/** Capa de servicios web: traduce HTTP a llamadas de la capa de negocio y nada mas. */
@RestController
@RequestMapping("/api/v1/libros")
public class LibroControlador {

    private final CatalogoServicio catalogo;

    public LibroControlador(CatalogoServicio catalogo) {
        this.catalogo = catalogo;
    }

    @GetMapping
    public List<LibroRespuesta> listar(@RequestParam(name = "q", required = false) String texto) {
        return catalogo.listarLibros(texto).stream().map(LibroRespuesta::desde).toList();
    }

    @GetMapping("/{id}")
    public LibroRespuesta obtener(@PathVariable Long id) {
        return LibroRespuesta.desde(catalogo.obtenerLibro(id));
    }

    @PostMapping
    public ResponseEntity<LibroRespuesta> crear(@Valid @RequestBody LibroSolicitud s) {
        Libro libro = catalogo.registrarLibro(s.isbn(), s.titulo(), s.autor(), s.anio(), s.ejemplaresTotales());
        URI ubicacion = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(libro.getId()).toUri();
        return ResponseEntity.created(ubicacion).body(LibroRespuesta.desde(libro));
    }

    @PutMapping("/{id}")
    public LibroRespuesta actualizar(@PathVariable Long id, @Valid @RequestBody LibroSolicitud s) {
        return LibroRespuesta.desde(catalogo.actualizarLibro(id, s.titulo(), s.autor(), s.anio(), s.ejemplaresTotales()));
    }
}
