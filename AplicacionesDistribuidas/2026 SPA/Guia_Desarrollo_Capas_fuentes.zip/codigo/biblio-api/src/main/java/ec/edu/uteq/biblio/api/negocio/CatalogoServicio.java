package ec.edu.uteq.biblio.api.negocio;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ec.edu.uteq.biblio.api.datos.LibroRepositorio;
import ec.edu.uteq.biblio.api.datos.SocioRepositorio;
import ec.edu.uteq.biblio.api.dominio.Libro;
import ec.edu.uteq.biblio.api.dominio.ReglaNegocioException;
import ec.edu.uteq.biblio.api.dominio.Socio;

/** Capa de negocio: casos de uso del catalogo de libros y de los socios. */
@Service
@Transactional(readOnly = true)
public class CatalogoServicio {

    private final LibroRepositorio libros;
    private final SocioRepositorio socios;

    // Inyeccion de dependencias por constructor: Spring entrega las implementaciones.
    public CatalogoServicio(LibroRepositorio libros, SocioRepositorio socios) {
        this.libros = libros;
        this.socios = socios;
    }

    public List<Libro> listarLibros(String texto) {
        if (texto == null || texto.isBlank()) {
            return libros.findAllByOrderByTitulo();
        }
        return libros.findByTituloContainingIgnoreCaseOrderByTitulo(texto.trim());
    }

    public Libro obtenerLibro(Long id) {
        return libros.findById(id).orElseThrow(() -> new RecursoNoEncontradoException("Libro", id));
    }

    @Transactional
    public Libro registrarLibro(String isbn, String titulo, String autor, short anio, int ejemplares) {
        if (libros.existsByIsbn(isbn)) {
            throw new ReglaNegocioException("ISBN_DUPLICADO", "Ya existe un libro con ISBN " + isbn);
        }
        return libros.save(new Libro(isbn, titulo, autor, anio, ejemplares));
    }

    @Transactional
    public Libro actualizarLibro(Long id, String titulo, String autor, short anio, int ejemplares) {
        Libro libro = obtenerLibro(id);
        libro.actualizarDatos(titulo, autor, anio, ejemplares);
        return libro; // el cambio se guarda al confirmar la transaccion (dirty checking)
    }

    public List<Socio> listarSocios() {
        return socios.findAllByOrderByNombres();
    }
}
