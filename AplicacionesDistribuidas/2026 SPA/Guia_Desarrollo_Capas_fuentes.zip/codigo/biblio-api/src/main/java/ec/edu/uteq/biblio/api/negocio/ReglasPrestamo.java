package ec.edu.uteq.biblio.api.negocio;

import java.math.BigDecimal;

import org.springframework.boot.context.properties.ConfigurationProperties;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;

import org.springframework.validation.annotation.Validated;

/**
 * Parametros del negocio leidos de application.yaml (prefijo biblio.reglas).
 * Cambiar una regla no exige recompilar: basta con cambiar la configuracion.
 */
@Validated
@ConfigurationProperties(prefix = "biblio.reglas")
public record ReglasPrestamo(
        @Min(1) int maxPrestamosActivos,
        @Min(1) int diasPrestamo,
        @DecimalMin("0.00") BigDecimal multaPorDia) {
}
