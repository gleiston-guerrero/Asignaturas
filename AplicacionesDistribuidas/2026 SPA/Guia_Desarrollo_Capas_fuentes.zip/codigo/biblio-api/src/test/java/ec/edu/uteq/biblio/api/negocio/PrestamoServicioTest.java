package ec.edu.uteq.biblio.api.negocio;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import ec.edu.uteq.biblio.api.datos.LibroRepositorio;
import ec.edu.uteq.biblio.api.datos.PrestamoRepositorio;
import ec.edu.uteq.biblio.api.datos.SocioRepositorio;
import ec.edu.uteq.biblio.api.dominio.EstadoPrestamo;
import ec.edu.uteq.biblio.api.dominio.Libro;
import ec.edu.uteq.biblio.api.dominio.Prestamo;
import ec.edu.uteq.biblio.api.dominio.PrestamoRegistradoEvento;
import ec.edu.uteq.biblio.api.dominio.ReglaNegocioException;
import ec.edu.uteq.biblio.api.dominio.Socio;

/** Prueba unitaria: la capa de negocio se prueba sola, con las capas inferiores simuladas. */
@ExtendWith(MockitoExtension.class)
class PrestamoServicioTest {

    private static final ZoneId ZONA = ZoneId.of("America/Guayaquil");
    private static final LocalDate HOY = LocalDate.of(2027, 2, 1);

    @Mock
    private PrestamoRepositorio prestamos;
    @Mock
    private LibroRepositorio libros;
    @Mock
    private SocioRepositorio socios;
    @Mock
    private ApplicationEventPublisher eventos;

    private PrestamoServicio servicio;
    private Socio socio;
    private Libro libro;

    @BeforeEach
    void preparar() {
        Clock reloj = Clock.fixed(HOY.atStartOfDay(ZONA).toInstant(), ZONA);
        ReglasPrestamo reglas = new ReglasPrestamo(3, 7, new BigDecimal("0.25"));
        servicio = new PrestamoServicio(prestamos, libros, socios, reglas, reloj, eventos);
        socio = new Socio("E-0001", "Ana Torres", "ana.torres@uteq.edu.ec");
        libro = new Libro("978-1-4920-3402-5", "Building Microservices", "S. Newman", (short) 2021, 1);
    }

    @Test
    void registraPrestamoRetiraEjemplarYPublicaEvento() {
        when(socios.findById(1L)).thenReturn(Optional.of(socio));
        when(prestamos.countBySocioIdAndEstado(1L, EstadoPrestamo.ACTIVO)).thenReturn(0L);
        when(libros.findById(10L)).thenReturn(Optional.of(libro));
        when(prestamos.save(any(Prestamo.class))).thenAnswer(inv -> inv.getArgument(0));

        Prestamo p = servicio.registrar(1L, 10L);

        assertThat(p.getEstado()).isEqualTo(EstadoPrestamo.ACTIVO);
        assertThat(p.getFechaVencimiento()).isEqualTo(HOY.plusDays(7));
        assertThat(libro.getEjemplaresDisponibles()).isZero();
        verify(eventos).publishEvent(any(PrestamoRegistradoEvento.class));
    }

    @Test
    void rechazaCuandoElSocioAlcanzoElLimite() {
        when(socios.findById(1L)).thenReturn(Optional.of(socio));
        when(prestamos.countBySocioIdAndEstado(1L, EstadoPrestamo.ACTIVO)).thenReturn(3L);

        assertThatThrownBy(() -> servicio.registrar(1L, 10L))
                .isInstanceOf(ReglaNegocioException.class)
                .extracting("codigo").isEqualTo("LIMITE_PRESTAMOS");
        verify(prestamos, never()).save(any());
    }

    @Test
    void rechazaCuandoNoQuedanEjemplares() {
        libro.retirarEjemplar(); // el unico ejemplar ya esta prestado
        when(socios.findById(1L)).thenReturn(Optional.of(socio));
        when(prestamos.countBySocioIdAndEstado(1L, EstadoPrestamo.ACTIVO)).thenReturn(0L);
        when(libros.findById(10L)).thenReturn(Optional.of(libro));

        assertThatThrownBy(() -> servicio.registrar(1L, 10L))
                .isInstanceOf(ReglaNegocioException.class)
                .extracting("codigo").isEqualTo("SIN_EJEMPLARES");
    }

    @Test
    void lanzaNoEncontradoSiElSocioNoExiste() {
        when(socios.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> servicio.registrar(99L, 10L))
                .isInstanceOf(RecursoNoEncontradoException.class);
    }

    @Test
    void devolucionConTresDiasDeAtrasoCobraMulta() {
        LocalDate haceDiezDias = HOY.minusDays(10); // vencio hace 3 dias (prestamo de 7 dias)
        Prestamo p = Prestamo.registrar(libro, socio, haceDiezDias, 7);
        when(prestamos.buscarConDetalle(5L)).thenReturn(Optional.of(p));

        Prestamo devuelto = servicio.devolver(5L);

        assertThat(devuelto.getEstado()).isEqualTo(EstadoPrestamo.DEVUELTO);
        assertThat(devuelto.getMulta()).isEqualByComparingTo("0.75");
        assertThat(libro.getEjemplaresDisponibles()).isEqualTo(1);
    }
}
