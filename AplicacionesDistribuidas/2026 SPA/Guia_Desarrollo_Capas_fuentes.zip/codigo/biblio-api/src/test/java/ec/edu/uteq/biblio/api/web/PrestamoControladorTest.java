package ec.edu.uteq.biblio.api.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.assertj.MockMvcTester;

import ec.edu.uteq.biblio.api.dominio.Libro;
import ec.edu.uteq.biblio.api.dominio.Prestamo;
import ec.edu.uteq.biblio.api.dominio.ReglaNegocioException;
import ec.edu.uteq.biblio.api.dominio.Socio;
import ec.edu.uteq.biblio.api.negocio.PrestamoServicio;

/** Prueba de la capa de servicios web aislada: solo se cargan el controlador y el manejador de errores. */
@WebMvcTest(PrestamoControlador.class)
class PrestamoControladorTest {

    @Autowired
    private MockMvcTester mvc;

    @MockitoBean
    private PrestamoServicio servicio;

    private static final String CUERPO = """
            {"socioId": 1, "libroId": 10}
            """;

    @Test
    void registrarDevuelve201ConElPrestamo() {
        Libro libro = new Libro("978-1-4920-3402-5", "Building Microservices", "S. Newman", (short) 2021, 1);
        Socio socio = new Socio("E-0001", "Ana Torres", "ana.torres@uteq.edu.ec");
        Prestamo prestamo = Prestamo.registrar(libro, socio, LocalDate.of(2027, 2, 1), 7);
        when(servicio.registrar(1L, 10L)).thenReturn(prestamo);

        assertThat(mvc.post().uri("/api/v1/prestamos").contentType(MediaType.APPLICATION_JSON).content(CUERPO))
                .hasStatus(HttpStatus.CREATED)
                .bodyJson().extractingPath("$.estado").isEqualTo("ACTIVO");
    }

    @Test
    void cuerpoInvalidoDevuelve400EnFormatoProblemDetails() {
        assertThat(mvc.post().uri("/api/v1/prestamos").contentType(MediaType.APPLICATION_JSON)
                .content("{\"socioId\": -5}"))
                .hasStatus(HttpStatus.BAD_REQUEST)
                .hasContentType(MediaType.APPLICATION_PROBLEM_JSON);
    }

    @Test
    void reglaDeNegocioDevuelve422ConSuCodigo() {
        when(servicio.registrar(1L, 10L))
                .thenThrow(new ReglaNegocioException("SIN_EJEMPLARES", "No hay ejemplares"));

        assertThat(mvc.post().uri("/api/v1/prestamos").contentType(MediaType.APPLICATION_JSON).content(CUERPO))
                .hasStatus(HttpStatus.UNPROCESSABLE_CONTENT)
                .bodyJson().extractingPath("$.codigo").isEqualTo("SIN_EJEMPLARES");
    }

    @Test
    void conflictoDeConcurrenciaDevuelve409() {
        when(servicio.registrar(1L, 10L))
                .thenThrow(new ObjectOptimisticLockingFailureException(Libro.class, 10L));

        assertThat(mvc.post().uri("/api/v1/prestamos").contentType(MediaType.APPLICATION_JSON).content(CUERPO))
                .hasStatus(HttpStatus.CONFLICT);
    }
}
