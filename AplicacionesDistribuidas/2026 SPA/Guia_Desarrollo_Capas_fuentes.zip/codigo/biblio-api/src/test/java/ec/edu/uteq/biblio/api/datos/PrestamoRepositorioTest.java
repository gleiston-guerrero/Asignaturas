package ec.edu.uteq.biblio.api.datos;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.testcontainers.junit.jupiter.Testcontainers;

import ec.edu.uteq.biblio.api.ContenedoresPrueba;
import ec.edu.uteq.biblio.api.dominio.EstadoPrestamo;
import ec.edu.uteq.biblio.api.dominio.Libro;
import ec.edu.uteq.biblio.api.dominio.Prestamo;
import ec.edu.uteq.biblio.api.dominio.Socio;

/**
 * Prueba de la capa de acceso a datos contra PostgreSQL 18 real: valida el esquema
 * creado por Flyway, las consultas JPQL y las restricciones CHECK de la base de datos.
 */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(ContenedoresPrueba.class)
@Testcontainers(disabledWithoutDocker = true)
class PrestamoRepositorioTest {

    @Autowired
    private PrestamoRepositorio prestamos;
    @Autowired
    private LibroRepositorio libros;
    @Autowired
    private SocioRepositorio socios;
    @Autowired
    private JdbcTemplate jdbc;

    @Test
    void flywayCargaLosDatosIniciales() {
        assertThat(libros.count()).isEqualTo(4);
        assertThat(socios.count()).isEqualTo(3);
    }

    @Test
    void cuentaPrestamosActivosYTraeElDetalleEnUnaConsulta() {
        Socio socio = socios.findAllByOrderByNombres().getFirst();
        Libro libro = libros.findByIsbn("978-90-815406-3-6").orElseThrow();
        prestamos.save(Prestamo.registrar(libro, socio, LocalDate.of(2027, 2, 1), 7));

        assertThat(prestamos.countBySocioIdAndEstado(socio.getId(), EstadoPrestamo.ACTIVO)).isEqualTo(1);
        List<Prestamo> lista = prestamos.buscarPorSocio(socio.getId());
        assertThat(lista).hasSize(1);
        assertThat(lista.getFirst().getLibro().getTitulo()).isEqualTo("Distributed Systems");
    }

    @Test
    void laBaseDeDatosRechazaEjemplaresNegativosAunqueElCodigoFalle() {
        // Defensa en profundidad: la regla tambien esta en la base de datos (CHECK).
        assertThatThrownBy(() -> jdbc.update("UPDATE libro SET ejemplares_disponibles = -1 WHERE isbn = ?",
                "978-1-4920-3402-5"))
                .isInstanceOf(DataIntegrityViolationException.class);
    }
}
