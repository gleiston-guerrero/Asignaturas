package ec.edu.uteq.biblio.api.integracion;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.resttestclient.autoconfigure.AutoConfigureRestTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.client.RestTestClient;
import org.testcontainers.junit.jupiter.Testcontainers;

import ec.edu.uteq.biblio.api.ContenedoresPrueba;
import ec.edu.uteq.biblio.api.web.dto.LibroRespuesta;
import ec.edu.uteq.biblio.api.web.dto.PrestamoRespuesta;

/**
 * Prueba de integracion de extremo a extremo de biblio-api: servidor HTTP real en un
 * puerto aleatorio, las tres capas internas y PostgreSQL 18 en un contenedor.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureRestTestClient
@Import(ContenedoresPrueba.class)
@Testcontainers(disabledWithoutDocker = true)
class BiblioApiIntegracionTest {

    @Autowired
    private RestTestClient cliente;

    private LibroRespuesta crearLibro(String isbn, int ejemplares) {
        String cuerpo = """
                {"isbn": "%s", "titulo": "Libro de prueba %s", "autor": "Autor", "anio": 2026, "ejemplaresTotales": %d}
                """.formatted(isbn, isbn, ejemplares);
        return cliente.post().uri("/api/v1/libros").contentType(MediaType.APPLICATION_JSON).body(cuerpo)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().exists("Location")
                .returnResult(LibroRespuesta.class).getResponseBody();
    }

    private HttpStatus prestar(long socioId, long libroId) {
        int codigo = cliente.post().uri("/api/v1/prestamos").contentType(MediaType.APPLICATION_JSON)
                .body("{\"socioId\": %d, \"libroId\": %d}".formatted(socioId, libroId))
                .exchange()
                .returnResult(String.class).getStatus().value();
        return HttpStatus.valueOf(codigo);
    }

    @Test
    void cicloCompletoDePrestamoYDevolucion() {
        LibroRespuesta libro = crearLibro("978-0-00-000001-1", 1);

        PrestamoRespuesta prestamo = cliente.post().uri("/api/v1/prestamos").contentType(MediaType.APPLICATION_JSON)
                .body("{\"socioId\": 1, \"libroId\": %d}".formatted(libro.id()))
                .exchange()
                .expectStatus().isCreated()
                .returnResult(PrestamoRespuesta.class).getResponseBody();
        assertThat(prestamo.estado()).isEqualTo("ACTIVO");

        // Sin ejemplares: la regla de negocio llega al cliente como 422 con su codigo
        cliente.post().uri("/api/v1/prestamos").contentType(MediaType.APPLICATION_JSON)
                .body("{\"socioId\": 2, \"libroId\": %d}".formatted(libro.id()))
                .exchange()
                .expectStatus().isEqualTo(HttpStatus.UNPROCESSABLE_CONTENT)
                .expectBody().jsonPath("$.codigo").isEqualTo("SIN_EJEMPLARES");

        cliente.post().uri("/api/v1/prestamos/{id}/devolucion", prestamo.id())
                .exchange()
                .expectStatus().isOk()
                .expectBody().jsonPath("$.estado").isEqualTo("DEVUELTO");

        cliente.get().uri("/api/v1/libros/{id}", libro.id())
                .exchange()
                .expectBody().jsonPath("$.ejemplaresDisponibles").isEqualTo(1);
    }

    @Test
    void recursoInexistenteDevuelve404() {
        cliente.get().uri("/api/v1/libros/999999")
                .exchange()
                .expectStatus().isNotFound()
                .expectHeader().contentType(MediaType.APPLICATION_PROBLEM_JSON);
    }

    @Test
    void solicitudesSimultaneasNoPrestanMasEjemplaresDeLosQueExisten() throws Exception {
        LibroRespuesta libro = crearLibro("978-0-00-000002-8", 1);
        int clientes = 3; // los tres socios de los datos iniciales piden el unico ejemplar a la vez
        CountDownLatch salida = new CountDownLatch(1);
        List<Future<HttpStatus>> resultados = new ArrayList<>();

        try (ExecutorService hilos = Executors.newFixedThreadPool(clientes)) {
            for (long socio = 1; socio <= clientes; socio++) {
                long socioId = socio;
                Callable<HttpStatus> tarea = () -> {
                    salida.await(); // todos parten en el mismo instante
                    return prestar(socioId, libro.id());
                };
                resultados.add(hilos.submit(tarea));
            }
            salida.countDown();
        }

        long exitosos = 0;
        for (Future<HttpStatus> r : resultados) {
            HttpStatus estado = r.get();
            assertThat(estado).isIn(HttpStatus.CREATED, HttpStatus.CONFLICT, HttpStatus.UNPROCESSABLE_CONTENT);
            if (estado == HttpStatus.CREATED) {
                exitosos++;
            }
        }
        assertThat(exitosos).isEqualTo(1);
        cliente.get().uri("/api/v1/libros/{id}", libro.id())
                .exchange()
                .expectBody().jsonPath("$.ejemplaresDisponibles").isEqualTo(0);
    }
}
