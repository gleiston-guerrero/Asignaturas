# BiblioUTEQ: aplicacion distribuida en capas

Proyecto de ejemplo de la guia *Desarrollo de Aplicaciones Distribuidas por Capas* (Aplicaciones Distribuidas, ISR-701, UTEQ).

| Nivel | Modulo | Tecnologia | Puerto |
|---|---|---|---|
| Presentacion | `biblio-web` | Spring Boot 4.1.2, Thymeleaf, cliente HTTP declarativo | 8081 |
| Servicios y negocio | `biblio-api` | Spring Boot 4.1.2, Spring MVC, Spring Data JPA, Flyway | 8080 |
| Datos | contenedor `db` | PostgreSQL 18 | 5432 |

## Requisitos (Windows 11)

- JDK 27 (Eclipse Temurin) o JDK 25 LTS
- IntelliJ IDEA 2026.2 o posterior
- Docker Desktop (para PostgreSQL, Docker Compose y Testcontainers)
- Git

No hace falta instalar Maven: el proyecto trae Maven Wrapper (`mvnw.cmd`), que descarga Maven 3.9.16.

## Ejecutar todo con Docker Compose (PowerShell)

```powershell
.\mvnw.cmd -DskipTests package
docker compose up -d --build
```

- Aplicacion web: http://localhost:8081
- API REST: http://localhost:8080/api/v1/libros
- Contrato OpenAPI: http://localhost:8080/swagger-ui.html

## Pruebas

```powershell
.\mvnw.cmd verify
```

Ejecuta las pruebas unitarias, las de cada capa y las de integracion. Las que usan PostgreSQL real necesitan Docker Desktop en ejecucion; sin Docker se omiten.

## Variables de entorno

| Variable | Modulo | Valor por defecto |
|---|---|---|
| `DB_URL` | biblio-api | `jdbc:postgresql://localhost:5432/biblio` |
| `DB_USER`, `DB_PASSWORD` | biblio-api | `biblio` |
| `BIBLIO_API_URL` | biblio-web | `http://localhost:8080` |
