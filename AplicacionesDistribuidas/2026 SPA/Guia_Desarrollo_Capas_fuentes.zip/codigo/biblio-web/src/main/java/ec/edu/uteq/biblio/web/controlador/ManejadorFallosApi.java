package ec.edu.uteq.biblio.web.controlador;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

/**
 * Fallo parcial: si el nivel del API no responde (caido, lento o con error interno),
 * la capa de presentacion sigue viva y muestra una pagina controlada.
 */
@ControllerAdvice
public class ManejadorFallosApi {

    private static final Logger LOG = LoggerFactory.getLogger(ManejadorFallosApi.class);

    @ExceptionHandler({ ResourceAccessException.class, HttpServerErrorException.class })
    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    public String apiNoDisponible(Exception ex) {
        LOG.warn("El API de biblioteca no esta disponible: {}", ex.getMessage());
        return "servicio-no-disponible";
    }
}
