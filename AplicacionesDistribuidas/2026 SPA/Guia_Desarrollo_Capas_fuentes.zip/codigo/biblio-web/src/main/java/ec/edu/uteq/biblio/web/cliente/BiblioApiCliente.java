package ec.edu.uteq.biblio.web.cliente;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;
import org.springframework.web.service.annotation.PostExchange;

import ec.edu.uteq.biblio.web.cliente.Modelos.LibroDatos;
import ec.edu.uteq.biblio.web.cliente.Modelos.PrestamoDatos;
import ec.edu.uteq.biblio.web.cliente.Modelos.SocioDatos;
import ec.edu.uteq.biblio.web.cliente.Modelos.SolicitudPrestamo;

/**
 * Cliente HTTP declarativo. Spring crea en tiempo de ejecucion un objeto que
 * implementa esta interfaz y traduce cada llamada a una solicitud HTTP al API
 * (patron Proxy remoto): el controlador lo usa como si fuera un objeto local.
 */
@HttpExchange("/api/v1")
public interface BiblioApiCliente {

    @GetExchange("/libros")
    List<LibroDatos> listarLibros(@RequestParam(name = "q", required = false) String texto);

    @GetExchange("/socios")
    List<SocioDatos> listarSocios();

    @GetExchange("/socios/{id}/prestamos")
    List<PrestamoDatos> prestamosDelSocio(@PathVariable Long id);

    @PostExchange("/prestamos")
    PrestamoDatos registrarPrestamo(@RequestBody SolicitudPrestamo solicitud);

    @PostExchange("/prestamos/{id}/devolucion")
    PrestamoDatos devolver(@PathVariable Long id);
}
