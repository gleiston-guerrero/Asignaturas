package ec.edu.uteq.biblio.web.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ec.edu.uteq.biblio.web.cliente.BiblioApiCliente;

/** Capa de presentacion: prepara los datos de la vista; la logica de negocio vive en el API. */
@Controller
public class CatalogoWebControlador {

    private final BiblioApiCliente api;

    public CatalogoWebControlador(BiblioApiCliente api) {
        this.api = api;
    }

    @GetMapping("/")
    public String catalogo(@RequestParam(name = "q", required = false) String texto, Model modelo) {
        modelo.addAttribute("libros", api.listarLibros(texto));
        modelo.addAttribute("q", texto);
        return "catalogo";
    }
}
