package ec.edu.uteq.biblio.web.controlador;

import java.util.List;

import org.springframework.http.ProblemDetail;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ec.edu.uteq.biblio.web.cliente.BiblioApiCliente;
import ec.edu.uteq.biblio.web.cliente.Modelos.PrestamoDatos;
import ec.edu.uteq.biblio.web.cliente.Modelos.SolicitudPrestamo;

@Controller
public class PrestamoWebControlador {

    private final BiblioApiCliente api;

    public PrestamoWebControlador(BiblioApiCliente api) {
        this.api = api;
    }

    @GetMapping("/prestamos")
    public String prestamos(@RequestParam(name = "socioId", required = false) Long socioId, Model modelo) {
        modelo.addAttribute("socios", api.listarSocios());
        modelo.addAttribute("libros", api.listarLibros(null));
        modelo.addAttribute("socioId", socioId);
        List<PrestamoDatos> lista = socioId == null ? List.of() : api.prestamosDelSocio(socioId);
        modelo.addAttribute("prestamos", lista);
        return "prestamos";
    }

    @PostMapping("/prestamos")
    public String registrar(@RequestParam Long socioId, @RequestParam Long libroId, RedirectAttributes flash) {
        try {
            PrestamoDatos p = api.registrarPrestamo(new SolicitudPrestamo(socioId, libroId));
            flash.addFlashAttribute("exito", "Pr\u00e9stamo registrado. Vence el " + p.fechaVencimiento() + ".");
        } catch (HttpClientErrorException ex) {
            flash.addFlashAttribute("error", detalle(ex));
        }
        return "redirect:/prestamos?socioId=" + socioId;
    }

    @PostMapping("/prestamos/{id}/devolucion")
    public String devolver(@PathVariable Long id, @RequestParam Long socioId, RedirectAttributes flash) {
        try {
            PrestamoDatos p = api.devolver(id);
            flash.addFlashAttribute("exito", "Devoluci\u00f3n registrada. Multa: $" + p.multa() + ".");
        } catch (HttpClientErrorException ex) {
            flash.addFlashAttribute("error", detalle(ex));
        }
        return "redirect:/prestamos?socioId=" + socioId;
    }

    /** Muestra al usuario el campo "detail" del Problem Details que devolvio el API. */
    private static String detalle(HttpClientErrorException ex) {
        ProblemDetail problema = ex.getResponseBodyAs(ProblemDetail.class);
        return problema != null && problema.getDetail() != null ? problema.getDetail() : ex.getStatusText();
    }
}
