package ec.edu.uteq.biblio.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiblioWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(BiblioWebApplication.class, args);
    }
}
