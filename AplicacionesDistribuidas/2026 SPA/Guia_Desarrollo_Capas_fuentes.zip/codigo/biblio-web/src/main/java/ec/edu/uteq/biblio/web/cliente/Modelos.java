package ec.edu.uteq.biblio.web.cliente;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Representaciones que la capa de presentacion recibe del API. Son copias propias
 * del contrato JSON: biblio-web no depende del codigo de biblio-api, solo de su API.
 */
public final class Modelos {

    private Modelos() {
    }

    public record LibroDatos(Long id, String isbn, String titulo, String autor, short anio,
            int ejemplaresTotales, int ejemplaresDisponibles) {
    }

    public record SocioDatos(Long id, String codigo, String nombres, String correo, boolean activo) {
    }

    public record PrestamoDatos(Long id, Long socioId, String codigoSocio, Long libroId, String tituloLibro,
            LocalDate fechaPrestamo, LocalDate fechaVencimiento, LocalDate fechaDevolucion,
            String estado, BigDecimal multa) {
    }

    public record SolicitudPrestamo(Long socioId, Long libroId) {
    }
}
