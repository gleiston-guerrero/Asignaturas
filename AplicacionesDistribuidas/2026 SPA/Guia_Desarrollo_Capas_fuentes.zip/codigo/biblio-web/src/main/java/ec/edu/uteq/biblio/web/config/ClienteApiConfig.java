package ec.edu.uteq.biblio.web.config;

import java.net.http.HttpClient;
import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.support.RestClientAdapter;
import org.springframework.web.service.invoker.HttpServiceProxyFactory;

import ec.edu.uteq.biblio.web.cliente.BiblioApiCliente;

/**
 * Configura la comunicacion entre niveles: URL del API (por variable de entorno)
 * y tiempos de espera. Sin tiempos de espera, una caida del API dejaria colgadas
 * las solicitudes de los usuarios de la aplicacion web.
 */
@Configuration
public class ClienteApiConfig {

    @Bean
    BiblioApiCliente biblioApiCliente(RestClient.Builder builder,
            @Value("${biblio.api.url}") String urlApi,
            @Value("${biblio.api.timeout-conexion:2s}") Duration timeoutConexion,
            @Value("${biblio.api.timeout-lectura:5s}") Duration timeoutLectura) {

        HttpClient http = HttpClient.newBuilder().connectTimeout(timeoutConexion).build();
        JdkClientHttpRequestFactory fabrica = new JdkClientHttpRequestFactory(http);
        fabrica.setReadTimeout(timeoutLectura);

        RestClient restClient = builder.baseUrl(urlApi).requestFactory(fabrica).build();
        return HttpServiceProxyFactory.builderFor(RestClientAdapter.create(restClient))
                .build()
                .createClient(BiblioApiCliente.class);
    }
}
