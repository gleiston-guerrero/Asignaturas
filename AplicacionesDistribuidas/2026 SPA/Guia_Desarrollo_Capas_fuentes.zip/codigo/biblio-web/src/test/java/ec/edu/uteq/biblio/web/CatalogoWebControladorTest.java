package ec.edu.uteq.biblio.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.assertj.MockMvcTester;
import org.springframework.web.client.ResourceAccessException;

import ec.edu.uteq.biblio.web.cliente.BiblioApiCliente;
import ec.edu.uteq.biblio.web.cliente.Modelos.LibroDatos;
import ec.edu.uteq.biblio.web.controlador.CatalogoWebControlador;
import ec.edu.uteq.biblio.web.controlador.ManejadorFallosApi;

/** La capa de presentacion se prueba sin el API: el cliente HTTP se simula. */
@WebMvcTest({ CatalogoWebControlador.class, ManejadorFallosApi.class })
class CatalogoWebControladorTest {

    @Autowired
    private MockMvcTester mvc;

    @MockitoBean
    private BiblioApiCliente api;

    @Test
    void muestraLosLibrosQueDevuelveElApi() {
        when(api.listarLibros(null)).thenReturn(List.of(
                new LibroDatos(1L, "978-90-815406-3-6", "Distributed Systems", "M. van Steen", (short) 2023, 3, 0)));

        assertThat(mvc.get().uri("/"))
                .hasStatusOk()
                .hasViewName("catalogo")
                .bodyText().contains("Distributed Systems").contains("0 de 3");
    }

    @Test
    void siElApiNoRespondeMuestraUnaPaginaControlada() {
        when(api.listarLibros(null)).thenThrow(new ResourceAccessException("Connection refused"));

        assertThat(mvc.get().uri("/"))
                .hasStatus(HttpStatus.SERVICE_UNAVAILABLE)
                .hasViewName("servicio-no-disponible");
    }
}
