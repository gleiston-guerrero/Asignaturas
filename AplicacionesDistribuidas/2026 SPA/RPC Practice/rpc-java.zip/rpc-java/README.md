# RPC desde cero en Java (ISR-701, UTEQ)

Codigo base de la guia de practica. Sin dependencias externas.

## Versiones

| Elemento | Version |
|---|---|
| Sistema operativo | Windows 10 u 11 (64 bits) |
| IDE | IntelliJ IDEA 2025.3.1 |
| JDK | 21 LTS (recomendado Eclipse Temurin 21.0.x; probado con OpenJDK 21.0.12) |
| Language level | 21 |
| Build system | IntelliJ (sin Maven ni Gradle) |
| Red | TCP, puerto 5000 |

## Uso en IntelliJ IDEA 2025.3.1

1. File | New | Project -> Java. Name: `rpc-java`, Build system: IntelliJ, JDK: 21 (si no aparece, Download JDK... -> version 21, Eclipse Temurin), Add sample code: desmarcado. Create.
2. Copie los archivos de `src/` de este paquete en la carpeta `src` del proyecto (sin paquete).
3. Build | Build Project (Ctrl+F9).
4. Ejecute `ServidorRPC` (flecha verde junto a `main`) y luego `ClienteApp`.
5. Argumentos opcionales en Run | Edit Configurations -> Program arguments: servidor `5000`; cliente `localhost 5000`.

## Alternativa desde la terminal (PowerShell, JDK 21 en el PATH)

    $cp = "out\production\rpc-java"
    javac --release 21 -d $cp src\*.java
    java -cp $cp ServidorRPC 5000
    java -cp $cp ClienteApp localhost 5000

## Archivos (en el orden de los pasos)

1. `Calculadora.java` contrato compartido (IDL)
2. `Peticion.java`, `Respuesta.java` mensajes serializables
3. `CalculadoraImpl.java` procedimiento real
4. `ServidorStub.java` stub del servidor (skeleton)
5. `ServidorRPC.java` runtime del servidor (ServerSocket + hilos)
6. `ClienteStub.java` stub del cliente (proxy)
7. `ClienteApp.java` programa cliente
