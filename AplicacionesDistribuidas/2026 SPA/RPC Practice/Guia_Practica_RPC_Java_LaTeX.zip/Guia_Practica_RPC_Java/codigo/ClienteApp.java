// PASO 7. Programa cliente: solo conoce la interfaz Calculadora.
// Las llamadas se escriben igual que si fueran locales (transparencia de acceso).
public class ClienteApp {
    public static void main(String[] args) throws Exception {
        String host = args.length > 0 ? args[0] : "localhost";
        int puerto = args.length > 1 ? Integer.parseInt(args[1]) : 5000;

        try (ClienteStub stub = new ClienteStub(host, puerto)) {
            Calculadora calc = stub;

            System.out.println("sumar(7, 5)      = " + calc.sumar(7, 5));
            System.out.println("dividir(10, 4)   = " + calc.dividir(10, 4));
            System.out.println("saludar(\"UTEQ\") = " + calc.saludar("UTEQ"));

            try {
                calc.dividir(1, 0);
            } catch (ClienteStub.ErrorRemoto e) {
                System.out.println("dividir(1, 0)    -> error remoto: " + e.getMessage());
            }
        }
    }
}
