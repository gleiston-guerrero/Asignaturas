import java.io.EOFException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

// PASO 5. Runtime del servidor: escucha en un puerto TCP, atiende cada cliente
// en su propio hilo y entrega cada peticion al stub del servidor.
public class ServidorRPC {
    public static void main(String[] args) throws Exception {
        int puerto = args.length > 0 ? Integer.parseInt(args[0]) : 5000;
        ServidorStub stub = new ServidorStub(new CalculadoraImpl());
        try (ServerSocket servidor = new ServerSocket(puerto)) {
            System.out.println("[Servidor] Escuchando en el puerto " + puerto);
            while (true) {
                Socket cliente = servidor.accept();
                new Thread(() -> atender(cliente, stub)).start();
            }
        }
    }

    private static void atender(Socket socket, ServidorStub stub) {
        String quien = socket.getRemoteSocketAddress().toString();
        System.out.println("[Servidor] Cliente conectado: " + quien);
        try (socket;
             ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream())) {
            while (true) {
                Peticion p = (Peticion) entrada.readObject();      // unmarshalling
                System.out.println("[Servidor] Peticion " + p.metodo() + " de " + quien);
                Respuesta r = stub.despachar(p);
                salida.writeObject(r);                              // marshalling
                salida.flush();
            }
        } catch (EOFException fin) {
            System.out.println("[Servidor] Cliente desconectado: " + quien);
        } catch (Exception e) {
            System.out.println("[Servidor] Error con " + quien + ": " + e);
        }
    }
}
