import java.io.Serializable;

// PASO 2. Mensaje de peticion: nombre del procedimiento y sus parametros.
// Serializable permite convertirlo en bytes (marshalling) para enviarlo por la red.
public record Peticion(String metodo, Object[] args) implements Serializable {
}
