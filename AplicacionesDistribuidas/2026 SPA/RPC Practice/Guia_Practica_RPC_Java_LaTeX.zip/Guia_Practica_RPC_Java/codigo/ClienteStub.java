import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

// PASO 6. Stub del cliente (proxy): implementa la MISMA interfaz que el servidor,
// de modo que el programa cliente cree que llama a un metodo local.
// Por dentro empaqueta la llamada, la envia, espera y desempaqueta la respuesta.
public class ClienteStub implements Calculadora, AutoCloseable {

    public static class ErrorRemoto extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public ErrorRemoto(String mensaje) { super(mensaje); }
    }

    private final Socket socket;
    private final ObjectOutputStream salida;
    private final ObjectInputStream entrada;

    public ClienteStub(String host, int puerto) throws IOException {
        socket = new Socket(host, puerto);
        salida = new ObjectOutputStream(socket.getOutputStream());
        salida.flush();
        entrada = new ObjectInputStream(socket.getInputStream());
    }

    private synchronized Object invocar(String metodo, Object... args) {
        try {
            salida.writeObject(new Peticion(metodo, args));   // marshalling
            salida.reset();
            salida.flush();
            Respuesta r = (Respuesta) entrada.readObject();   // espera bloqueante
            if (r.esError()) {
                throw new ErrorRemoto(r.error());
            }
            return r.valor();
        } catch (IOException | ClassNotFoundException e) {
            throw new ErrorRemoto("fallo de comunicacion: " + e.getMessage());
        }
    }

    @Override
    public int sumar(int a, int b) {
        return (Integer) invocar("sumar", a, b);
    }

    @Override
    public double dividir(double a, double b) {
        return (Double) invocar("dividir", a, b);
    }

    @Override
    public String saludar(String nombre) {
        return (String) invocar("saludar", nombre);
    }

    @Override
    public void close() throws IOException {
        socket.close();
    }
}
