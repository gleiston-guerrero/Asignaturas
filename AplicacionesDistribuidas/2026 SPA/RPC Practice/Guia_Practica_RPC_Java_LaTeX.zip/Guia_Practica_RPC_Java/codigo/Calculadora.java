// PASO 1. Contrato del servicio (equivale a la IDL del RPC clasico).
// Cliente y servidor comparten esta interfaz; ninguno conoce el codigo del otro.
public interface Calculadora {
    int sumar(int a, int b);
    double dividir(double a, double b);
    String saludar(String nombre);
}
