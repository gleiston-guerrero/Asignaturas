# Guia de practica: RPC desde cero en Java (ISR-701, UTEQ)

Archivo principal: `Guia_Practica_RPC_Java.tex`. Los listados de codigo se leen desde `codigo/`.

Compilacion (MiKTeX o TeX Live, desde esta carpeta):

    pdflatex Guia_Practica_RPC_Java.tex
    biber Guia_Practica_RPC_Java
    pdflatex Guia_Practica_RPC_Java.tex
    pdflatex Guia_Practica_RPC_Java.tex

Paquetes: babel (spanish), biblatex + biber (style=ieee), tcolorbox, xltabular, booktabs, listings, tikz, needspace, fancyhdr, titlesec, xurl.
