// ===================================================================
// 1. CANAL DE EVENTOS DEL SERVIDOR (SSE)
// ===================================================================

// EventSource abre una conexion HTTP que el servidor NO cierra, y por
// la que va empujando eventos. Reconecta sola si se corta.
const flujo = new EventSource("/api/flujo");

const estado = document.getElementById("estado");

flujo.onopen = () => {
	estado.textContent = "Conectado";
	estado.className = "estado conectado";
};

flujo.onerror = () => {
	estado.textContent = "Desconectado";
	estado.className = "estado desconectado";
};

// El nombre del evento ("cola" u "topico") lo puso el backend en
// SseEmitter.event().name(...). Por eso podemos escuchar cada uno
// por separado y pintarlos en columnas distintas.
flujo.addEventListener("cola",   e => pintar("cola",   JSON.parse(e.data)));
flujo.addEventListener("topico", e => pintar("topico", JSON.parse(e.data)));

// ===================================================================
// 2. PINTADO DE FILAS
// ===================================================================

const contadores = {
	"TEC-01":      document.getElementById("cTec01"),
	"TEC-02":      document.getElementById("cTec02"),
	"TEC-03":      document.getElementById("cTec03"),
	"NOTIFICADOR": document.getElementById("cNot"),
	"MONITOR SLA": document.getElementById("cSla"),
	"AUDITORIA":   document.getElementById("cAud")
};

function pintar(canal, fila) {

	const lista = document.getElementById(
		canal === "cola" ? "listaCola" : "listaTopico");

	const li = document.createElement("li");
	li.innerHTML =
		'<span class="hora">' + hora(fila.instante) + '</span>' +
		'<span class="actor">' + fila.actor + '</span> &middot; ' +
		fila.ticketId + '<br>' + fila.detalle;

	// insertBefore con firstChild pone lo nuevo ARRIBA.
	lista.insertBefore(li, lista.firstChild);

	const c = contadores[fila.actor];
	if (c) c.textContent = parseInt(c.textContent, 10) + 1;
}

function hora(instante) {
	// El backend envia un Instant serializado en ISO-8601.
	return new Date(instante).toLocaleTimeString("es-EC");
}

// ===================================================================
// 3. ENVIO DE TICKETS
// ===================================================================

document.getElementById("btnEnviar").addEventListener("click", async () => {

	const cuerpo = {
		cliente:     document.getElementById("cliente").value,
		servicio:    document.getElementById("servicio").value,
		prioridad:   document.getElementById("prioridad").value,
		descripcion: document.getElementById("descripcion").value
	};

	const respuesta = await fetch("/api/tickets", {
		method:  "POST",
		headers: { "Content-Type": "application/json" },
		body:    JSON.stringify(cuerpo)
	});

	if (!respuesta.ok) {
		alert("Error al enviar el ticket: " + respuesta.status);
	}
	// No hace falta hacer nada mas: la respuesta visible llegara por SSE
	// cuando un tecnico tome el ticket. Eso ES el desacoplamiento.
});

document.getElementById("btnLote").addEventListener("click", async () => {
	await fetch("/api/tickets/lote/9", { method: "POST" });
});

document.getElementById("btnLimpiar").addEventListener("click", () => {
	document.getElementById("listaCola").innerHTML = "";
	document.getElementById("listaTopico").innerHTML = "";
	Object.values(contadores).forEach(c => c.textContent = "0");
});
