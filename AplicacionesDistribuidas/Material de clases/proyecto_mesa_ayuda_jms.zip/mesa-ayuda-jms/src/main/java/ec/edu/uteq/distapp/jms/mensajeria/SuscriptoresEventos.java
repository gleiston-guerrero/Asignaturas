package ec.edu.uteq.distapp.jms.mensajeria;

import ec.edu.uteq.distapp.jms.config.JmsConfig;
import ec.edu.uteq.distapp.jms.dominio.EventoTicket;
import ec.edu.uteq.distapp.jms.web.FilaTablero;
import ec.edu.uteq.distapp.jms.web.TableroSse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import java.time.Instant;

/**
 * Tres suscriptores INDEPENDIENTES al MISMO TOPICO.
 *
 * Cada uno recibe SU PROPIA COPIA de cada evento.
 * Ninguno sabe que los otros existen. El publicador tampoco.
 *
 * Prueba de extensibilidad: para anadir un cuarto interesado basta con
 * escribir otro metodo con @JmsListener aqui abajo. Ni el productor ni
 * los otros tres suscriptores se enteran ni cambian.
 */
@Component
public class SuscriptoresEventos {

	private static final Logger log = LoggerFactory.getLogger(SuscriptoresEventos.class);

	private final TableroSse tablero;

	public SuscriptoresEventos(TableroSse tablero) {
		this.tablero = tablero;
	}

	// ---------------------------------------------------------------
	// SUSCRIPTOR 1: notificacion al cliente. NO durable.
	// Si estuvo caido, no queremos inundar al cliente con avisos viejos.
	// ---------------------------------------------------------------

	@JmsListener(destination = JmsConfig.TOPICO_EVENTOS, containerFactory = "fabricaTopico")
	public void notificarCliente(EventoTicket evento) {

		String detalle = "Correo a " + evento.cliente()
				+ ": su ticket " + evento.ticketId() + " esta " + evento.estadoNuevo();

		log.info("<-- TOPICO  | NOTIFICADOR  | {}", detalle);
		publicar("NOTIFICADOR", evento, detalle);
	}

	// ---------------------------------------------------------------
	// SUSCRIPTOR 2: monitor de acuerdos de nivel de servicio. NO durable.
	// ---------------------------------------------------------------

	@JmsListener(destination = JmsConfig.TOPICO_EVENTOS, containerFactory = "fabricaTopico")
	public void monitorearSla(EventoTicket evento) {

		int limite = evento.prioridad().minutosSla();
		String detalle = "Cronometro SLA iniciado: " + limite
				+ " min para el ticket " + evento.ticketId();

		log.info("<-- TOPICO  | MONITOR SLA  | {}", detalle);
		publicar("MONITOR SLA", evento, detalle);
	}

	// ---------------------------------------------------------------
	// SUSCRIPTOR 3: auditoria. DURABLE.
	// Un registro de auditoria con huecos no sirve como evidencia,
	// asi que este suscriptor SI debe recibir lo que se publico
	// mientras estuvo desconectado.
	// ---------------------------------------------------------------

	@JmsListener(destination = JmsConfig.TOPICO_EVENTOS,
				 containerFactory = "fabricaTopicoDurable",
				 subscription = "suscripcion-auditoria")
	public void registrarAuditoria(EventoTicket evento) {

		String detalle = "AUDIT " + evento.ocurridoEn() + " | ticket " + evento.ticketId()
				+ " | " + evento.estadoAnterior() + " -> " + evento.estadoNuevo()
				+ " | por " + evento.tecnico();

		log.info("<-- TOPICO  | AUDITORIA    | {}", detalle);
		publicar("AUDITORIA", evento, detalle);
	}

	// ---------------------------------------------------------------

	private void publicar(String suscriptor, EventoTicket evento, String detalle) {
		tablero.difundir("topico", new FilaTablero(
				"topico", suscriptor, evento.ticketId(), evento.cliente(),
				detalle, Instant.now().toString()));
	}
}
