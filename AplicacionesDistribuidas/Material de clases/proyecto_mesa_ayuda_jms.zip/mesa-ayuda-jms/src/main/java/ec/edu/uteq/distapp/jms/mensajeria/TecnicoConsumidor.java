package ec.edu.uteq.distapp.jms.mensajeria;

import ec.edu.uteq.distapp.jms.config.JmsConfig;
import ec.edu.uteq.distapp.jms.dominio.EventoTicket;
import ec.edu.uteq.distapp.jms.dominio.Ticket;
import ec.edu.uteq.distapp.jms.web.FilaTablero;
import ec.edu.uteq.distapp.jms.web.TableroSse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Tres tecnicos escuchando LA MISMA COLA.
 *
 * Patron: Competing Consumers. El broker entrega cada ticket a UNO SOLO
 * de los tres. Repartir la carga NO requiere ni una linea de logica
 * nuestra: lo hace el broker.
 */
@Component
public class TecnicoConsumidor {

	private static final Logger log = LoggerFactory.getLogger(TecnicoConsumidor.class);

	private final TicketProductor productor;
	private final TableroSse tablero;

	// Contadores para demostrar el reparto. AtomicInteger es seguro
	// entre hilos: cada tecnico corre en un hilo distinto.
	private final AtomicInteger totalTec01 = new AtomicInteger();
	private final AtomicInteger totalTec02 = new AtomicInteger();
	private final AtomicInteger totalTec03 = new AtomicInteger();

	public TecnicoConsumidor(TicketProductor productor, TableroSse tablero) {
		this.productor = productor;
		this.tablero = tablero;
	}

	// ---------------------------------------------------------------
	// LOS TRES OYENTES: mismo destino, misma fabrica, metodos distintos
	// ---------------------------------------------------------------

	@JmsListener(destination = JmsConfig.COLA_TICKETS, containerFactory = "fabricaCola")
	public void tecnicoUno(Ticket ticket) {
		atender("TEC-01", ticket, totalTec01.incrementAndGet());
	}

	@JmsListener(destination = JmsConfig.COLA_TICKETS, containerFactory = "fabricaCola")
	public void tecnicoDos(Ticket ticket) {
		atender("TEC-02", ticket, totalTec02.incrementAndGet());
	}

	@JmsListener(destination = JmsConfig.COLA_TICKETS, containerFactory = "fabricaCola")
	public void tecnicoTres(Ticket ticket) {
		atender("TEC-03", ticket, totalTec03.incrementAndGet());
	}

	// ---------------------------------------------------------------
	// LOGICA COMPARTIDA
	// ---------------------------------------------------------------

	private void atender(String tecnico, Ticket ticket, int acumulado) {

		log.info("<-- COLA    | {} recibe el ticket {} (lleva {}) [hilo {}]",
				tecnico, ticket.id(), acumulado, Thread.currentThread().getName());

		// El navegador ve al instante quien lo tomo.
		tablero.difundir("cola", new FilaTablero(
				"cola", tecnico, ticket.id(), ticket.cliente(),
				"Ticket asignado a " + tecnico, Instant.now().toString()));

		// Simulamos el trabajo real del tecnico.
		simularTrabajo(700);

		// Terminado el trabajo, se PUBLICA el hecho en el topico.
		// Aqui es donde la cola se convierte en topico.
		productor.publicarEvento(new EventoTicket(
				ticket.id(),
				ticket.cliente(),
				ticket.prioridad(),
				"NUEVO",
				"EN_ATENCION",
				tecnico,
				Instant.now()));
	}

	private void simularTrabajo(long milisegundos) {
		try {
			Thread.sleep(milisegundos);
		} catch (InterruptedException e) {
			// Buena practica: restaurar la marca de interrupcion del hilo.
			Thread.currentThread().interrupt();
		}
	}
}
