package ec.edu.uteq.distapp.jms.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Mantiene la lista de navegadores conectados y les empuja eventos.
 *
 * No tiene NADA que ver con JMS: es solo el cable entre el backend y
 * la pantalla. Se ha separado a proposito para que quede claro donde
 * termina la mensajeria y donde empieza la interfaz.
 */
@Component
public class TableroSse {

	private static final Logger log = LoggerFactory.getLogger(TableroSse.class);

	/**
	 * CopyOnWriteArrayList es una lista segura entre hilos, optimizada
	 * para muchas lecturas y pocas escrituras: justo nuestro caso,
	 * porque los seis consumidores leen constantemente y solo se
	 * escribe cuando un navegador se conecta o se va.
	 */
	private final List<SseEmitter> emisores = new CopyOnWriteArrayList<>();

	/** Registra un navegador nuevo y le devuelve su canal. */
	public SseEmitter registrar() {

		// 0L significa "sin tiempo de expiracion".
		SseEmitter emisor = new SseEmitter(0L);

		emisor.onCompletion(() -> emisores.remove(emisor));
		emisor.onTimeout(() -> emisores.remove(emisor));
		emisor.onError(error -> emisores.remove(emisor));

		emisores.add(emisor);
		log.info("Tablero: navegador conectado. Total: {}", emisores.size());
		return emisor;
	}

	/**
	 * Envia una fila a TODOS los navegadores conectados.
	 * El parametro canal se convierte en el nombre del evento SSE,
	 * que el JavaScript usara para decidir en que columna pintarlo.
	 */
	public void difundir(String canal, FilaTablero fila) {
		for (SseEmitter emisor : emisores) {
			try {
				emisor.send(SseEmitter.event().name(canal).data(fila));
			} catch (IOException e) {
				// El navegador cerro la pestana. No es un error real.
				emisores.remove(emisor);
			}
		}
	}
}
