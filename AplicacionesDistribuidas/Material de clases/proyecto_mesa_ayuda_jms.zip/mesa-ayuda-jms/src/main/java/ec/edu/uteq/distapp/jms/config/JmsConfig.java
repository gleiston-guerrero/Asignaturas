package ec.edu.uteq.distapp.jms.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.jms.ConnectionFactory;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;

@Configuration
public class JmsConfig {

	// ---------------------------------------------------------------
	// NOMBRES DE LOS DESTINOS
	// Son constantes (static final) porque @JmsListener exige valores
	// conocidos en tiempo de compilacion.
	// ---------------------------------------------------------------

	/** COLA: cada ticket lo atiende UN SOLO tecnico. */
	public static final String COLA_TICKETS = "soporte.tickets.cola";

	/** TOPICO: cada evento lo reciben TODOS los suscriptores. */
	public static final String TOPICO_EVENTOS = "soporte.tickets.eventos";

	// ---------------------------------------------------------------
	// CONVERSOR: objeto Java  <-->  mensaje JMS
	// ---------------------------------------------------------------

	/**
	 * Convierte nuestros records a JSON dentro de un TextMessage.
	 *
	 * IMPORTANTE: recibimos por parametro el ObjectMapper que Spring Boot
	 * ya ha configurado. Si dejaramos que MappingJackson2MessageConverter
	 * creara el suyo propio, ese no tendria registrado el modulo de
	 * fechas de Java 8 y al enviar un Instant fallaria con:
	 *   InvalidDefinitionException: Java 8 date/time type
	 *   `java.time.Instant` not supported by default
	 */
	@Bean
	public MessageConverter conversorJackson(ObjectMapper objectMapper) {
		MappingJackson2MessageConverter conversor = new MappingJackson2MessageConverter();
		conversor.setObjectMapper(objectMapper);

		// El cuerpo sera texto (JSON), no bytes ni objeto serializado.
		conversor.setTargetType(MessageType.TEXT);

		// El conversor escribe en esta propiedad el nombre de la clase,
		// para que el consumidor sepa a que tipo deserializar.
		conversor.setTypeIdPropertyName("_tipo");

		return conversor;
	}

	// ---------------------------------------------------------------
	// PLANTILLAS DE ENVIO
	// Dos plantillas distintas porque pubSubDomain es una propiedad
	// del objeto, no del metodo. Una plantilla habla SIEMPRE con colas
	// o SIEMPRE con topicos.
	// ---------------------------------------------------------------

	/** Plantilla para COLAS. @Primary evita ambiguedad al inyectar. */
	@Bean
	@Primary
	public JmsTemplate plantillaCola(ConnectionFactory fabricaConexiones,
									 MessageConverter conversorJackson) {
		JmsTemplate plantilla = new JmsTemplate(fabricaConexiones);
		plantilla.setPubSubDomain(false);          // <-- COLA
		plantilla.setMessageConverter(conversorJackson);
		return plantilla;
	}

	/** Plantilla para TOPICOS. */
	@Bean
	public JmsTemplate plantillaTopico(ConnectionFactory fabricaConexiones,
									   MessageConverter conversorJackson) {
		JmsTemplate plantilla = new JmsTemplate(fabricaConexiones);
		plantilla.setPubSubDomain(true);           // <-- TOPICO
		plantilla.setMessageConverter(conversorJackson);
		return plantilla;
	}

	// ---------------------------------------------------------------
	// FABRICAS DE CONTENEDORES DE ESCUCHA
	// Cada @JmsListener elige su fabrica por nombre. La fabrica decide
	// si escucha una cola o un topico.
	// ---------------------------------------------------------------

	/** Fabrica para escuchar COLAS. */
	@Bean
	public DefaultJmsListenerContainerFactory fabricaCola(
			ConnectionFactory fabricaConexiones,
			DefaultJmsListenerContainerFactoryConfigurer configurador,
			MessageConverter conversorJackson) {

		DefaultJmsListenerContainerFactory fabrica = new DefaultJmsListenerContainerFactory();

		// Primero aplicamos lo que venga de application.properties...
		configurador.configure(fabrica, fabricaConexiones);

		// ...y DESPUES fijamos lo nuestro, para que no lo sobrescriba.
		fabrica.setPubSubDomain(false);            // <-- COLA
		fabrica.setMessageConverter(conversorJackson);

		return fabrica;
	}

	/** Fabrica para escuchar TOPICOS con suscripcion NO durable. */
	@Bean
	public DefaultJmsListenerContainerFactory fabricaTopico(
			ConnectionFactory fabricaConexiones,
			DefaultJmsListenerContainerFactoryConfigurer configurador,
			MessageConverter conversorJackson) {

		DefaultJmsListenerContainerFactory fabrica = new DefaultJmsListenerContainerFactory();
		configurador.configure(fabrica, fabricaConexiones);

		fabrica.setPubSubDomain(true);             // <-- TOPICO
		fabrica.setSubscriptionDurable(false);     // no durable
		fabrica.setMessageConverter(conversorJackson);

		return fabrica;
	}

	/**
	 * Fabrica para escuchar TOPICOS con suscripcion DURABLE.
	 * El identificador de cliente debe ser unico en todo el broker.
	 */
	@Bean
	public DefaultJmsListenerContainerFactory fabricaTopicoDurable(
			ConnectionFactory fabricaConexiones,
			DefaultJmsListenerContainerFactoryConfigurer configurador,
			MessageConverter conversorJackson) {

		DefaultJmsListenerContainerFactory fabrica = new DefaultJmsListenerContainerFactory();
		configurador.configure(fabrica, fabricaConexiones);

		fabrica.setPubSubDomain(true);             // <-- TOPICO
		fabrica.setSubscriptionDurable(true);      // <-- DURABLE
		fabrica.setClientId("auditoria-mesa-ayuda");
		fabrica.setMessageConverter(conversorJackson);

		return fabrica;
	}
}
