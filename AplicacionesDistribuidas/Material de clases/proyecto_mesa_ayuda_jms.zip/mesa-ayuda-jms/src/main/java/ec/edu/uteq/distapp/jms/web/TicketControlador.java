package ec.edu.uteq.distapp.jms.web;

import ec.edu.uteq.distapp.jms.dominio.SolicitudTicket;
import ec.edu.uteq.distapp.jms.dominio.Ticket;
import ec.edu.uteq.distapp.jms.mensajeria.TicketProductor;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;

@RestController
@RequestMapping("/api")
public class TicketControlador {

	private final TicketProductor productor;
	private final TableroSse tablero;

	// Numerador simple de tickets. En produccion vendria de la base de datos.
	private final AtomicInteger secuencia = new AtomicInteger(1000);

	public TicketControlador(TicketProductor productor, TableroSse tablero) {
		this.productor = productor;
		this.tablero = tablero;
	}

	/**
	 * Recibe el formulario y ENCOLA el ticket.
	 *
	 * Observa que el metodo responde de inmediato, sin esperar a que
	 * ningun tecnico lo atienda: eso es el desacoplamiento de
	 * sincronizacion en accion.
	 */
	@PostMapping(path = "/tickets", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Ticket> crear(@Valid @RequestBody SolicitudTicket solicitud) {

		Ticket ticket = new Ticket(
				"TK-" + secuencia.incrementAndGet(),
				solicitud.cliente(),
				solicitud.servicio(),
				solicitud.prioridad(),
				solicitud.descripcion(),
				Instant.now());

		productor.encolarTicket(ticket);

		// 202 Accepted es el codigo correcto: "lo he aceptado y lo
		// procesare", no "ya esta hecho". Devolver 200 OK seria mentir.
		return ResponseEntity.accepted().body(ticket);
	}

	/**
	 * Genera varios tickets de golpe para ver el reparto entre tecnicos.
	 */
	@PostMapping("/tickets/lote/{cantidad}")
	public ResponseEntity<String> lote(@PathVariable int cantidad) {

		int total = Math.min(Math.max(cantidad, 1), 20);   // limite de seguridad

		for (int i = 1; i <= total; i++) {
			productor.encolarTicket(new Ticket(
					"TK-" + secuencia.incrementAndGet(),
					"Cliente " + i,
					"Internet Fibra",
					ec.edu.uteq.distapp.jms.dominio.Prioridad.MEDIA,
					"Averia generada automaticamente numero " + i,
					Instant.now()));
		}
		return ResponseEntity.accepted().body(total + " tickets encolados");
	}

	/**
	 * Canal de eventos hacia el navegador.
	 * El tipo de contenido text/event-stream es lo que convierte esta
	 * respuesta en un canal SSE.
	 */
	@GetMapping(path = "/flujo", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public SseEmitter flujo() {
		return tablero.registrar();
	}
}
