package ec.edu.uteq.distapp.jms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada.
 *
 * @SpringBootApplication equivale a tres anotaciones a la vez:
 *   @Configuration        -> esta clase puede definir beans
 *   @EnableAutoConfiguration -> configura Tomcat, JMS, Jackson... solo
 *   @ComponentScan        -> busca @Component, @Service, @RestController
 *                            en ESTE paquete y en todos los de debajo
 *
 * De ahi que TODO el codigo deba colgar de ec.edu.uteq.distapp.jms:
 * una clase colocada fuera de ese arbol seria ignorada por completo.
 */
@SpringBootApplication
public class MesaAyudaJmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MesaAyudaJmsApplication.class, args);
	}
}
