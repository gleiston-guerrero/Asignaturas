package ec.edu.uteq.distapp.jms.dominio;

import java.time.Instant;

/**
 * Hecho consumado que viaja por el TOPICO.
 * Semanticamente es un EVENTO: "el ticket cambio de estado".
 * Por eso va a un topico y lo reciben TODOS los interesados.
 *
 * Notese el tiempo verbal de los campos: describe algo que YA paso.
 */
public record EventoTicket(
		String ticketId,
		String cliente,
		Prioridad prioridad,
		String estadoAnterior,
		String estadoNuevo,
		String tecnico,
		Instant ocurridoEn) {
}
