package ec.edu.uteq.distapp.jms.dominio;

import java.time.Instant;

/**
 * Orden de trabajo que viaja por la COLA.
 * Semanticamente es un COMANDO: "atiende este ticket".
 * Por eso va a una cola y lo debe recibir un unico tecnico.
 */
public record Ticket(
		String id,
		String cliente,
		String servicio,
		Prioridad prioridad,
		String descripcion,
		Instant creadoEn) {
}
