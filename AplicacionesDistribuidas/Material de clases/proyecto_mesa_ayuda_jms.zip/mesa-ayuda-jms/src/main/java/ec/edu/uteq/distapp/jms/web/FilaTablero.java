package ec.edu.uteq.distapp.jms.web;

/**
 * Una linea del tablero del navegador.
 * canal vale "cola" o "topico" y decide en que columna se pinta.
 */
public record FilaTablero(
		String canal,
		String actor,
		String ticketId,
		String cliente,
		String detalle,
		String instante) {
}
