package ec.edu.uteq.distapp.jms.dominio;

/**
 * Nivel de urgencia de un ticket de soporte.
 * El campo minutosSla indica en cuantos minutos debe atenderse
 * segun el acuerdo de nivel de servicio del ISP.
 */
public enum Prioridad {

	BAJA(480),
	MEDIA(240),
	ALTA(60),
	CRITICA(15);

	private final int minutosSla;

	Prioridad(int minutosSla) {
		this.minutosSla = minutosSla;
	}

	public int minutosSla() {
		return minutosSla;
	}
}
