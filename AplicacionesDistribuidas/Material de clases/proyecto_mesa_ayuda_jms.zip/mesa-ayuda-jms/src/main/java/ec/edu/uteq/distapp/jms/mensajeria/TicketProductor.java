package ec.edu.uteq.distapp.jms.mensajeria;

import ec.edu.uteq.distapp.jms.config.JmsConfig;
import ec.edu.uteq.distapp.jms.dominio.EventoTicket;
import ec.edu.uteq.distapp.jms.dominio.Ticket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

/**
 * Unico punto de la aplicacion que ENVIA mensajes.
 * Concentrar aqui los dos envios deja a la vista la diferencia
 * entre mandar un comando a una cola y publicar un evento en un topico.
 */
@Service
public class TicketProductor {

	private static final Logger log = LoggerFactory.getLogger(TicketProductor.class);

	private final JmsTemplate plantillaCola;
	private final JmsTemplate plantillaTopico;

	/**
	 * @Qualifier es OBLIGATORIO aqui: hay dos beans de tipo JmsTemplate
	 * y sin el, Spring inyectaria la marcada con @Primary en los dos
	 * parametros, y los eventos acabarian en una cola.
	 */
	public TicketProductor(@Qualifier("plantillaCola") JmsTemplate plantillaCola,
						   @Qualifier("plantillaTopico") JmsTemplate plantillaTopico) {
		this.plantillaCola = plantillaCola;
		this.plantillaTopico = plantillaTopico;
	}

	// ---------------------------------------------------------------
	// ENVIO A LA COLA  (punto a punto)
	// ---------------------------------------------------------------

	/**
	 * Deposita el ticket en la cola. Un solo tecnico lo recibira.
	 * El metodo retorna de inmediato: NO espera a que nadie lo atienda.
	 */
	public void encolarTicket(Ticket ticket) {

		plantillaCola.convertAndSend(
				JmsConfig.COLA_TICKETS,      // destino
				ticket,                       // objeto que se convertira a JSON
				mensaje -> {
					// Duplicamos la prioridad como PROPIEDAD del mensaje
					// para que pueda usarse en selectores del lado del broker.
					mensaje.setStringProperty("prioridad", ticket.prioridad().name());
					mensaje.setStringProperty("servicio", ticket.servicio());
					return mensaje;
				});

		log.info("--> COLA    | ticket {} encolado (prioridad {})",
				ticket.id(), ticket.prioridad());
	}

	// ---------------------------------------------------------------
	// PUBLICACION EN EL TOPICO  (publicacion / suscripcion)
	// ---------------------------------------------------------------

	/**
	 * Publica el evento. Lo reciben TODOS los suscriptores activos.
	 * Si no hay ninguno, la operacion es valida y no ocurre nada.
	 */
	public void publicarEvento(EventoTicket evento) {

		plantillaTopico.convertAndSend(
				JmsConfig.TOPICO_EVENTOS,
				evento,
				mensaje -> {
					mensaje.setStringProperty("estadoNuevo", evento.estadoNuevo());
					mensaje.setStringProperty("prioridad", evento.prioridad().name());
					return mensaje;
				});

		log.info("--> TOPICO  | evento {} -> {} del ticket {} publicado",
				evento.estadoAnterior(), evento.estadoNuevo(), evento.ticketId());
	}
}
