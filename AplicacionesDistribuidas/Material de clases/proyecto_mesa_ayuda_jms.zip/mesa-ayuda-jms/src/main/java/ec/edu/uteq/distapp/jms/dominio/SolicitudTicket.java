package ec.edu.uteq.distapp.jms.dominio;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Lo que llega desde el formulario del navegador.
 * No lleva id ni fecha: esos los genera el servidor, nunca el cliente.
 */
public record SolicitudTicket(

		@NotBlank(message = "El cliente es obligatorio")
		@Size(max = 60)
		String cliente,

		@NotBlank(message = "El servicio es obligatorio")
		String servicio,

		@NotNull(message = "La prioridad es obligatoria")
		Prioridad prioridad,

		@NotBlank(message = "La descripcion es obligatoria")
		@Size(max = 200)
		String descripcion) {
}
