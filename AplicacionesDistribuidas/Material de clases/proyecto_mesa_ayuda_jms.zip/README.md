# Mesa de ayuda ISP — JMS: cola + publicación/suscripción

Proyecto de referencia del manual *Mensajería asíncrona con JMS*
(Aplicaciones Distribuidas ISR-701, UTEQ).

## Requisitos
- JDK 21
- Docker Desktop en ejecución
- IntelliJ IDEA

## 1. Levantar el broker
```
cd <esta-carpeta>
docker compose up -d
```
Consola de administración: http://localhost:8161/console
Usuario `distapp`, contraseña `distapp2026`.

## 2. Ejecutar la aplicación
Abrir `mesa-ayuda-jms` en IntelliJ (File > Open, seleccionar la carpeta
que contiene el `pom.xml`) y ejecutar `MesaAyudaJmsApplication`.

O bien:
```
cd mesa-ayuda-jms
mvnw.cmd spring-boot:run
```

## 3. Abrir el tablero
http://localhost:8080

## Destinos JMS
| Destino | Tipo | Semántica |
|---|---|---|
| `soporte.tickets.cola` | Queue | Cada ticket lo atiende UN técnico |
| `soporte.tickets.eventos` | Topic | Cada evento lo reciben LOS TRES suscriptores |

## Nota
El envoltorio de Maven (`mvnw.cmd` y `.mvn/`) no está incluido: lo genera
IntelliJ al crear el proyecto con el asistente de Spring Boot. Si abres
este código directamente, usa el Maven de IntelliJ o instala Maven.
